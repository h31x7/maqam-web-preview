import json
import asyncio
import sys
import unittest
from uuid import uuid4
from pathlib import Path
import tempfile
import importlib.util
from unittest.mock import patch
import httpx
from fastapi.testclient import TestClient
from app.main import create_app
from app.config import Settings
from app.repository import LocalRepository

# Selector loop avoids Windows Proactor startup issues in some local runtimes.
if sys.platform=='win32':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


class BackendTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        path = Path(self.temp.name)
        datasets = {'lectures': [{'id':'1','title':'درس','summaryId':'summary-1','quizId':'quiz-1','bookId':None}], 'summaries':[{'id':'summary-1','lectureId':'1','title':'درس','points':['نقطة']*9}], 'quizzes':[{'id':'quiz-1','lectureId':'1','title':'درس','questions':[{'id':'q1','text':'سؤال','options':[{'letter':'أ','text':'نعم'},{'letter':'ب','text':'لا'}],'correctLetter':'أ'}]}], 'books':[{'id':'book-1','storagePath':'book-1.pdf','title':'كتاب'}], 'schedule':{'entries':[]}, 'live-translation-demo':[{'id':'1','ar':'الحمد لله','en':'Praise God','duration':3}]}
        for key,value in datasets.items():
            (path / (key+'.json')).write_text(json.dumps(value),encoding='utf-8')
        self.repo = LocalRepository(path)
        self.guest = str(uuid4())
        self.headers = {'X-Installation-Id':self.guest}

    def tearDown(self):
        self.temp.cleanup()

    def client(self, handler=None, **kwargs):
        return TestClient(create_app(Settings(**kwargs), self.repo, httpx.MockTransport(handler or (lambda request:httpx.Response(500)))))

    def test_offline_catalog_and_validation(self):
        with self.client() as c:
            self.assertEqual(c.get('/api/health').status_code,200)
            self.assertEqual(len(c.get('/api/lectures/1').json()['summary']['points']),9)
            self.assertEqual(c.post('/api/chat',json={'message':'hello'},headers=self.headers).status_code,503)
            self.assertEqual(c.post('/api/chat',json={'message':''},headers=self.headers).status_code,422)
            self.assertEqual(c.get('/api/chat/history',headers={'X-Installation-Id':'bad'}).status_code,422)
            self.assertEqual(c.post('/api/translate-demo',json={'sentenceId':'1','language':'fr'}).status_code,503)
            self.assertEqual(c.get('/api/books/book-1/file').status_code,503)

    def test_dify_stream_and_guest_isolation(self):
        def handler(request):
            if request.url.path.endswith('/stop'):
                return httpx.Response(200,json={'result':'success'})
            return httpx.Response(200,text='data: '+json.dumps({'event':'message','answer':'مرحبا','conversation_id':'conv-1','task_id':'task-1','message_id':'msg-1'})+'\n\ndata: '+json.dumps({'event':'message_end','conversation_id':'conv-1','message_id':'msg-1'})+'\n\n')
        with self.client(handler,dify_api_key='test') as c:
            r=c.post('/api/chat',json={'message':'سؤال'},headers=self.headers)
            self.assertEqual(r.status_code,200)
            self.assertIn('event: message',r.text)
            self.assertIn('event: end',r.text)
            self.assertEqual(len(c.get('/api/chat/history',headers=self.headers).json()['conversations']),1)
            other={'X-Installation-Id':str(uuid4())}
            self.assertEqual(c.get('/api/chat/history',headers=other).json()['conversations'],[])
            self.assertEqual(c.post('/api/chat',json={'message':'x','conversationId':'conv-1'},headers=other).status_code,404)
            self.assertEqual(c.post('/api/chat/stop',json={'taskId':'task-1'},headers=other).status_code,404)
            self.assertEqual(c.post('/api/chat/stop',json={'taskId':'task-1'},headers=self.headers).status_code,200)

    def test_dify_401_and_timeout(self):
        with self.client(lambda r:httpx.Response(401),dify_api_key='test') as c:
            self.assertEqual(c.post('/api/chat',json={'message':'x'},headers=self.headers).status_code,503)
        def timeout(request):
            raise httpx.ReadTimeout('redacted',request=request)
        with self.client(timeout,dify_api_key='test') as c:
            self.assertEqual(c.post('/api/chat',json={'message':'x'},headers=self.headers).status_code,504)

    def test_official_translation_cached(self):
        calls=[]
        def handler(request):
            calls.append(request)
            self.assertEqual(request.url.host,'translation.googleapis.com')
            self.assertNotIn('key',request.url.params)
            self.assertEqual(request.headers['x-goog-api-key'],'test')
            return httpx.Response(200,json={'data':{'translations':[{'translatedText':'Louange à Dieu'}]}})
        with self.client(handler,translation_provider='google',google_translation_api_key='test') as c:
            for _ in range(2):
                self.assertEqual(c.post('/api/translate-demo',json={'sentenceId':'1','language':'fr'}).json()['text'],'Louange à Dieu')
            self.assertEqual(len(calls),1)

    def test_private_pdf_range(self):
        def handler(request):
            self.assertEqual(request.headers['range'],'bytes=0-3')
            return httpx.Response(206,content=b'%PDF',headers={'content-range':'bytes 0-3/100','content-type':'application/pdf','accept-ranges':'bytes'})
        with self.client(handler,supabase_url='https://example.supabase.co',supabase_service_role_key='test') as c:
            r=c.get('/api/books/book-1/file',headers={'Range':'bytes=0-3'})
            self.assertEqual(r.status_code,206)
            self.assertEqual(r.content,b'%PDF')
            self.assertEqual(r.headers['content-range'],'bytes 0-3/100')
            self.assertEqual(c.get('/api/books/book-1/file',headers={'Range':'bytes=1-2,4-5'}).status_code,416)

    def test_cors_rate_limit_and_unknown_routes(self):
        with self.client(rate_limit_per_minute=2,allowed_origins=['https://allowed.example']) as c:
            allowed=c.get('/api/books',headers={'Origin':'https://allowed.example'})
            self.assertEqual(allowed.headers['access-control-allow-origin'],'https://allowed.example')
            denied=c.get('/api/books',headers={'Origin':'https://other.example'})
            self.assertNotIn('access-control-allow-origin',denied.headers)
            self.assertEqual(c.get('/api/books').status_code,429)
        with self.client() as c:
            self.assertEqual(c.post('/api/chat',content='x'*32769).status_code,413)
            self.assertEqual(c.get('/server.py').json()['code'],'not_found')

    def test_no_retry_after_read_timeout(self):
        calls=[]
        def timeout(request):
            calls.append(request)
            raise httpx.ReadTimeout('private request',request=request)
        with self.client(timeout,dify_api_key='test') as c:
            self.assertEqual(c.post('/api/chat',json={'message':'x'},headers=self.headers).status_code,504)
            self.assertEqual(len(calls),1)

    def test_connect_retry_before_stream(self):
        calls=[]
        def connect(request):
            calls.append(request)
            raise httpx.ConnectError('private request',request=request)
        with self.client(connect,dify_api_key='test') as c:
            self.assertEqual(c.post('/api/chat',json={'message':'x'},headers=self.headers).status_code,503)
            self.assertEqual(len(calls),2)

    def test_stream_interruption_preserves_partial_and_stops(self):
        calls=[]
        class Interrupted(httpx.AsyncByteStream):
            async def __aiter__(self):
                yield ('data: '+json.dumps({'event':'message','answer':'جزء','conversation_id':'partial','task_id':'task-partial','message_id':'message-partial'})+'\n\n').encode()
                raise httpx.ReadTimeout('private detail')
        def handler(request):
            calls.append(request.url.path)
            if request.url.path.endswith('/stop'): return httpx.Response(200,json={'result':'success'})
            return httpx.Response(200,stream=Interrupted())
        with self.client(handler,dify_api_key='test') as c:
            r=c.post('/api/chat',json={'message':'سؤال'},headers=self.headers)
            self.assertIn('stream_interrupted',r.text)
            self.assertEqual(len(calls),2)
            self.assertEqual(calls[-1],'/v1/chat-messages/task-partial/stop')
            messages=c.get('/api/chat/history',headers=self.headers).json()['conversations'][0]['messages']
            self.assertEqual(messages[-1]['text'],'جزء')

    def test_missing_content_is_clean_unavailable(self):
        self.repo.path=Path(self.temp.name)/'missing'
        with self.client() as c:
            r=c.get('/api/lectures')
            self.assertEqual(r.status_code,503)
            self.assertEqual(r.json()['code'],'service_unavailable')
            self.assertNotIn('Traceback',r.text)

    def test_uploader_rejects_traversal_and_reparse_points(self):
        spec=importlib.util.spec_from_file_location('upload_books',Path(__file__).parents[1]/'scripts/upload_books.py')
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        root=Path(self.temp.name)
        (root/'test.pdf').write_bytes(b'%PDF')
        self.assertEqual(module.safe_source_file(root,Path('test.pdf')),root.absolute()/'test.pdf')
        with self.assertRaises(ValueError): module.safe_source_file(root,Path('../other.pdf'))
        with self.assertRaises(ValueError): module.safe_source_file(root,root/'test.pdf')
        original=Path.lstat
        def reparse(path):
            result=original(path)
            if path.name=='test.pdf':
                class Reparse:
                    st_mode=result.st_mode
                    st_file_attributes=1024
                return Reparse()
            return result
        with patch.object(Path,'lstat',reparse):
            with self.assertRaises(ValueError): module.safe_source_file(root,Path('test.pdf'))


if __name__=='__main__': unittest.main()
