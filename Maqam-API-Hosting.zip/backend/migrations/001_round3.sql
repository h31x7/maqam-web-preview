-- Run in Supabase SQL editor. API uses server-only service_role; clients get no grants.
begin;
create table if not exists public.content (
  key text primary key check (key in ('lectures','summaries','quizzes','schedule','books','live-translation-demo')),
  payload jsonb not null,
  updated_at timestamptz not null default now()
);
create table if not exists public.conversations (
  id text primary key,
  installation_id uuid not null,
  created_at timestamptz not null default now()
);
create index if not exists conversations_installation_idx on public.conversations(installation_id,created_at desc);
create table if not exists public.chat_messages (
  id text primary key,
  conversation_id text not null references public.conversations(id) on delete cascade,
  role text not null check(role in ('user','assistant')),
  text text not null check(length(text)<=100000),
  created_at timestamptz not null default now()
);
create index if not exists messages_conversation_idx on public.chat_messages(conversation_id,created_at);
create table if not exists public.translation_cache (
  sentence_id text not null,
  language text not null,
  text text not null,
  created_at timestamptz not null default now(),
  primary key(sentence_id,language)
);
alter table public.content enable row level security;
alter table public.conversations enable row level security;
alter table public.chat_messages enable row level security;
alter table public.translation_cache enable row level security;
-- No anon/authenticated policies: no direct guest-supplied SQL identity to trust.
revoke all on public.content,public.conversations,public.chat_messages,public.translation_cache from anon,authenticated;
grant all on public.content,public.conversations,public.chat_messages,public.translation_cache to service_role;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('maqam-books','maqam-books',false,50000000,array['application/pdf'])
on conflict(id) do update set public=false,file_size_limit=50000000,allowed_mime_types=array['application/pdf'];
-- Private bucket has no guest policies. API authenticates with service_role and proxies Range.
commit;
