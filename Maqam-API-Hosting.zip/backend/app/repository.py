"""Swappable content, conversation and translation storage boundary."""
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol
import httpx

Json = dict[str, Any]


class RepositoryUnavailable(Exception):
    """Sanitized boundary error: upstream URL/identity is not logged."""


class Repository(Protocol):
    async def content(self, name: str) -> Any: ...
    async def conversation_owned(self, guest: str, conversation: str) -> bool: ...
    async def save_message(self, guest: str, conversation: str, role: str, text: str, message_id: str) -> None: ...
    async def history(self, guest: str) -> list[Json]: ...
    async def translation(self, sentence: str, language: str) -> str | None: ...
    async def save_translation(self, sentence: str, language: str, text: str) -> None: ...


class LocalRepository:
    """Real bundled content fallback; chat/cache memory only for local development."""
    def __init__(self, path: Path):
        self.path=path
        self.conversations: dict[str, Json]={}
        self.cache: dict[tuple[str,str],str]={}

    async def content(self,name: str) -> Any:
        file=self.path / (name+'.json')
        try: return json.loads(file.read_text(encoding='utf-8-sig'))
        except (OSError,ValueError): raise RepositoryUnavailable('content unavailable') from None

    async def conversation_owned(self,guest: str,conversation: str) -> bool:
        return self.conversations.get(conversation,{}).get('installation_id')==guest

    async def save_message(self,guest: str,conversation: str,role: str,text: str,message_id: str) -> None:
        record=self.conversations.setdefault(conversation,{'id':conversation,'installation_id':guest,'messages':[]})
        if record['installation_id']!=guest: raise ValueError('ownership')
        record['messages'].append({'id':message_id,'role':role,'text':text,'createdAt':datetime.now(timezone.utc).isoformat()})

    async def history(self,guest: str) -> list[Json]:
        return [{'id':r['id'],'messages':r['messages']} for r in self.conversations.values() if r['installation_id']==guest]

    async def translation(self,sentence: str,language: str) -> str | None:
        return self.cache.get((sentence,language))

    async def save_translation(self,sentence: str,language: str,text: str) -> None:
        self.cache[(sentence,language)]=text


class SupabaseRepository:
    def __init__(self,url: str,key: str,client: httpx.AsyncClient):
        self.url=url+'/rest/v1'
        self.headers={'apikey':key,'Authorization':'Bearer '+key}
        self.client=client

    async def request(self,method: str,table: str,**kwargs: Any) -> Any:
        headers={**self.headers,**kwargs.pop('headers',{})}
        try:
            r=await self.client.request(method,self.url+'/'+table,headers=headers,**kwargs)
            r.raise_for_status()
            return r.json() if r.content else None
        except (httpx.HTTPError,ValueError):
            raise RepositoryUnavailable('repository unavailable') from None

    async def content(self,name: str) -> Any:
        rows=await self.request('GET','content',params={'key':'eq.'+name,'select':'payload'})
        if not rows: raise RepositoryUnavailable('content not seeded')
        return rows[0]['payload']

    async def conversation_owned(self,guest: str,conversation: str) -> bool:
        rows=await self.request('GET','conversations',params={'id':'eq.'+conversation,'installation_id':'eq.'+guest,'select':'id'})
        return bool(rows)

    async def save_message(self,guest: str,conversation: str,role: str,text: str,message_id: str) -> None:
        # A conflict must never update another installation's owner.
        await self.request('POST','conversations',params={'on_conflict':'id'},headers={'Prefer':'resolution=ignore-duplicates'},json={'id':conversation,'installation_id':guest})
        if not await self.conversation_owned(guest,conversation): raise ValueError('ownership')
        await self.request('POST','chat_messages',json={'id':message_id,'conversation_id':conversation,'role':role,'text':text})

    async def history(self,guest: str) -> list[Json]:
        rows=await self.request('GET','conversations',params={'installation_id':'eq.'+guest,'select':'id,chat_messages(id,role,text,created_at)','order':'created_at.desc','limit':'50'})
        return [{'id':r['id'],'messages':[{'id':m['id'],'role':m['role'],'text':m['text'],'createdAt':m['created_at']} for m in sorted(r['chat_messages'],key=lambda m:m['created_at'])]} for r in rows]

    async def translation(self,sentence: str,language: str) -> str | None:
        rows=await self.request('GET','translation_cache',params={'sentence_id':'eq.'+sentence,'language':'eq.'+language,'select':'text'})
        return rows[0]['text'] if rows else None

    async def save_translation(self,sentence: str,language: str,text: str) -> None:
        await self.request('POST','translation_cache',headers={'Prefer':'resolution=ignore-duplicates'},params={'on_conflict':'sentence_id,language'},json={'sentence_id':sentence,'language':language,'text':text})
