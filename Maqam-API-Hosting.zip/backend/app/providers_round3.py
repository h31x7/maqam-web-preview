"""Official provider adapters. No credentials or prompts are logged."""
import asyncio
import html
from typing import Any, Protocol
import httpx
from .config import Settings


class TranslationProvider(Protocol):
    async def translate(self,text: str,language: str) -> str: ...


class GoogleTranslation:
    def __init__(self,client: httpx.AsyncClient,key: str):
        self.client=client
        self.key=key

    async def translate(self,text: str,language: str) -> str:
        response=await self.client.post('https://translation.googleapis.com/language/translate/v2',headers={'X-Goog-Api-Key':self.key},json={'q':text,'source':'ar','target':language,'format':'text'})
        response.raise_for_status()
        return html.unescape(response.json()['data']['translations'][0]['translatedText'])


class Dify:
    def __init__(self,client: httpx.AsyncClient,settings: Settings):
        self.client=client
        self.settings=settings

    async def open_stream(self,guest: str,message: str,conversation: str | None) -> httpx.Response:
        payload: dict[str,Any]={'inputs':{},'query':message,'response_mode':'streaming','user':guest}
        if conversation: payload['conversation_id']=conversation
        # Retry only connect failures: read timeout can happen after the provider accepted a turn.
        for attempt in range(2):
            try:
                request=self.client.build_request('POST',self.settings.dify_api_url+'/chat-messages',headers={'Authorization':'Bearer '+self.settings.dify_api_key},json=payload)
                response=await self.client.send(request,stream=True)
                if response.status_code>=400:
                    await response.aclose()
                    raise httpx.HTTPStatusError('provider rejected request',request=request,response=response)
                return response
            except (httpx.ConnectError,httpx.ConnectTimeout):
                if attempt: raise
                await asyncio.sleep(0.15)
        raise RuntimeError('unreachable')

    async def stop(self,guest: str,task: str) -> None:
        r=await self.client.post(self.settings.dify_api_url+'/chat-messages/'+task+'/stop',headers={'Authorization':'Bearer '+self.settings.dify_api_key},json={'user':guest})
        r.raise_for_status()
