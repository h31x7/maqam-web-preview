"""Maqam Round 3 API: server-only providers, UUID guest capability."""
import asyncio
import json
import logging
import re
import time
from collections import OrderedDict, deque
from contextlib import asynccontextmanager
from typing import Annotated, Any
from uuid import UUID, uuid4
from urllib.parse import quote
import httpx
import anyio
from fastapi import FastAPI, Header, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from pydantic import BaseModel, ConfigDict, Field, field_validator
from .config import Settings
from .repository import LocalRepository, Repository, SupabaseRepository, RepositoryUnavailable
from .providers_round3 import Dify, GoogleTranslation

log=logging.getLogger('maqam.api')
logging.getLogger('httpx').setLevel(logging.WARNING)
logging.getLogger('httpcore').setLevel(logging.WARNING)


class APIError(Exception):
    def __init__(self,status: int,error: str,code: str):
        self.status,self.error,self.code=status,error,code


class ChatInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    message: str=Field(min_length=1,max_length=4000)
    conversationId: str | None=Field(default=None,max_length=100,pattern=r'^[A-Za-z0-9_-]+$')
    @field_validator('message')
    @classmethod
    def trim(cls,value: str) -> str:
        value=value.strip()
        if not value: raise ValueError('empty')
        return value


class StopInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    taskId: str=Field(min_length=1,max_length=100,pattern=r'^[A-Za-z0-9_-]+$')


class TranslationInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    sentenceId: str | int
    language: str=Field(min_length=2,max_length=20,pattern=r'^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})?$')


def provider_error(exc: Exception) -> APIError:
    if isinstance(exc,httpx.TimeoutException):
        return APIError(504,'استغرقت الخدمة وقتًا طويلًا. حاول مرة أخرى.','provider_timeout')
    return APIError(503,'المساعد غير متاح حاليًا','assistant_unavailable')


def sse(event: str,data: dict[str,Any]) -> str:
    return 'event: '+event+'\ndata: '+json.dumps(data,ensure_ascii=False)+'\n\n'


class BodyLimitMiddleware:
    """Cap all POST bytes, including chunked bodies, before JSON parsing."""
    def __init__(self,app):
        self.app=app

    async def __call__(self,scope,receive,send):
        if scope['type']!='http' or scope['method']!='POST':
            return await self.app(scope,receive,send)
        parts=[]
        size=0
        while True:
            event=await receive()
            if event['type']=='http.disconnect': return
            chunk=event.get('body',b'')
            size+=len(chunk)
            if size>32768:
                response=JSONResponse({'error':'حجم الطلب أكبر من المسموح.','code':'request_too_large'},status_code=413)
                return await response(scope,receive,send)
            parts.append(chunk)
            if not event.get('more_body',False): break
        delivered=False
        async def replay():
            nonlocal delivered
            if not delivered:
                delivered=True
                return {'type':'http.request','body':b''.join(parts),'more_body':False}
            return await receive()
        await self.app(scope,replay,send)


def create_app(settings: Settings | None=None,repository: Repository | None=None,transport: httpx.AsyncBaseTransport | None=None) -> FastAPI:
    settings=settings or Settings()
    client=httpx.AsyncClient(timeout=httpx.Timeout(settings.timeout_seconds,connect=min(10,settings.timeout_seconds)),transport=transport,follow_redirects=False)
    repo=repository or (SupabaseRepository(settings.supabase_url,settings.supabase_service_role_key,client) if settings.storage_ready else LocalRepository(settings.data_dir))
    dify=Dify(client,settings)
    tasks: OrderedDict[str,tuple[str,float]]=OrderedDict()
    rates: OrderedDict[str,deque[float]]=OrderedDict()
    translation_lock=asyncio.Lock()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        yield
        await client.aclose()

    app=FastAPI(title='Maqam API',version='3.0.0',lifespan=lifespan)
    app.add_middleware(BodyLimitMiddleware)

    @app.middleware('http')
    async def rate_limit(request: Request,call_next):
        # Bounded IP buckets. Do not log identifiers, URLs, bodies, keys or prompts.
        if request.method!='OPTIONS' and request.url.path!='/api/health':
            length=request.headers.get('content-length')
            if length and (not length.isdigit() or int(length)>32768):
                return JSONResponse({'error':'حجم الطلب أكبر من المسموح.','code':'request_too_large'},status_code=413)
            now=time.monotonic()
            key=request.client.host if request.client else 'unknown'
            bucket=rates.setdefault(key,deque())
            rates.move_to_end(key)
            while bucket and now-bucket[0]>60: bucket.popleft()
            while len(rates)>10000: rates.popitem(last=False)
            if len(bucket)>=settings.rate_limit_per_minute:
                return JSONResponse({'error':'طلبات كثيرة. انتظر قليلًا ثم حاول مجددًا.','code':'rate_limited'},status_code=429,headers={'Retry-After':'60'})
            bucket.append(now)
        start=time.monotonic()
        response=await call_next(request)
        log.info(json.dumps({'event':'request','method':request.method,'status':response.status_code,'elapsedMs':round((time.monotonic()-start)*1000)}))
        return response

    @app.exception_handler(APIError)
    async def api_error(request: Request,exc: APIError):
        return JSONResponse({'error':exc.error,'code':exc.code},status_code=exc.status)

    @app.exception_handler(RepositoryUnavailable)
    async def repository_error(request: Request,exc: RepositoryUnavailable):
        return JSONResponse({'error':'المحتوى أو الخدمة غير متاحة حاليًا. حاول لاحقًا.','code':'service_unavailable'},status_code=503)

    @app.exception_handler(RequestValidationError)
    async def invalid(request: Request,exc: RequestValidationError):
        return JSONResponse({'error':'يرجى التحقق من البيانات المرسلة.','code':'invalid_request'},status_code=422)

    @app.exception_handler(StarletteHTTPException)
    async def http_error(request: Request,exc: StarletteHTTPException):
        return JSONResponse({'error':'المحتوى أو الطلب غير متاح.','code':'not_found' if exc.status_code==404 else 'invalid_request'},status_code=exc.status_code)

    @app.exception_handler(Exception)
    async def unexpected(request: Request,exc: Exception):
        log.warning(json.dumps({'event':'unavailable','type':type(exc).__name__}))
        return JSONResponse({'error':'الخدمة غير متاحة حاليًا. حاول لاحقًا.','code':'service_unavailable'},status_code=503)

    async def guest(value: str | None) -> str:
        try:
            parsed=UUID(value or '')
            if parsed.version!=4: raise ValueError('not random UUID')
            return str(parsed)
        except ValueError:
            raise APIError(422,'معرّف الزائر غير صالح.','invalid_installation')

    async def find(name: str,id: str):
        rows=await repo.content(name)
        item=next((r for r in rows if str(r['id'])==id),None)
        if item is None: raise APIError(404,'المحتوى المطلوب غير موجود.','not_found')
        return item

    @app.get('/api/health')
    async def health():
        return {'status':'ok','version':3,'assistantAvailable':bool(settings.dify_api_key),'booksAvailable':settings.storage_ready,'translationAvailable':settings.translation_provider=='google' and bool(settings.google_translation_api_key)}

    @app.get('/api/lectures')
    async def lectures(): return await repo.content('lectures')

    @app.get('/api/lectures/{id}')
    async def lecture(id: str):
        item=await find('lectures',id)
        summary=next((r for r in await repo.content('summaries') if str(r['lectureId'])==id),None)
        quiz=next((r for r in await repo.content('quizzes') if str(r['lectureId'])==id),None)
        book=await find('books',item['bookId']) if item.get('bookId') else None
        if book: book={k:v for k,v in book.items() if k!='sourcePath'}
        return {**item,'summary':summary,'quiz':quiz,'book':book}

    @app.get('/api/lectures/{id}/quiz')
    async def quiz(id: str):
        data=await lecture(id)
        if not data['quiz']: raise APIError(404,'اختبار هذه المحاضرة غير متاح.','not_found')
        return [{'title':q['text'],'answers':[o['text'] for o in q['options']],'correct':next(i for i,o in enumerate(q['options']) if o['letter']==q['correctLetter'])} for q in data['quiz']['questions']]

    @app.post('/api/lectures/{id}/summary')
    async def summary(id: str):
        data=await lecture(id)
        if not data['summary']: raise APIError(404,'ملخص هذه المحاضرة غير متاح.','not_found')
        return {'text':'\n'.join(str(i+1)+'. '+p for i,p in enumerate(data['summary']['points'])),'title':data['summary']['title'],'points':data['summary']['points']}

    @app.get('/api/schedule')
    async def schedule(): return await repo.content('schedule')

    @app.get('/api/books')
    async def books(): return [{k:v for k,v in b.items() if k!='sourcePath'} for b in await repo.content('books')]

    @app.get('/api/live-translation-demo')
    async def demo(): return await repo.content('live-translation-demo')

    @app.get('/api/books/{id}/file')
    async def pdf(id: str,range_value: Annotated[str | None,Header(alias='Range')]=None):
        book=await find('books',id)
        if not settings.storage_ready: raise APIError(503,'الكتاب غير متاح حاليًا.','books_unavailable')
        if range_value:
            match=re.fullmatch(r'bytes=(\d*)-(\d*)',range_value)
            if not match or not any(match.groups()) or (match[1] and match[2] and int(match[1])>int(match[2])):
                raise APIError(416,'نطاق الملف غير صالح.','invalid_range')
        storage_path=book.get('storagePath','')
        if not storage_path or '..' in storage_path.split('/') or storage_path.startswith('/'):
            raise APIError(503,'الكتاب غير متاح حاليًا.','books_unavailable')
        headers={'apikey':settings.supabase_service_role_key,'Authorization':'Bearer '+settings.supabase_service_role_key}
        if range_value: headers['Range']=range_value
        req=client.build_request('GET',settings.supabase_url+'/storage/v1/object/authenticated/'+quote(settings.storage_bucket,safe='')+'/'+quote(storage_path,safe='/'),headers=headers)
        try: response=await client.send(req,stream=True)
        except httpx.HTTPError: raise APIError(503,'الكتاب غير متاح حاليًا. حاول لاحقًا.','books_unavailable')
        if response.status_code not in (200,206):
            status=416 if response.status_code==416 else 503
            await response.aclose()
            raise APIError(status,'تعذر فتح الكتاب حاليًا.','books_unavailable')
        async def chunks():
            try:
                async for chunk in response.aiter_bytes(): yield chunk
            finally: await response.aclose()
        safe_headers={k:v for k,v in response.headers.items() if k in ('content-length','content-range','accept-ranges','etag','last-modified')}
        safe_headers.update({'Content-Disposition':'inline','Cache-Control':'private, max-age=3600','X-Content-Type-Options':'nosniff'})
        return StreamingResponse(chunks(),status_code=response.status_code,media_type='application/pdf',headers=safe_headers)

    @app.post('/api/chat')
    async def chat(body: ChatInput,request: Request,installation: Annotated[str | None,Header(alias='X-Installation-Id')]=None):
        owner=await guest(installation)
        if body.conversationId and not await repo.conversation_owned(owner,body.conversationId):
            raise APIError(404,'المحادثة غير موجودة.','conversation_not_found')
        if not settings.dify_api_key: raise APIError(503,'المساعد غير متاح حاليًا','assistant_unavailable')
        try: response=await dify.open_stream(owner,body.message,body.conversationId)
        except httpx.HTTPError as exc: raise provider_error(exc)
        async def events():
            conversation=body.conversationId
            task=None
            message_id=str(uuid4())
            answer=[]
            answer_length=0
            saved=False
            ended=False
            started=time.monotonic()
            try:
                async for line in response.aiter_lines():
                    if time.monotonic()-started>180: raise ValueError('stream time limit')
                    if await request.is_disconnected(): break
                    if not line.startswith('data:'): continue
                    raw=line[5:].strip()
                    if raw=='[DONE]': break
                    try: event=json.loads(raw)
                    except json.JSONDecodeError: continue
                    current=event.get('conversation_id') or conversation
                    if conversation and current!=conversation: raise ValueError('conversation changed')
                    conversation=current
                    task=event.get('task_id') or task
                    message_id=event.get('message_id') or message_id
                    if conversation and not saved:
                        await repo.save_message(owner,conversation,'user',body.message,str(uuid4()))
                        saved=True
                    if task:
                        tasks[task]=(owner,time.monotonic())
                        tasks.move_to_end(task)
                        while len(tasks)>1000: tasks.popitem(last=False)
                    kind=event.get('event')
                    if kind in ('message','agent_message'):
                        if not conversation: raise ValueError('missing conversation')
                        text=event.get('answer','')
                        answer_length+=len(text)
                        if answer_length>100000: raise ValueError('answer too large')
                        answer.append(text)
                        yield sse('message',{'text':text,'conversationId':conversation,'taskId':task,'messageId':message_id})
                    elif kind=='message_end':
                        ended=True
                        yield sse('end',{'conversationId':conversation,'messageId':message_id})
                        break
                    elif kind=='error':
                        yield sse('error',{'error':'المساعد غير متاح حاليًا','code':'assistant_unavailable'})
                        break
                if not ended: yield sse('error',{'error':'توقف الاتصال بالمساعد. يمكنك المحاولة مجددًا.','code':'stream_interrupted'})
            except Exception:
                yield sse('error',{'error':'توقف الاتصال بالمساعد. يمكنك المحاولة مجددًا.','code':'stream_interrupted'})
            finally:
                # Starlette cancels disconnected streams; shield bounded cleanup/stop.
                with anyio.move_on_after(5,shield=True):
                    await response.aclose()
                    if conversation and saved and answer:
                        try: await repo.save_message(owner,conversation,'assistant',''.join(answer),message_id)
                        except Exception: log.warning('{"event":"history_save_unavailable"}')
                    if not ended and task:
                        try: await dify.stop(owner,task)
                        except httpx.HTTPError: pass
        return StreamingResponse(events(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})

    @app.get('/api/chat/history')
    async def history(installation: Annotated[str | None,Header(alias='X-Installation-Id')]=None):
        return {'conversations':await repo.history(await guest(installation))}

    @app.post('/api/chat/stop')
    async def stop(body: StopInput,installation: Annotated[str | None,Header(alias='X-Installation-Id')]=None):
        owner=await guest(installation)
        entry=tasks.get(body.taskId)
        if not entry or entry[0]!=owner or time.monotonic()-entry[1]>3600:
            raise APIError(404,'الطلب غير موجود.','task_not_found')
        try: await dify.stop(owner,body.taskId)
        except httpx.HTTPError as exc: raise provider_error(exc)
        return {'stopped':True}

    @app.post('/api/translate-demo')
    async def translate(body: TranslationInput):
        sentence=await find('live-translation-demo',str(body.sentenceId))
        if body.language in ('ar','en','ur','tr') and body.language in sentence:
            return {'sentenceId':body.sentenceId,'language':body.language,'text':sentence[body.language],'source':'provided'}
        if settings.translation_provider!='google' or not settings.google_translation_api_key:
            raise APIError(503,'الترجمة لهذه اللغة غير متاحة حاليًا','translation_unavailable')
        async with translation_lock:
            cached=await repo.translation(str(body.sentenceId),body.language)
            if cached is not None: return {'sentenceId':body.sentenceId,'language':body.language,'text':cached,'source':'cache'}
            try: text=await GoogleTranslation(client,settings.google_translation_api_key).translate(sentence['ar'],body.language)
            except (httpx.HTTPError,KeyError,IndexError):
                raise APIError(503,'الترجمة لهذه اللغة غير متاحة حاليًا','translation_unavailable')
            await repo.save_translation(str(body.sentenceId),body.language,text)
            return {'sentenceId':body.sentenceId,'language':body.language,'text':text,'source':'google-cloud'}

    app.add_middleware(CORSMiddleware,allow_origins=settings.allowed_origins,allow_methods=['GET','POST','OPTIONS'],allow_headers=['Content-Type','X-Installation-Id','Range'],expose_headers=['Content-Range','Accept-Ranges','Content-Length'])
    return app


app=create_app()
