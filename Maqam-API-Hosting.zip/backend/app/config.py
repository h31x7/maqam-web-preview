"""Server-only settings; credentials never enter client configuration."""
import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Settings:
    dify_api_url: str = field(default_factory=lambda: os.getenv('DIFY_API_URL','https://api.dify.ai/v1').rstrip('/'))
    dify_api_key: str = field(default_factory=lambda: os.getenv('DIFY_API_KEY',''))
    supabase_url: str = field(default_factory=lambda: os.getenv('SUPABASE_URL','').rstrip('/'))
    supabase_service_role_key: str = field(default_factory=lambda: os.getenv('SUPABASE_SERVICE_ROLE_KEY',''))
    storage_bucket: str = field(default_factory=lambda: os.getenv('SUPABASE_STORAGE_BUCKET','maqam-books'))
    translation_provider: str = field(default_factory=lambda: os.getenv('TRANSLATION_PROVIDER','disabled'))
    google_translation_api_key: str = field(default_factory=lambda: os.getenv('GOOGLE_TRANSLATION_API_KEY',''))
    allowed_origins: list[str] = field(default_factory=lambda: [s.strip() for s in os.getenv('ALLOWED_ORIGINS','http://localhost:8081').split(',') if s.strip() and s.strip() != '*'])
    timeout_seconds: float = field(default_factory=lambda: min(90,max(1,float(os.getenv('REQUEST_TIMEOUT_SECONDS','30')))))
    rate_limit_per_minute: int = field(default_factory=lambda: max(1,int(os.getenv('RATE_LIMIT_PER_MINUTE','30'))))
    data_dir: Path = field(default_factory=lambda: Path(os.getenv('DATA_DIR') or str(Path(__file__).resolve().parents[2] / 'data')))

    @property
    def storage_ready(self) -> bool:
        return bool(self.supabase_url and self.supabase_service_role_key)
