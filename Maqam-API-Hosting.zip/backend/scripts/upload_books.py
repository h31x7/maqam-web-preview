"""Upload original PDFs from an explicitly supplied source root to private Storage."""
import argparse
import asyncio
import json
import os
import sys
import stat
from pathlib import Path
from urllib.parse import quote
import httpx
from dotenv import load_dotenv


def safe_source_file(source_root: Path,relative: Path) -> Path:
    """Lexical containment plus rejection of symlinks/junctions/reparse points.

    Windows strict resolve opens directories with GetFinalPathNameByHandle,
    denied by some sandboxes even when file metadata/read access is granted.
    lstat checks every component below the explicit root without following a
    link. Rejecting all reparse points prevents a junction from escaping it.
    """
    root=Path(os.path.abspath(source_root))
    if relative.anchor or '..' in relative.parts: raise ValueError('Unsafe source path')
    file=Path(os.path.abspath(root/relative))
    if not file.is_relative_to(root) or file==root: raise ValueError('Unsafe source path')
    current=root
    for part in (None,*file.relative_to(root).parts):
        if part is not None: current=current/part
        info=current.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',1024):
            raise ValueError('Symlink or junction source path')
        if current!=file and not stat.S_ISDIR(info.st_mode): raise ValueError('Invalid source directory')
    if not stat.S_ISREG(info.st_mode): raise ValueError('Invalid source file')
    return file


async def main() -> None:
    load_dotenv()
    parser=argparse.ArgumentParser()
    parser.add_argument('--source-root',required=True,type=Path)
    parser.add_argument('--metadata',type=Path,default=Path(__file__).resolve().parents[2]/'data/books.json')
    parser.add_argument('--validate-only','--dry-run',action='store_true')
    args=parser.parse_args()
    root=Path(os.path.abspath(args.source_root))
    books=json.loads(args.metadata.read_text(encoding='utf-8-sig'))
    files=[]
    for book in books:
        relative=Path(book.get('sourcePath') or book['filename'])
        file=safe_source_file(root,relative)
        if file.suffix.lower()!='.pdf': raise ValueError('Unsafe source path')
        if file.stat().st_size!=book['sizeBytes']: raise ValueError('PDF size does not match metadata')
        if book['sizeBytes']>50000000: raise ValueError('PDF exceeds configured private bucket limit')
        storage_path=book['storagePath']
        if storage_path.startswith('/') or '..' in storage_path.split('/'): raise ValueError('Unsafe storage path')
        files.append((book['id'],file,storage_path))
    if args.validate_only:
        print('Validated '+str(len(files))+' PDFs; no network calls.')
        return
    url=os.environ['SUPABASE_URL'].rstrip('/')
    key=os.environ['SUPABASE_SERVICE_ROLE_KEY']
    bucket=os.getenv('SUPABASE_STORAGE_BUCKET','maqam-books')
    async with httpx.AsyncClient(timeout=httpx.Timeout(300,connect=10)) as client:
        for id,file,path in files:
            async def chunks():
                with file.open('rb') as stream:
                    while chunk:=stream.read(1024*1024):
                        yield chunk
            response=await client.post(url+'/storage/v1/object/'+quote(bucket,safe='')+'/'+quote(path,safe='/'),headers={'apikey':key,'Authorization':'Bearer '+key,'Content-Type':'application/pdf','Content-Length':str(file.stat().st_size),'x-upsert':'true'},content=chunks())
            if response.status_code>=400: raise RuntimeError('Upload failed: '+id+' HTTP '+str(response.status_code))
            print('Uploaded '+id)


if __name__=='__main__':
    try: asyncio.run(main())
    except Exception as exc:
        print('Upload failed ('+type(exc).__name__+'); check source root, sizes and environment.',file=sys.stderr)
        sys.exit(1)
