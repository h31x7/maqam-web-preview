"""Run from backend after SQL migration. Never prints credentials or user content."""
import argparse
import asyncio
import json
import os
import sys
from pathlib import Path
import httpx
from dotenv import load_dotenv

DATASETS=('lectures','summaries','quizzes','schedule','books','live-translation-demo')


async def main() -> None:
    load_dotenv()
    parser=argparse.ArgumentParser()
    parser.add_argument('--data-dir',type=Path,default=Path(__file__).resolve().parents[2]/'data')
    parser.add_argument('--validate-only','--dry-run',action='store_true')
    args=parser.parse_args()
    payloads=[]
    for name in DATASETS:
        value=json.loads((args.data_dir/(name+'.json')).read_text(encoding='utf-8-sig'))
        if name=='books': value=[{k:v for k,v in b.items() if k!='sourcePath'} for b in value]
        payloads.append({'key':name,'payload':value})
    lectures=payloads[0]['payload']
    if len(lectures)!=9 or len(payloads[1]['payload'])!=9 or len(payloads[4]['payload'])!=7:
        raise ValueError('Expected 9 lectures, 9 summaries and 7 books')
    if sum(len(q['questions']) for q in payloads[2]['payload'])!=45:
        raise ValueError('Expected 45 questions')
    if {str(l['id']) for l in lectures}!={str(i) for i in range(1,10)} or {l['order'] for l in lectures}!=set(range(1,10)):
        raise ValueError('Invalid lecture ids/order')
    summary_ids={s['id'] for s in payloads[1]['payload']}
    quiz_ids={q['id'] for q in payloads[2]['payload']}
    book_ids={b['id'] for b in payloads[4]['payload']}
    if len(summary_ids)!=9 or len(quiz_ids)!=9 or len(book_ids)!=7: raise ValueError('Duplicate metadata ids')
    for lecture in lectures:
        if lecture['summaryId'] not in summary_ids or lecture['quizId'] not in quiz_ids or (lecture['bookId'] is not None and lecture['bookId'] not in book_ids):
            raise ValueError('Invalid lecture content link')
    for summary in payloads[1]['payload']:
        if len(summary['points'])!=9: raise ValueError('Summary point count')
    for quiz in payloads[2]['payload']:
        if len(quiz['questions'])!=5: raise ValueError('Quiz question count')
        for q in quiz['questions']:
            letters=[o['letter'] for o in q['options']]
            if len(letters)!=4 or set(letters)!={'أ','ب','ج','د'} or q['correctLetter'] not in letters: raise ValueError('Invalid options')
    if len(payloads[3]['payload']['entries'])!=12 or len(payloads[5]['payload'])!=27:
        raise ValueError('Expected 12 schedule cards and 27 captions')
    if {s['id'] for s in payloads[5]['payload']}!=set(range(27)):
        raise ValueError('Invalid caption ids')
    if any(s['duration']<=0 or any(not isinstance(s.get(lang),str) or not s[lang] for lang in ('ar','en','ur','tr')) for s in payloads[5]['payload']):
        raise ValueError('Invalid caption content')
    if args.validate_only:
        print('Six datasets validated; no network calls.')
        return
    url=os.environ['SUPABASE_URL'].rstrip('/')
    key=os.environ['SUPABASE_SERVICE_ROLE_KEY']
    async with httpx.AsyncClient(timeout=30) as client:
        response=await client.post(url+'/rest/v1/content',params={'on_conflict':'key'},headers={'apikey':key,'Authorization':'Bearer '+key,'Prefer':'resolution=merge-duplicates'},json=payloads)
        if response.status_code>=400: raise RuntimeError('Supabase seed failed: HTTP '+str(response.status_code))
    print('Seeded six datasets.')


if __name__=='__main__':
    try: asyncio.run(main())
    except Exception as exc:
        print('Seed failed ('+type(exc).__name__+'); check files, migration and environment.',file=sys.stderr)
        sys.exit(1)
