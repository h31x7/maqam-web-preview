/** User-supplied Round 3 offline content. PDFs are uploaded separately. */
export type AnswerLetter = 'أ' | 'ب' | 'ج' | 'د';

export interface ContentVerification {
  status: 'VERIFIED' | 'UNVERIFIED';
  confidence: 'high' | 'low' | 'none';
  actualTitle: string | null;
  reason: string;
  sourceUrl?: string;
  missingTokens?: string[];
}

export interface ContentLecture {
  id: string;
  youtubeId: string;
  title: string;
  expectedTitle: string;
  sheikh: string;
  order: number;
  summaryId: string;
  quizId: string;
  bookId: string | null;
  thumbnail: string;
  verification: ContentVerification;
  transcriptAvailable: false;
}

export interface ContentSummary {
  id: string;
  lectureId: string;
  title: string;
  sourceTitleLine: string;
  points: string[];
}

export interface ContentQuiz {
  id: string;
  lectureId: string;
  title: string;
  sheikh: string;
  questions: {
    id: string;
    text: string;
    options: { letter: AnswerLetter; text: string }[];
    correctLetter: AnswerLetter;
  }[];
}

export interface ContentBook {
  id: string;
  title: string;
  filename: string;
  sizeBytes: number;
  sourcePath: string;
  storagePath: string;
  mimeType: 'application/pdf';
  author: string | null;
}
