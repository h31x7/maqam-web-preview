# Maqam — approved D.2

Product: Arabic RTL scholarly platform of the Haram institute. Visitor and Sharia student are primary; teaching and operations share the same component family. User-approved D.2 is the visual authority. Existing exact Arabic copy and behavioral contracts are authoritative.

## Tokens and typography

Noto Kufi Arabic is the UI face; Amiri carries scholarly passages and major titles. UI scale 12/14/16/20/24px, display 40–56px, scholarly line height 1.65–1.9. Spacing follows 4/8px. Borders 1px, radii 4px controls, 8px panels, 14px dialogs, arch reserved for broadcast media. Feedback 160ms ease-out, reduced-motion override.

Dark: background #071e21, surface-1 #102b2e, surface-2 #173539, surface-3 #1c3d40, border #305054, text-1 #ecf2eb, text-2 #afc2bd, text-3 #94ada7, accent #d6b571, accent-ink #14292a, danger #f39e8f, success #a5cbb6.

Light: background #f3f7f3, surfaces #ffffff/#eaf1ec/#e3ece5, border #b8cec3, text #183e37/#4e685f/#526d63, accent #826528, accent-ink #ffffff, danger #a34436, success #256546. Media remains #0c2929 with #efddb2 text in both modes. Green #006633 and blue #005b8a are restrained brand accents.

## Canonical UI map

Appearance/device: PresentationProvider, session-only state; no new storage keys. Navigation shell: MaqamShell, original navigation children and callbacks. Buttons/fields/panels/dialogs: shared mq-* CSS primitives; state-dependent legacy classes translated to token classes. Icons: inline stroke SVG, 24-unit grid, 1.75 stroke. Root accessibility/filter/motion owns precedence. Original application components own every business state, form, fetch and storage operation.

Desktop 248px right rail; tablet compact rail; mobile drawer for controls and persistent bottom tab strip. Content uses editorial headings, divided lecture/library lists, academic panels and data tables; no repeated generic card sections. Dark media arch is the visitor home visual anchor. No glow, gradient text, glass blur or decorative animation.

## Decisions and constraints

Keep DOM text and button/title selector hooks needed by existing voice commands. No invented guest entry, routes, data, downloadable files or portraits. Missing original assets must remain visible as restrained media surfaces with their original text; source paths preserved. Theme and responsive drawer state are presentational only. Screens cannot own competing token systems.

## Team feedback round — approved extension

The current brief supersedes session-only appearance: PresentationProvider is the sole theme owner; maqam_theme stores dark/light, system preference supplies the first visit, and the head bootstrap sets data-theme before paint. The same CSS-variable surfaces remain the visual authority. A 44px stroke icon next to each language button replaces the wide two-option appearance switch. All headings h1–h4 and page/section titles use exact embedded thmanyah Serif Display Medium/Bold with Amiri fallback. Noto Kufi Arabic body is unchanged. Font use/permission caveat is in docs/FONT-NOTICE.md.

New academic pages use divided lists and existing mq panel/control tokens. Homework is a full answer workspace; schedule is the official source-bound weekly prayer-slot timetable; rankings display only local recorded activity. No invented peer counts or operational metrics. Form dates use native labelled controls, explicit Asia/Riyadh instants and canonical validation. The existing desktop rail/mobile bottom navigation remains; More contains secondary routes.

## Round3 canonical additions
FeedbackProvider remains business storage owner. Round3StudentChat uses persisted student conversations; original notes have a separate More route. The source-language registry and one translation controller own platform/live/dubbing selection. Monthly calendar is superseded by Round3Timetable, preserving only real dated task events. All page/section titles retain embedded thmanyah; Amiri is for scholarly source excerpts. Native select/date controls remain OS-owned and labelled.

## Round4 authority
The round4 brief supersedes poster timetable/real-profile directory/only-actual ranking in demo mode. Five fictional teachers and sixty deterministic student records are isolated behind DEMO_MODE; original recording credits remain exact. SHOW_DEMO_BADGES controls the shared badge only. Reader vectors and normal notes live in dedicated maqam_study_v1 IndexedDB, separate from existing blob attachments and smart notes. Academic tables, scholarly Q&A, quiet reader paper and current D.2 token system remain canonical.

## Round5 note discussion extension
The note discussion is a business variant of the canonical Maajem conversation: MaajemMessage and MaajemComposer own shared message, backend-source and input presentation in both student and note chat. Existing D.2 surface/text/border/accent CSS variables remain the runtime token owners; no new palette or typography system. A quiet accent rule identifies the proposed text. Desktop opens a 680px right panel; phone opens the full viewport. The before/after comparison stacks on phones, uses Amiri for note text and preserves explicit apply/ignore. Current text, manual editing and version history stay alongside the discussion.

## Recorded video preparation repair
The existing lecture translation panel owns source preparation, stage/progress, failure and explicit retry. A language selection outside Arabic or a prepare/play tap starts the complete recording job; default Arabic visits never start transcription. The same canonical controls, inline statuses, token surfaces and Arabic labels apply on desktop/mobile and dark/light. A finished machine transcript discloses that it has not been human reviewed. Playback requires a subsequent user tap after asynchronous preparation, preserving mobile audio unlock. Absolute segment start/end times retain initial, middle and trailing silence until actual recording duration; the play control remains usable in those gaps. Authored text remains available for non-video lessons and retains its independent-reading disclosure.
