from pathlib import Path
import os
import sys
import threading
import webbrowser
import server

ROOT=Path(__file__).resolve().parent
URL='http://127.0.0.1:5000/'

def main():
    server.load_groq_environment(ROOT / ".env")
    try:
        httpd=server.create_server('127.0.0.1',5000,ROOT)
    except OSError:
        raise SystemExit('Port 5000 is busy. Close the previous local Maqam server and run again. No existing process was stopped.')
    threading.Thread(target=server.validate_groq_models,daemon=True,name='groq-model-validation').start()
    if os.environ.get('TTS_PROVIDER','').strip().lower()=='edge':
        threading.Thread(target=lambda:server._speech_capabilities(httpd.edge_speech),daemon=True,name='edge-voice-discovery').start()
    print('Current Maqam: '+URL+'\nKeep this window open. Press Ctrl+C to stop.',flush=True)
    if '--no-browser' not in sys.argv:
        timer=threading.Timer(1,lambda:webbrowser.open(URL));timer.daemon=True;timer.start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()

if __name__=='__main__':main()
