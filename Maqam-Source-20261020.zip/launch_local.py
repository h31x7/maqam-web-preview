from pathlib import Path
import sys
import threading
import webbrowser
import server

ROOT=Path(__file__).resolve().parent
URL='http://127.0.0.1:5000/'

def main():
    try:
        httpd=server.create_server('127.0.0.1',5000,ROOT)
    except OSError:
        raise SystemExit('Port 5000 is busy. Close the previous local Maqam server and run again. No existing process was stopped.')
    print('Current Maqam: '+URL+'\nKeep this window open. Press Ctrl+C to stop.',flush=True)
    if '--no-browser' not in sys.argv:
        timer=threading.Timer(1,lambda:webbrowser.open(URL));timer.daemon=True;timer.start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()

if __name__=='__main__':main()
