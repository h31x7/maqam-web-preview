"""HTTP-boundary regression tests; no production credential or external call.

HTTP streams execute the real handler in memory. The upstream transport is
mocked beneath urllib's redirect/error processing, so those policies still run.
The legacy fallback exists only to demonstrate meaningful baseline failures
before the new server factory is implemented.
"""

import ast
import contextlib
import email.message
import http.client
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import runpy
import socket
import socketserver
import tempfile
import unittest
from unittest import mock
import urllib.error
import urllib.request
import urllib.response
import uuid


APP_DIR = Path(__file__).resolve().parents[1]
TEST_TMP_ROOT = APP_DIR / "tests" / ".test-tmp"
TEST_KEY = "unit-test-provider-credential-not-a-real-key"
PUBLIC_ORIGIN = "https://maqam.test"
VISITOR = "visitor_7cfb8d16-031e-42db-9c5f-97d8de6ed335"
STUDENT = "student_50630269-c43d-4af8-9a99-2bd6cccb8af8"
CONVERSATION = "81f4fca6-039e-4aba-a35e-2039cf32679b"
LEAK_MARKER = "private-upstream-diagnostic-do-not-disclose"


class MemoryConnection:
    def __init__(self, request):
        self.incoming = io.BytesIO(request)
        self.outgoing = bytearray()

    def makefile(self, *_args, **_kwargs):
        return self.incoming

    def sendall(self, data):
        self.outgoing.extend(data)

    def settimeout(self, *_args):
        pass


class QuietLegacyServer(socketserver.TCPServer):
    def handle_error(self, *_args):
        pass


class ServerContractTests(unittest.TestCase):
    def setUp(self):
        TEST_TMP_ROOT.mkdir(exist_ok=True)
        self.folder = tempfile.TemporaryDirectory(prefix="maqam-http-test-", dir=TEST_TMP_ROOT)
        self.root = Path(self.folder.name)
        self.assertTrue(self.root.resolve().is_relative_to(TEST_TMP_ROOT.resolve()))
        self.addCleanup(self.folder.cleanup)
        (self.root / "maqamooo.html").write_text("<!doctype html><html lang=ar dir=rtl>اختبار</html>", encoding="utf-8")
        for filename in (".env", "server.py", "private.zip", "README.md", "private.json"):
            (self.root / filename).write_text("not-public-test-fixture", encoding="utf-8")
        (self.root / ".git").mkdir()
        (self.root / ".git" / "config").write_text("not-public-test-fixture", encoding="utf-8")
        (self.root / "assets").mkdir()
        (self.root / "assets" / "app.0123456789abcdef.css").write_text("body{color:#123}", encoding="utf-8")
        (self.root / "assets" / "private.py").write_text("not-public-test-fixture", encoding="utf-8")
        (self.root / "assets" / ".secret.css").write_text("not-public-test-fixture", encoding="utf-8")
        self.environ = mock.patch.dict(os.environ, {
            "DIFY_API_KEY": TEST_KEY,
            "DIFY_API_URL": "https://api.dify.ai/v1",
            "PUBLIC_ORIGIN": PUBLIC_ORIGIN,
            "PORT": "0",
        })
        self.environ.start()
        self.addCleanup(self.environ.stop)
        name = "maqam_server_test_" + uuid.uuid4().hex
        spec = importlib.util.spec_from_file_location(name, APP_DIR / "server.py")
        self.module = importlib.util.module_from_spec(spec)
        # Never allow the baseline's startup key-suffix diagnostics into output.
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            spec.loader.exec_module(self.module)
        if callable(getattr(self.module, "create_server", None)):
            self.server = self.module.create_server("127.0.0.1", 0, base_dir=self.root)
        else:
            self.module.BASE_DIR = str(self.root)
            self.server = QuietLegacyServer(("127.0.0.1", 0), self.module.MaqamProxyHandler)
        self.addCleanup(self.server.server_close)
        self.handler = type("QuietTestHandler", (self.module.MaqamProxyHandler,), {"log_message": lambda *_args: None})
        self.upstream_calls = []
        self.upstream_status = 200
        self.upstream_headers = {}
        self.upstream_body = json.dumps({
            "answer": "إجابة اختبار من المصدر",
            "conversation_id": CONVERSATION,
            "id": "message-test-id",
            "created_at": 1700000000,
        }, ensure_ascii=False).encode("utf-8")
        self.upstream_exception = None

        def transport(_handler, request):
            self.upstream_calls.append(request)
            if self.upstream_exception:
                raise self.upstream_exception
            headers = email.message.Message()
            headers["Content-Type"] = "application/json"
            for key, value in self.upstream_headers.items():
                headers[key] = value
            # A redirect target would be seen here if urllib follows it.
            if urllib.parse.urlsplit(request.full_url).hostname == "untrusted.invalid":
                response = urllib.response.addinfourl(io.BytesIO(b'{"answer":"redirected"}'), headers, request.full_url, 200)
            else:
                response = urllib.response.addinfourl(io.BytesIO(self.upstream_body), headers, request.full_url, self.upstream_status)
            response.msg = "test upstream"
            return response

        for target in ("urllib.request.HTTPSHandler.https_open", "urllib.request.HTTPHandler.http_open"):
            patch = mock.patch(target, autospec=True, side_effect=transport)
            patch.start()
            self.addCleanup(patch.stop)

    def request(self, method, path, payload=None, *, raw_body=None, headers=None):
        body = raw_body
        if body is None:
            body = b"" if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        if isinstance(body, str):
            body = body.encode("utf-8")
        fields = {"Host": "maqam.test"}
        if method == "POST":
            fields.update({"Content-Type": "application/json", "Content-Length": str(len(body)), "Origin": PUBLIC_ORIGIN})
        fields.update(headers or {})
        wire = (method + " " + path + " HTTP/1.0\r\n" + "".join(key + ": " + str(value) + "\r\n" for key, value in fields.items()) + "\r\n").encode("ascii") + body
        connection = MemoryConnection(wire)
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.handler(connection, ("127.0.0.1", 12345), self.server)
        raw = bytes(connection.outgoing)
        self.assertIn(b"\r\n\r\n", raw, "Handler did not produce an HTTP response")
        head, body = raw.split(b"\r\n\r\n", 1)
        lines = head.decode("iso-8859-1").splitlines()
        response_headers = http.client.parse_headers(io.BytesIO(("\r\n".join(lines[1:]) + "\r\n\r\n").encode("iso-8859-1")))
        return int(lines[0].split()[1]), response_headers, body

    @staticmethod
    def chat_payload(**overrides):
        return {"query": "سؤال اختبار", "user": VISITOR, "conversation_id": "", **overrides}

    def assert_safe_error(self, response, expected_status):
        status, headers, body = response
        self.assertIn(status, (expected_status,) if isinstance(expected_status, int) else expected_status)
        self.assertIn("application/json", headers.get("Content-Type", ""))
        data = json.loads(body)
        self.assertIsInstance(data.get("error"), str)
        self.assertTrue(data["error"].strip())
        self.assertFalse(data.get("success", False))
        for marker in (TEST_KEY, LEAK_MARKER, "api.dify.ai", "Traceback", "URLError", "TimeoutError"):
            self.assertFalse(marker.encode() in body, "An internal diagnostic or credential was disclosed")
        for field in ("raw", "dify_message", "details", "hint"):
            self.assertNotIn(field, data)
        self.assertIn("no-store", headers.get("Cache-Control", ""))

    def test_extreme_content_length_is_rejected_without_integer_conversion_failure(self):
        self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload(), headers={"Content-Length": "9" * 5000}), (400, 413))
        self.assertEqual(self.upstream_calls, [])

    def test_extreme_numeric_input_is_a_client_error(self):
        self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload(inputs={"number": 10 ** 1000})), 400)
        self.assertEqual(self.upstream_calls, [])

    def test_body_read_has_an_elapsed_deadline(self):
        clock = [100.0]
        class SlowBody(io.BytesIO):
            def read(self, *args):
                result = super().read(*args)
                clock[0] += 11.0
                return result
            def read1(self, *args):
                return self.read(*args)
        def makefile(connection, *_args, **_kwargs):
            return SlowBody(connection.incoming.getvalue())
        with mock.patch.object(MemoryConnection, "makefile", makefile), mock.patch("time.monotonic", side_effect=lambda: clock[0]):
            self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload()), 408)
        self.assertEqual(self.upstream_calls, [])

    def test_health_requires_the_application_file(self):
        (self.root / "maqamooo.html").unlink()
        status, _headers, body = self.request("GET", "/api/health")
        self.assertEqual(status, 503)
        self.assertEqual(json.loads(body), {"status": "unavailable"})

    def test_create_server_factory_exposes_requested_single_listener(self):
        self.assertTrue(callable(getattr(self.module, "create_server", None)), "A reusable single-port create_server factory is required")
        self.assertIsInstance(self.server, socketserver.ThreadingMixIn, "Slow chat must not monopolize static/health handling")
        self.assertEqual(self.server.server_address[0], "127.0.0.1")
        self.assertGreater(self.server.server_address[1], 0)

    def test_entrypoint_uses_port_environment_and_one_listener(self):
        listeners = []

        def fake_init(instance, address, handler, *_args, **_kwargs):
            listeners.append(address)
            instance.server_address = address
            instance.RequestHandlerClass = handler
            instance.socket = mock.Mock()

        class InlineThread:
            def __init__(self, target=None, args=(), **_kwargs):
                self.target, self.args = target, args
            def start(self):
                self.target(*self.args)

        with mock.patch.dict(os.environ, {"PORT": "54321", "DIFY_API_KEY": TEST_KEY}), \
             mock.patch("socketserver.TCPServer.__init__", fake_init), \
             mock.patch("socketserver.BaseServer.serve_forever", return_value=None), \
             mock.patch("socketserver.TCPServer.server_close", return_value=None), \
             mock.patch("threading.Thread", InlineThread), \
             contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            runpy.run_path(str(APP_DIR / "server.py"), run_name="__main__")
        self.assertEqual(listeners, [("0.0.0.0", 54321)], "Entrypoint must honor PORT and create exactly one listener")

    def test_private_files_and_directory_listings_are_404_for_get_and_head(self):
        paths = ("/.env", "/server.py", "/private.zip", "/README.md", "/private.json", "/.git/config", "/.git/", "/assets/", "/assets/private.py", "/assets/.secret.css")
        for method in ("GET", "HEAD"):
            for path in paths:
                with self.subTest(method=method, path=path):
                    status, _headers, _body = self.request(method, path)
                    self.assertEqual(status, 404)

    def test_encoded_traversal_and_nul_do_not_reach_private_files(self):
        for path in ("/%2eenv", "/assets/../.env", "/assets/%2e%2e/server.py", "/assets/%2e%2e%2f.env", "/assets/%252e%252e/server.py", "/assets/..\\server.py", "/maqamooo.html%00.py"):
            with self.subTest(path=path):
                self.assertEqual(self.request("HEAD", path)[0], 404)

    def test_asset_symlink_cannot_escape_public_root(self):
        with tempfile.TemporaryDirectory(prefix="maqam-outside-", dir=TEST_TMP_ROOT) as outside:
            private = Path(outside) / "outside.css"
            private.write_text("private-test-fixture", encoding="utf-8")
            try:
                (self.root / "assets" / "outside.css").symlink_to(private)
            except (OSError, NotImplementedError):
                self.skipTest("OS does not grant symlink creation; retain as explicit verification limit")
            self.assertEqual(self.request("HEAD", "/assets/outside.css")[0], 404)

    def test_root_and_canonical_html_are_served_for_get_and_head(self):
        for path in ("/", "/maqamooo.html"):
            with self.subTest(path=path):
                status, headers, body = self.request("GET", path)
                self.assertEqual(status, 200)
                self.assertIn("text/html", headers.get("Content-Type", ""))
                self.assertIn("اختبار".encode("utf-8"), body)
                head_status, _head_headers, head_body = self.request("HEAD", path)
                self.assertEqual(head_status, 200)
                self.assertEqual(head_body, b"")

    def test_health_exposes_status_only_and_is_not_cached(self):
        status, headers, body = self.request("GET", "/api/health")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body), {"status": "ok"})
        self.assertIn("no-store", headers.get("Cache-Control", ""))

    def test_approved_media_and_youtube_script_exceptions_only(self):
        baseline = json.loads((APP_DIR / "tests" / "csp-before-local-media.json").read_text(encoding="utf-8"))
        expected = ["media-src 'self' blob:" if directive == "media-src 'self'" else directive for directive in baseline]
        expected = [directive + " https://www.youtube.com" if directive.startswith("script-src ") else directive for directive in expected]
        expected = [directive + " https://cdnjs.cloudflare.com https://unpkg.com" if directive.startswith("connect-src ") else directive for directive in expected]
        expected.insert(next(i for i,d in enumerate(expected) if d.startswith("frame-src ")), "worker-src 'self' blob: https://cdnjs.cloudflare.com")
        _status, headers, _body = self.request("GET", "/maqamooo.html")
        self.assertEqual(headers["Content-Security-Policy"].split("; "), expected)

    def test_security_headers_apply_to_app_health_and_404(self):
        for path in ("/maqamooo.html", "/api/health", "/missing"):
            with self.subTest(path=path):
                _status, headers, _body = self.request("GET", path)
                self.assertEqual(headers.get("X-Content-Type-Options"), "nosniff")
                self.assertIn(headers.get("Referrer-Policy"), ("same-origin", "no-referrer", "strict-origin-when-cross-origin"))
                csp = headers.get("Content-Security-Policy", "")
                self.assertIn("frame-ancestors 'none'", csp)
                self.assertIn("object-src 'none'", csp)
                self.assertIn("base-uri 'self'", csp)

    def test_versioned_public_asset_can_be_cached_without_listing_its_directory(self):
        status, headers, body = self.request("GET", "/assets/app.0123456789abcdef.css")
        self.assertEqual(status, 200)
        self.assertEqual(body, b"body{color:#123}")
        policy = headers.get("Cache-Control", "")
        self.assertNotIn("no-store", policy)
        age = re.search(r"max-age=(\d+)", policy)
        self.assertIsNotNone(age)
        self.assertGreaterEqual(int(age.group(1)), 86400)

    def test_own_origin_has_at_most_one_cors_header(self):
        status, headers, _body = self.request("POST", "/api/chat", self.chat_payload())
        self.assertEqual(status, 200)
        values = headers.get_all("Access-Control-Allow-Origin", [])
        self.assertLessEqual(len(values), 1)
        self.assertNotIn("*", values)
        if values:
            self.assertEqual(values, [PUBLIC_ORIGIN])
            self.assertIn("Origin", headers.get("Vary", ""))

    def test_cross_origin_and_null_origin_are_rejected_before_upstream(self):
        for origin in ("https://untrusted.invalid", "null", "https://maqam.test.untrusted.invalid"):
            with self.subTest(origin=origin):
                self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload(), headers={"Origin": origin}), 403)
        self.assertEqual(len(self.upstream_calls), 0)

    def test_preflight_is_route_aware_and_never_wildcard(self):
        status, headers, _body = self.request("OPTIONS", "/api/chat", headers={"Origin": PUBLIC_ORIGIN, "Access-Control-Request-Method": "POST"})
        self.assertIn(status, (200, 204))
        self.assertNotIn("*", headers.get_all("Access-Control-Allow-Origin", []))
        self.assertIn(self.request("OPTIONS", "/api/chat", headers={"Origin": "https://untrusted.invalid"})[0], (403, 404))
        self.assertIn(self.request("OPTIONS", "/not-an-api", headers={"Origin": PUBLIC_ORIGIN})[0], (404, 405))

    def test_host_cannot_be_used_to_invent_an_allowed_origin(self):
        for host in ("untrusted.invalid", "maqam.test@untrusted.invalid", "https://maqam.test", "maqam.test,untrusted.invalid"):
            with self.subTest(host=host):
                status = self.request("POST", "/api/chat", self.chat_payload(), headers={"Host": host, "Origin": "https://untrusted.invalid"})[0]
                self.assertIn(status, (400, 403, 421))
        self.assertEqual(len(self.upstream_calls), 0)

    def test_oversized_body_is_rejected_before_reading_or_upstream(self):
        self.assert_safe_error(self.request("POST", "/api/chat", raw_body=b"{}", headers={"Content-Length": "16385"}), 413)
        self.assertEqual(len(self.upstream_calls), 0)

    def test_malformed_lengths_transfer_encoding_and_wrong_media_are_client_errors(self):
        cases = ({"Content-Length": "abc"}, {"Content-Length": "-1"}, {"Content-Length": "0"}, {"Transfer-Encoding": "chunked"}, {"Content-Type": "text/plain"})
        for headers in cases:
            with self.subTest(headers=headers):
                expected = (400, 411, 413) if "Content-Type" not in headers else (400, 415)
                self.assert_safe_error(self.request("POST", "/api/chat", raw_body=b"{}", headers=headers), expected)
        self.assertEqual(len(self.upstream_calls), 0)

    def test_invalid_json_utf8_shapes_and_field_types_are_400(self):
        raw_cases = (b"not-json", b"\xff", b"[]", b"null", b'"string"')
        for body in raw_cases:
            with self.subTest(kind="raw", size=len(body)):
                self.assert_safe_error(self.request("POST", "/api/chat", raw_body=body), 400)
        payloads = ({}, self.chat_payload(query=42), self.chat_payload(query=" "), self.chat_payload(query="x" * 4001), self.chat_payload(user=None), self.chat_payload(conversation_id=[]), self.chat_payload(inputs=[]))
        for index, payload in enumerate(payloads):
            with self.subTest(kind="field", index=index):
                self.assert_safe_error(self.request("POST", "/api/chat", payload), 400)
        self.assertEqual(len(self.upstream_calls), 0)

    def test_user_namespaces_and_conversation_id_syntax_are_validated(self):
        for user in ("guest_101", "student_maqam", "visitor_not-a-uuid", "admin_7cfb8d16-031e-42db-9c5f-97d8de6ed335", "x" * 512):
            with self.subTest(user=user):
                self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload(user=user)), 400)
        self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload(conversation_id="not-a-provider-uuid")), 400)
        self.assertEqual(len(self.upstream_calls), 0)

    def test_valid_visitor_and_student_identity_are_preserved_in_proxy_payload(self):
        for identity in (VISITOR, STUDENT):
            status, _headers, body = self.request("POST", "/api/chat", self.chat_payload(user=identity, conversation_id=CONVERSATION))
            self.assertEqual(status, 200)
            payload = json.loads(self.upstream_calls[-1].data)
            self.assertEqual(payload["user"], identity)
            self.assertEqual(payload["conversation_id"], CONVERSATION)
            self.assertEqual(payload["response_mode"], "blocking")
            self.assertEqual(self.upstream_calls[-1].get_header("Authorization"), "Bearer " + TEST_KEY)
            self.assertEqual(getattr(self.upstream_calls[-1], "timeout", None), 20)
            self.assertFalse(TEST_KEY.encode() in body)
            self.assertNotIn("raw", json.loads(body))

    def test_rate_limit_caps_twenty_requests_then_resets_after_sixty_seconds(self):
        with mock.patch("time.monotonic", return_value=1000) as monotonic, mock.patch("time.time", return_value=1700000000) as wall:
            for _ in range(20):
                self.assertEqual(self.request("POST", "/api/chat", self.chat_payload())[0], 200)
            response = self.request("POST", "/api/chat", self.chat_payload())
            self.assert_safe_error(response, 429)
            self.assertIsNotNone(response[1].get("Retry-After"))
            self.assertEqual(len(self.upstream_calls), 20)
            self.assertEqual(self.request("GET", "/api/health")[0], 200)
            monotonic.return_value, wall.return_value = 1061, 1700000061
            self.assertEqual(self.request("POST", "/api/chat", self.chat_payload())[0], 200)

    def test_missing_key_does_not_call_provider_or_disclose_configuration(self):
        with mock.patch.dict(os.environ, {"DIFY_API_KEY": ""}), mock.patch.object(self.module, "DIFY_API_KEY", "", create=True):
            self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload()), 503)
        self.assertEqual(len(self.upstream_calls), 0)

    def test_provider_timeout_and_connection_error_have_safe_gateway_errors(self):
        for error, status in ((socket.timeout(LEAK_MARKER), 504), (urllib.error.URLError(LEAK_MARKER), 502)):
            with self.subTest(error=type(error).__name__):
                self.upstream_exception = error
                self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload()), status)

    def test_provider_http_error_body_is_not_forwarded(self):
        self.upstream_status = 401
        self.upstream_body = json.dumps({"message": LEAK_MARKER + TEST_KEY}).encode()
        self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload()), (502, 503))

    def test_oversized_provider_response_is_a_bounded_gateway_error(self):
        self.upstream_body = json.dumps({"answer": "x" * 1048576, "conversation_id": CONVERSATION}).encode()
        self.assertGreater(len(self.upstream_body), 1048576)
        self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload()), 502)

    def test_invalid_provider_json_and_answer_schema_are_gateway_errors(self):
        for body in (b"not-json", b"[]", b'{}', b'{"answer":[]}', b'{"answer":""}'):
            with self.subTest(provider_body_length=len(body)):
                self.upstream_body = body
                self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload()), 502)

    def test_cross_origin_provider_redirect_is_rejected_without_forwarding_credentials(self):
        self.upstream_status = 302
        self.upstream_headers = {"Location": "https://untrusted.invalid/collect"}
        self.upstream_body = b"redirect-test-fixture"
        self.assert_safe_error(self.request("POST", "/api/chat", self.chat_payload()), 502)
        self.assertEqual(len(self.upstream_calls), 1, "Provider redirects must not create a second credential-bearing request")

    def test_only_real_safe_citation_fields_are_exposed(self):
        result = {
            "answer": "نص الاختبار",
            "conversation_id": CONVERSATION,
            "id": "message-test-id",
            "metadata": {"retriever_resources": [
                {"document_name": "كتاب التوحيد", "url": "https://example.org/book", "segment_content": LEAK_MARKER, "dataset_id": LEAK_MARKER},
                {"document_name": "مرجع بلا رابط", "url": "javascript:alert(1)", "score": 0.5},
                None,
                {"segment_content": LEAK_MARKER},
            ]},
            "internal": LEAK_MARKER,
        }
        self.upstream_body = json.dumps(result, ensure_ascii=False).encode("utf-8")
        status, _headers, body = self.request("POST", "/api/chat", self.chat_payload())
        self.assertEqual(status, 200)
        data = json.loads(body)
        self.assertEqual(data.get("sources"), [{"title": "كتاب التوحيد", "url": "https://example.org/book"}, {"title": "مرجع بلا رابط"}])
        self.assertFalse(LEAK_MARKER.encode() in body, "Raw retrieval/provider internals leaked")
        self.assertNotIn("raw", data)

    def test_no_citations_are_invented_when_provider_returns_none(self):
        status, _headers, body = self.request("POST", "/api/chat", self.chat_payload())
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body).get("sources"), [])

    def test_source_has_no_embedded_provider_key_default_or_alternate_provider(self):
        source = (APP_DIR / "server.py").read_text(encoding="utf-8")
        # Boolean assertions avoid unittest echoing an entire credential-bearing file.
        self.assertFalse(bool(re.search(r"app-[A-Za-z0-9_-]{16,}", source)), "Embedded provider credential remains in server source")
        tree = ast.parse(source)
        secret_defaults = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "get" and len(node.args) > 1:
                first, second = node.args[:2]
                if isinstance(first, ast.Constant) and first.value == "DIFY_API_KEY" and isinstance(second, ast.Constant) and second.value:
                    secret_defaults.append(True)
        self.assertFalse(secret_defaults, "Provider key must not have a nonempty source fallback")
        self.assertFalse("handle_gemini_chat" in source, "Unused alternate provider/fabricated fallback remains")


if __name__ == "__main__":
    unittest.main(verbosity=2)
