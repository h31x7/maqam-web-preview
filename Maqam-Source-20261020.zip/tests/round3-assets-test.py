import hashlib,json,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def read(name):return json.loads((ROOT/'data'/name).read_text(encoding='utf-8'))
class Assets(unittest.TestCase):
 def test_catalog_identity(self):
  rows=read('lectures.json');self.assertEqual(len(rows),16)
  self.assertEqual([r['videoId'] for r in rows if r['primary']],['uJENBxFnDbU','C5b3LdzYkEc','a06RUwUDem0','LxunR94uQJ4','P9TetTCd0hY','_4X9iyHSzNk','whVWVKZeItI'])
  for row in rows:
   self.assertNotIn('duration',row);self.assertNotIn('date',row)
   if not row['primary']:self.assertIsNone(row['videoId'])
 def test_source_counts(self):
  self.assertEqual(len(read('quizzes.json')),45)
  self.assertEqual(sum(len(r['points']) for r in read('summaries.json')),81)
  for q in read('quizzes.json'):self.assertEqual(len(q['options']),4);self.assertIn(q['correctIndex'],range(4))
  self.assertEqual(len(read('haram-schedule.json')),12)
 def test_language_source_identity(self):
  rows=read('languages.json');self.assertEqual(len(rows),172)
  self.assertEqual(len({r['name'] for r in rows}),172)
  self.assertEqual(sum(r['sourceCode']=='gd' for r in rows),2)
  sub=read('subtitles-unverified.json');self.assertIsNone(sub['videoId']);self.assertEqual(len(sub['segments']),27)
  self.assertEqual(sum(s['duration'] for s in sub['segments']),186)
 def test_original_assets(self):
  logo=ROOT/'assets/brand/maqam.png';self.assertEqual(hashlib.sha256(logo.read_bytes()).hexdigest(),'e2edc8f8672902355433c079703fe8d14c7e05565a0b50fc4b36b22fd668bdb3')
  books=read('books.json');self.assertEqual(len(books),7);self.assertEqual(sum(b['pages'] for b in books),3639)
  for b in books:
   self.assertEqual(hashlib.sha256((ROOT/b['pdf'].lstrip('/')).read_bytes()).hexdigest(),b['sha256'])
   self.assertTrue((ROOT/b['cover'].lstrip('/')).is_file())
 def test_text_preservation(self):
  source=ROOT.parents[1]/'work/round3/assets'
  originals=json.loads((source/'summaries-parsed-audit.json').read_text(encoding='utf-8'))
  for actual,original in zip(read('summaries.json'),originals):
   for field in ('lectureRef','file','title','points'):self.assertEqual(actual[field],original[field])
   self.assertEqual(actual['sourceSha256'],hashlib.sha256((source/original['file']).read_bytes()).hexdigest())
  groups=json.loads((source/'quiz-parsed-audit.json').read_text(encoding='utf-8'))
  for actual,original in zip(read('quizzes.json'),[q for g in groups for q in g['questions']]):
   for field in ('id','lectureRef','question','options','correctIndex'):self.assertEqual(actual[field],original[field])
  reviewed=json.loads((source.parent/'schedule-reviewed.json').read_text(encoding='utf-8'))
  self.assertEqual(read('haram-schedule.json'),reviewed)
if __name__=='__main__':unittest.main()


