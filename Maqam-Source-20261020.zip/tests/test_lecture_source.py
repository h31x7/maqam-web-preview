import importlib.util
import pathlib
import tempfile
import unittest
from unittest import mock

spec = importlib.util.spec_from_file_location('video_server', pathlib.Path(__file__).resolve().parents[1] / 'server.py')
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)

class VideoSourceTests(unittest.TestCase):
    def test_only_registered_exact_schema(self):
        self.assertEqual(s._lecture_video({'videoId':'uJENBxFnDbU'}, {'uJENBxFnDbU'}), 'uJENBxFnDbU')
        for value in ({'videoId':'https://youtube.com/x'}, {'videoId':'uJENBxFnDbU','url':'x'}, {'videoId':'AAAAAAAAAAA'}):
            with self.assertRaises(ValueError): s._lecture_video(value, {'uJENBxFnDbU'})

    def test_media_url_restrictions_and_private_resolution(self):
        for url in ('http://r.googlevideo.com/a','https://googlevideo.com.evil/a','https://u:p@r.googlevideo.com/a','https://r.googlevideo.com:444/a','https://127.0.0.1/a'):
            with self.assertRaises(s.LectureSourceFailure): s._lecture_media_target(url)
        with mock.patch.object(s.socket, 'getaddrinfo', return_value=[(2,1,6,'',('127.0.0.1',443))]):
            with self.assertRaises(s.LectureSourceFailure): s._lecture_media_target('https://r.googlevideo.com/a')

    def test_offsets_and_gaps_are_preserved(self):
        rows=s._lecture_rows({'duration':600,'segments':[{'start':2,'end':4,'text':'مرحبا'},{'start':9,'end':10,'text':'العلم'}]},600,600)
        self.assertEqual([(r['start'],r['end']) for r in rows], [(602,604),(609,610)])
        for rows in ([{'start':-1,'end':2,'text':'x'}],[{'start':1,'end':601,'text':'x'}],[{'start':3,'end':4,'text':'x'},{'start':2,'end':3,'text':'x'}]):
            with self.assertRaises(s.LectureSourceFailure): s._lecture_rows({'duration':600,'segments':rows},0,600)

    def test_job_deduplication_bounds_and_safe_failures(self):
        gate=__import__('threading').Event()
        def prepare(video, progress):
            gate.wait(2)
            raise RuntimeError('signed URL and secret diagnostic')
        with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parents[1] / 'work') as tmp:
            jobs=s.LectureSourceJobs({'uJENBxFnDbU','AAAAAAAAAAA'}, prepare=prepare, cache_dir=pathlib.Path(tmp))
            first=jobs.submit('uJENBxFnDbU')
            self.assertEqual(first['jobId'],jobs.submit('uJENBxFnDbU')['jobId'])
            with self.assertRaises(s.LectureSourceFailure): jobs.submit('AAAAAAAAAAA')
            gate.set()
            jobs.worker.join(3)
            result=jobs.snapshot(first['jobId'])
            self.assertEqual(result['status'],'failed')
            self.assertNotIn('secret',str(result))
            self.assertNotIn('signed',str(result))

    def test_multipart_fixed_model(self):
        body, content_type=s._lecture_multipart(b'ID3audio')
        self.assertIn(b'whisper-large-v3',body)
        self.assertIn(b'verbose_json',body)
        self.assertIn(b'timestamp_granularities[]',body)
        self.assertIn(b'ID3audio',body)
        self.assertIn('multipart/form-data; boundary=', content_type)

if __name__ == '__main__': unittest.main()

class SourceHttpTests(unittest.TestCase):
    from test_server import ServerContractTests as Harness
    setUp = Harness.setUp
    request = Harness.request

    def test_source_post_exact_schema_origin_and_framing(self):
        self.server.lecture_sources.registered={'uJENBxFnDbU'}
        with mock.patch.object(self.server.lecture_sources,'submit',return_value={'jobId':'00000000-0000-4000-8000-000000000000','status':'queued'}):
            self.assertEqual(self.request('POST','/api/lecture-source',{'videoId':'uJENBxFnDbU'})[0],202)
            for payload in ({'videoId':'uJENBxFnDbU','url':'x'},{'videoId':'AAAAAAAAAAA'}):
                self.assertEqual(self.request('POST','/api/lecture-source',payload)[0],400)
            self.assertEqual(self.request('POST','/api/lecture-source',{'videoId':'uJENBxFnDbU'},headers={'Origin':''})[0],403)
            self.assertEqual(self.request('POST','/api/lecture-source',{'videoId':'uJENBxFnDbU'},headers={'Transfer-Encoding':'chunked'})[0],400)

    def test_source_get_browser_poll_no_origin_and_wrong_origin_rejected(self):
        import json
        key='00000000-0000-4000-8000-000000000000'
        with mock.patch.object(self.server.lecture_sources,'snapshot',return_value={'jobId':key,'status':'processing'}):
            self.assertEqual(self.request('GET','/api/lecture-source?jobId='+key)[0],200)
            self.assertEqual(self.request('GET','/api/lecture-source?jobId='+key,headers={'Origin':'https://evil.example'})[0],403)
            self.assertEqual(self.request('GET','/api/lecture-source?jobId='+key,headers={'Sec-Fetch-Site':'cross-site'})[0],403)
            for query in ('','?jobId=bad','?jobId='+key+'&jobId='+key,'?jobId='+key+'&url=x'):
                self.assertEqual(self.request('GET','/api/lecture-source'+query)[0],400)
        with mock.patch.object(self.server.lecture_sources,'snapshot',return_value=None):
            self.assertEqual(json.loads(self.request('GET','/api/lecture-source?jobId='+key)[2])['code'],'source_job_expired')

class SourcePipelineTests(unittest.TestCase):
    def source(self):
        return {'videoId':'uJENBxFnDbU','alignmentVerified':True,'source':'whisper-large-v3','sourceSha256':'a'*64,'duration':1200,'transcriptReviewed':False,'segments':[{'start':2,'end':5,'duration':3,'ar':'نص'}]}

    def test_completed_jobs_restore_and_expire_without_audio(self):
        import time
        with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parents[1] / 'work') as tmp:
            jobs=s.LectureSourceJobs({'uJENBxFnDbU'}, prepare=lambda *_:self.source(), cache_dir=pathlib.Path(tmp))
            job=jobs.submit('uJENBxFnDbU'); jobs.worker.join(3)
            self.assertEqual(jobs.snapshot(job['jobId'])['status'],'completed')
            restored=s.LectureSourceJobs({'uJENBxFnDbU'},cache_dir=pathlib.Path(tmp))
            self.assertEqual(restored.submit('uJENBxFnDbU')['jobId'],job['jobId'])
            with mock.patch.object(s.time,'time',return_value=time.time()+s.LECTURE_CACHE_TTL+1):
                self.assertIsNone(restored.snapshot(job['jobId']))

    def test_full_multi_chunk_pipeline_preserves_last_chunk_and_actual_hash(self):
        import hashlib
        import sys
        import types
        directory_seen=[]
        def process(args,directory,deadline,name,maximum=0):
            import json
            directory_seen.append(directory)
            target=directory/name
            if name=='metadata.json':
                target.write_text(json.dumps({'id':'uJENBxFnDbU','duration':1200,'vcodec':'none','acodec':'aac','url':'https://r.googlevideo.com/a'}))
            else:
                (directory/'chunks.csv').write_text('chunk-000.mp3,0,600\nchunk-001.mp3,600,1200\n')
                (directory/'chunk-000.mp3').write_bytes(b'chunk1')
                (directory/'chunk-001.mp3').write_bytes(b'chunk2')
                target.write_bytes(b'')
            return target
        fake=types.SimpleNamespace(get_ffmpeg_exe=lambda:'ffmpeg')
        with mock.patch.dict(sys.modules,{'imageio_ffmpeg':fake}),mock.patch.object(s,'_lecture_process',side_effect=process),mock.patch.object(s,'LectureMediaBridge') as bridge,mock.patch.object(s,'_lecture_transcribe',return_value={'duration':600,'segments':[{'start':3,'end':5,'text':'نص'}]}),mock.patch.object(tempfile,'tempdir',str(pathlib.Path(__file__).resolve().parents[1]/'work')):
            bridge.return_value.__enter__.return_value.failure=None
            result=s._lecture_prepare('uJENBxFnDbU',lambda *_:None)
        self.assertEqual(result['duration'],1200)
        self.assertEqual(result['sourceSha256'],hashlib.sha256(b'chunk1chunk2').hexdigest())
        self.assertEqual(result['segments'][-1]['start'],603)
        self.assertFalse(result['transcriptReviewed'])
        self.assertFalse(directory_seen[0].exists())

    def test_provider_fixed_route_multipart_and_no_response_leaks(self):
        import io
        import urllib.error
        with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parents[1]/'work') as tmp:
            path=pathlib.Path(tmp)/'chunk.mp3'; path.write_bytes(b'ID3audio')
            response=mock.MagicMock(); response.__enter__.return_value=response
            response.getcode.return_value=200; response.read1.side_effect=[b'{"duration":10,"segments":[]}',b'']
            opener=mock.Mock(); opener.open.return_value=response
            with mock.patch.object(s,'_groq_key',return_value='unit-test-only'),mock.patch.object(s.urllib.request,'build_opener',return_value=opener):
                s._lecture_transcribe(path,s.time.monotonic()+60)
            request=opener.open.call_args.args[0]
            self.assertEqual(request.full_url,'https://api.groq.com/openai/v1/audio/transcriptions')
            self.assertIn(b'whisper-large-v3',request.data)
            self.assertIn(b'name="language"\r\n\r\nar',request.data)

    def test_segment_and_text_limits_reject_no_truncation(self):
        with self.assertRaises(s.LectureSourceFailure):
            s._lecture_rows({'duration':600,'segments':[{'start':0,'end':1,'text':'x'*16001}]},0,600)
        with self.assertRaises(s.LectureSourceFailure):
            s._lecture_rows({'duration':600,'segments':[{'start':0,'end':1,'text':'x'}]*2001},0,600)

class StreamBridgeTests(unittest.TestCase):
    def test_private_bridge_url_streams_ranges_and_rejects_other_paths(self):
        import urllib.request
        import contextlib
        class Response:
            status=206
            def getheader(self,name,default=None):
                return {'Content-Length':'4','Content-Range':'bytes 3-6/10'}.get(name,default)
            def read1(self,size):
                value=getattr(self,'body',b'data'); self.body=b''; return value
        @contextlib.contextmanager
        def upstream(url,deadline,byte_range=None):
            self.assertEqual(byte_range,'bytes=3-6')
            yield Response()
        with mock.patch.object(s,'_lecture_open_media',side_effect=upstream,create=True):
            self.assertTrue(hasattr(s,'LectureMediaBridge'),'A private streaming bridge must replace complete source downloads')
            with s.LectureMediaBridge('https://r.googlevideo.com/audio',s.time.monotonic()+10) as bridge:
                request=urllib.request.Request(bridge.url,headers={'Range':'bytes=3-6'})
                with urllib.request.urlopen(request) as response:
                    self.assertEqual(response.status,206)
                    self.assertEqual(response.headers['Content-Range'],'bytes 3-6/10')
                    self.assertEqual(response.read(),b'data')
                with self.assertRaises(urllib.error.HTTPError):
                    urllib.request.urlopen(bridge.url+'/wrong')
            self.assertEqual(bridge.transferred,4)

    def test_bridge_rejects_out_of_budget_content_range_before_streaming(self):
        import contextlib
        import urllib.request
        class Response:
            status=206
            def getheader(self,name,default=None):
                return {'Content-Length':'4','Content-Range':f'bytes 0-3/{s.LECTURE_MAX_BYTES+1}'}.get(name,default)
            def read1(self,size):
                raise AssertionError('Oversize source must not be read')
        @contextlib.contextmanager
        def upstream(*args): yield Response()
        with mock.patch.object(s,'_lecture_open_media',side_effect=upstream,create=True):
            self.assertTrue(hasattr(s,'LectureMediaBridge'),'A private streaming bridge must enforce source bounds')
            with s.LectureMediaBridge('https://r.googlevideo.com/audio',s.time.monotonic()+10) as bridge:
                with self.assertRaises(urllib.error.HTTPError): urllib.request.urlopen(bridge.url)
                self.assertEqual(bridge.failure.code,'source_size_limit')

class BridgeConcurrencyRegressionTests(unittest.TestCase):
    def test_second_seek_can_open_while_first_read_is_waiting(self):
        import contextlib, threading, urllib.request
        first_entered, second_entered = threading.Event(), threading.Event()
        class Response:
            status=206
            def __init__(self, first): self.first=first; self.done=False
            def getheader(self,name,default=None):
                return {'Content-Length':'4','Content-Range':'bytes 0-3/10' if self.first else 'bytes 3-6/10'}.get(name,default)
            def read1(self,size):
                if self.done:return b''
                self.done=True
                if self.first:first_entered.set();second_entered.wait(2)
                return b'data'
        @contextlib.contextmanager
        def upstream(url,deadline,byte_range=None):
            first=byte_range=='bytes=0-3'
            if not first:second_entered.set()
            yield Response(first)
        errors=[]
        with mock.patch.object(s,'_lecture_open_media',side_effect=upstream):
            with s.LectureMediaBridge('https://r.googlevideo.com/audio',s.time.monotonic()+6) as bridge:
                def first_read():
                    try:
                        with urllib.request.urlopen(urllib.request.Request(bridge.url,headers={'Range':'bytes=0-3'}),timeout=3) as r:r.read()
                    except Exception as e:errors.append(type(e).__name__)
                t=threading.Thread(target=first_read);t.start()
                self.assertTrue(first_entered.wait(2))
                try:
                    with urllib.request.urlopen(urllib.request.Request(bridge.url,headers={'Range':'bytes=3-6'}),timeout=.7) as r:self.assertEqual(r.read(),b'data')
                finally:second_entered.set();t.join(3)
                self.assertFalse(errors)

    def test_process_timeout_preserves_safe_error_without_external_taskkill(self):
        import sys,time
        with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parents[1]/'work') as tmp:
            with self.assertRaises(s.LectureSourceFailure) as caught:
                s._lecture_process([sys.executable,'-c','import time; time.sleep(5)'],pathlib.Path(tmp),time.monotonic()+.1,'out.txt')
            self.assertEqual(caught.exception.code,'source_timeout')

class BoundedUpstreamRangeTests(unittest.TestCase):
    def test_open_ended_demuxer_reads_are_fetched_in_bounded_ranges(self):
        import contextlib,urllib.request
        calls=[]; audio=b'abcdefghij'
        class Response:
            status=206
            def __init__(self,start,end):self.start=start;self.end=min(end,len(audio)-1);self.body=audio[start:self.end+1]
            def getheader(self,name,default=None):return {'Content-Length':str(len(self.body)),'Content-Range':f'bytes {self.start}-{self.end}/{len(audio)}'}.get(name,default)
            def read1(self,n):value=self.body[:n];self.body=self.body[n:];return value
        @contextlib.contextmanager
        def upstream(url,deadline,byte_range=None):
            calls.append(byte_range)
            self.assertRegex(byte_range,r'^bytes=[0-9]+-[0-9]+$')
            start,end=map(int,byte_range[6:].split('-'))
            self.assertLessEqual(end-start+1,4)
            yield Response(start,end)
        with mock.patch.object(s,'LECTURE_NETWORK_WINDOW',4,create=True),mock.patch.object(s,'_lecture_open_media',side_effect=upstream):
            with s.LectureMediaBridge('https://r.googlevideo.com/audio',s.time.monotonic()+5) as bridge:
                with urllib.request.urlopen(urllib.request.Request(bridge.url,headers={'Range':'bytes=0-'}),timeout=3) as r:
                    self.assertEqual(r.read(),audio)
                    self.assertEqual(r.headers['Content-Range'],'bytes 0-9/10')
                self.assertEqual(len(calls),3)

class WhisperSilenceRegressionTests(unittest.TestCase):
    def test_real_empty_text_intervals_remain_silent_absolute_gaps(self):
        rows=s._lecture_rows({'duration':30,'segments':[{'start':0,'end':4,'text':'أهلا'},{'start':4,'end':12,'text':''},{'start':12,'end':16,'text':'العلم'}]},600,30)
        self.assertEqual([(r['start'],r['end']) for r in rows],[(600,604),(612,616)])
        self.assertEqual([r['ar'] for r in rows],['أهلا','العلم'])

class PreparedRecordingCacheTests(unittest.TestCase):
    def test_actual_validated_bundled_source_is_reused_without_new_asr(self):
        import json
        with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parents[1]/'work') as tmp:
            directory=pathlib.Path(tmp);prepared=directory/'prepared';prepared.mkdir()
            source=SourcePipelineTests().source()
            (prepared/'uJENBxFnDbU.json').write_text(json.dumps(source),encoding='utf-8')
            jobs=s.LectureSourceJobs({'uJENBxFnDbU'},cache_dir=directory/'cache',prepared_dir=prepared)
            job=jobs.submit('uJENBxFnDbU')
            self.assertEqual(job['status'],'completed');self.assertEqual(job['source']['duration'],1200)
            self.assertIsNone(jobs.worker)

class ContinuousSpeechRateTests(unittest.TestCase):
    def test_edge_allows_sentence_prefetch_without_weakening_groq_limits(self):
        for provider,allowed in [('edge',120),('groq',20)]:
            with mock.patch.dict(s.os.environ,{'TTS_PROVIDER':provider}):
                app=s.create_server('127.0.0.1',0)
            try:
                for index in range(allowed):self.assertTrue(app.groq_limiter.admit('test-client')[0],(provider,index))
                self.assertFalse(app.groq_limiter.admit('test-client')[0])
            finally:app.server_close()
