"""Round 3 public manifest and PDF byte-range HTTP contract."""
from pathlib import Path
import unittest
import test_server


class Round3StaticTests(unittest.TestCase):
    setUp = test_server.ServerContractTests.setUp
    request = test_server.ServerContractTests.request

    def put(self, path, content=b'0123456789'):
        target = self.root / path.lstrip('/')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        return target

    def test_explicit_data_and_book_paths_only(self):
        public_paths = [f'/data/{name}.json' for name in ('languages', 'books', 'lectures', 'quizzes', 'summaries', 'haram-schedule', 'subtitles-unverified')]
        public_paths += [f'/assets/brand/{name}.png' for name in ('maqam', 'favicon-32', 'favicon-192', 'touch-icon', 'apple-touch-icon')]
        for number in range(1, 10):
            public_paths += [f'/assets/books/book-{number}.pdf', f'/assets/book-covers/book-{number}.png', f'/data/book-indexes/book-{number}.json']
        for path in public_paths:
            self.put(path)
            self.assertEqual(self.request('GET', path)[0], 200, path)
        for path in ('/data/private.json', '/data/book-indexes/book-10.json', '/assets/books/private.pdf', '/assets/books/secret.png', '/assets/book-covers/private.png', '/assets/brand/private.png'):
            self.put(path)
            self.assertEqual(self.request('GET', path)[0], 404, path)

    def test_reserved_paths_reject_separator_and_case_aliases(self):
        for directory in ('books', 'book-covers', 'brand'):
            self.put(f'/assets/{directory}/private.png', b'PRIVATE')
            for alias in (f'/assets//{directory}/private.png', f'/assets/{directory.upper()}/private.png', f'/assets/{directory}./private.png', f'/assets/{directory}%20/private.png'):
                for method in ('GET', 'HEAD'):
                    with self.subTest(path=alias, method=method):
                        self.assertEqual(self.request(method, alias)[0], 404)

    def test_full_and_single_pdf_ranges_and_head(self):
        path = '/assets/books/book-1.pdf'
        self.put(path)
        for value, status, expected, content_range in ((None, 200, b'0123456789', None), ('bytes=2-4', 206, b'234', 'bytes 2-4/10'), ('bytes=7-', 206, b'789', 'bytes 7-9/10'), ('bytes=-3', 206, b'789', 'bytes 7-9/10'), ('bytes=8-99', 206, b'89', 'bytes 8-9/10'), ('bytes=-99', 206, b'0123456789', 'bytes 0-9/10')):
            for method in ('GET', 'HEAD'):
                with self.subTest(value=value, method=method):
                    response, headers, body = self.request(method, path, headers={} if value is None else {'Range': value})
                    self.assertEqual(response, status)
                    self.assertEqual(headers['Content-Type'], 'application/pdf')
                    self.assertEqual(headers['Accept-Ranges'], 'bytes')
                    self.assertEqual(headers.get('Content-Range'), content_range)
                    self.assertEqual(int(headers['Content-Length']), len(expected))
                    self.assertEqual(body, b'' if method == 'HEAD' else expected)
                    self.assertEqual(headers['X-Content-Type-Options'], 'nosniff')

    def test_range_reads_only_requested_slice_of_large_pdf(self):
        data = b'%PDF-1.7\n' + bytes(range(256)) * 16384
        path = '/assets/books/book-7.pdf'
        self.put(path, data)
        start, end = 3_000_001, 3_065_539
        status, headers, body = self.request('GET', path + '?reader=1', headers={'Range': f'bytes={start}-{end}'})
        self.assertEqual(status, 206)
        self.assertEqual(body, data[start:end + 1])
        self.assertEqual(int(headers['Content-Length']), end - start + 1)

    def test_invalid_pdf_ranges_are_bounded_and_rejected(self):
        path = '/assets/books/book-1.pdf'
        self.put(path)
        for value in ('bytes=10-', 'bytes=4-2', 'bytes=-0', 'bytes=', 'bytes=0-1,3-4', 'items=0-1', 'bytes=+1-2', 'bytes=0-' + '9' * 5000, 'bytes=0-1\r\nRange: bytes=2-3'):
            for method in ('GET', 'HEAD'):
                with self.subTest(value=value[:40], method=method):
                    status, headers, body = self.request(method, path, headers={'Range': value})
                    self.assertEqual(status, 416)
                    self.assertEqual(headers['Content-Range'], 'bytes */10')
                    self.assertEqual(headers['Accept-Ranges'], 'bytes')
                    if method == 'HEAD':
                        self.assertEqual(body, b'')
        self.put(path, b'')
        self.assertEqual(self.request('GET', path, headers={'Range': 'bytes=0-'})[0], 416)

    def test_manifest_cannot_be_used_for_traversal_or_symlinks(self):
        path = '/assets/books/book-1.pdf'
        target = self.put(path)
        for request_path in ('/assets/books/../books/book-1.pdf', '/assets/books/%2e%2e/books/book-1.pdf', '/data/%252e%252e/books.json', '/assets/books/book-1.pdf/extra'):
            self.assertEqual(self.request('GET', request_path)[0], 404)
        target.unlink()
        private = self.put('/private.pdf', b'PRIVATE')
        try:
            target.symlink_to(private)
        except (OSError, NotImplementedError):
            self.skipTest('Creating symlinks is unavailable on this host')
        self.assertEqual(self.request('GET', path)[0], 404)


if __name__ == '__main__':
    unittest.main()
