const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const html = fs.readFileSync(path.join(__dirname, '..', 'maqamooo.html'), 'utf8');
function markdownRuntime(tokens, actualMarked) {
  const block = html.match(/\/\/ MAQAM_SAFE_MARKDOWN_START([\s\S]*?)\/\/ MAQAM_SAFE_MARKDOWN_END/);
  assert.ok(block, 'Strict React Markdown renderer is present');
  const React = {createElement(type, props, ...children) {return {type, props: props || {}, children};}};
  const ctx = {React, URL, window: {marked: actualMarked || {lexer: () => tokens}}};
  vm.runInNewContext(block[1] + '\nthis.renderSafeMarkdown = renderSafeMarkdown; this.safeMarkdownUrl = safeMarkdownUrl;', ctx);
  return ctx;
}
function allNodes(value, rows = []) {
  if (Array.isArray(value)) value.forEach(v => allNodes(v, rows));
  else if (value && typeof value === 'object') {rows.push(value); allNodes(value.children, rows);}
  return rows;
}
test('No browser AI secret or direct Dify request remains', () => {
  assert.ok(!/api\.dify\.ai/.test(html), 'Browser must use only the same-origin chat proxy');
  assert.ok(!/['"]Authorization['"]\s*:\s*['"]Bearer\s+[^'"\s]+/.test(html), 'No browser credential header');
  assert.ok(!/\bapp-[A-Za-z0-9]{12,}\b/.test(html), 'No real app credential string');
});
test('Every versionable CDN script is exact-version pinned and integrity checked', () => {
  const scripts = [...html.matchAll(/<script\b([^>]*\bsrc="([^"]+)"[^>]*)>/g)];
  assert.equal(scripts.length, 6, 'Five versionable scripts plus the Google integration');
  for (const [,attrs,src] of scripts) {
    if (src.startsWith('https://translate.google.com/translate_a/element.js?')) continue;
    assert.ok(/(?:\/18\.2\.0\/|@7\.28\.5\/|@17\.0\.5\/|\/assets\/vendor\/tailwind\.3\.4\.17\.[a-f0-9]{12}\.js$)/.test(src), 'Unexpected unpinned CDN URL');
    assert.ok(/integrity="sha384-[A-Za-z0-9+/=]+"/.test(attrs), 'Missing SHA384 integrity');
    assert.ok(/crossorigin="anonymous"/.test(attrs), 'Missing anonymous CORS for SRI');
  }
});
test('Untrusted Markdown has no HTML injection sink', () => {
  const render = html.slice(html.indexOf('const renderFormattedText ='), html.indexOf('const renderFormattedText =') + 1800);
  assert.ok(!render.includes('dangerouslySetInnerHTML'), 'Chat text must become React elements, never HTML injection');
  assert.ok(render.includes('renderSafeMarkdown'), 'Chat renderer uses shared strict renderer');
});
test('Raw HTML and unknown tokens become inert text, never attributes or scripts', () => {
  const payload = '<img src=x onerror=alert(1)><script>alert(1)</script><svg onload=alert(1)>';
  const ctx = markdownRuntime([{type:'html',text:payload},{type:'unknown',raw:payload}]);
  const result = ctx.renderSafeMarkdown(payload);
  const nodes = allNodes(result);
  assert.ok(nodes.every(n => !['script','img','svg','iframe','object','style'].includes(n.type)));
  assert.ok(nodes.every(n => !Object.keys(n.props).some(p => /^on|dangerouslySetInnerHTML|style$/i.test(p))));
  assert.ok(JSON.stringify(result).includes(payload), 'Attack remains only text content');
});
test('Dangerous Markdown link protocols and encoded scheme tricks never become hrefs', () => {
  const hrefs=['javascript:alert(1)','JaVaScRiPt:alert(1)','java\nscript:alert(1)','data:text/html,<svg onload=alert(1)>','vbscript:msgbox(1)','file:///secret','//evil.example','javascript&#58;alert(1)','&#x6a;avascript:alert(1)','javascript%3Aalert(1)','\\\\evil.example'];
  const ctx=markdownRuntime(hrefs.map(href=>({type:'paragraph',tokens:[{type:'link',href,tokens:[{type:'text',text:'اختبار'}]}]})));
  assert.ok(allNodes(ctx.renderSafeMarkdown('input')).every(n => !n.props.href), 'Unsafe href is absent');
  for (const href of hrefs) assert.equal(ctx.safeMarkdownUrl(href), null);
});
test('Scholarly Markdown formatting and safe links survive the allowlist', () => {
  const ctx=markdownRuntime([
    {type:'heading',depth:3,tokens:[{type:'text',text:'عنوان'}]},
    {type:'paragraph',tokens:[{type:'strong',tokens:[{type:'text',text:'نص'}]},{type:'em',tokens:[{type:'text',text:'مائل'}]},{type:'codespan',text:'code'},{type:'link',href:'https://example.org/source',tokens:[{type:'text',text:'المصدر'}]}]},
    {type:'blockquote',tokens:[{type:'paragraph',tokens:[{type:'text',text:'اقتباس'}]}]},
    {type:'list',ordered:true,start:2,items:[{tokens:[{type:'text',text:'قائمة'}]}]},
    {type:'code',text:'const x = "<script>";'},
    {type:'table',header:[{tokens:[{type:'text',text:'عنوان'}]}],rows:[[{tokens:[{type:'text',text:'خلية'}]}]]}
  ]);
  const nodes=allNodes(ctx.renderSafeMarkdown('input'));
  for (const type of ['h3','strong','em','code','a','blockquote','ol','li','pre','table','th','td']) assert.ok(nodes.some(n=>n.type===type), type+' preserved');
  const link=nodes.find(n=>n.type==='a');assert.equal(link.props.href,'https://example.org/source');assert.equal(link.props.rel,'noopener noreferrer');
});
test('Remote images never load and missing Markdown library fails to escaped text', () => {
  const ctx=markdownRuntime([{type:'image',href:'https://tracker.invalid/pixel',text:'وصف'}]);
  assert.ok(!allNodes(ctx.renderSafeMarkdown('input')).some(n=>n.type==='img'));
  ctx.window.marked=null;
  assert.equal(ctx.renderSafeMarkdown('<script>alert(1)</script>'),'<script>alert(1)</script>');
});

test('Real pinned marked lexer output preserves scholarly formatting without executable HTML', () => {
  const library={};vm.runInNewContext(fs.readFileSync(path.join(__dirname,'vendor','marked-17.0.5.umd.js'),'utf8'),library);
  const markdown='# عنوان عربي\n\n**نص مؤكد** و *نص مائل*\n\n> اقتباس\n\n1. بند أول\n2. بند ثان\n\n[مصدر](https://example.org/book)\n\n[خبيث](javascript:alert(1))\n\n![صورة](https://tracker.invalid/pixel)\n\n<img src=x onerror=alert(1)>\n\n<script>alert(1)</script>\n\n| عنوان | آخر |\n| --- | --- |\n| خلية | قيمة |';
  const ctx=markdownRuntime(null,library.marked),nodes=allNodes(ctx.renderSafeMarkdown(markdown));
  for(const type of ['h1','strong','em','blockquote','ol','li','table','th','td']) assert.ok(nodes.some(n=>n.type===type),type+' rendered from actual lexer');
  assert.ok(nodes.every(n=>!['img','script','svg','iframe','object','style'].includes(n.type)));
  assert.ok(nodes.every(n=>!Object.keys(n.props).some(p=>/^on|dangerouslySetInnerHTML|style$/i.test(p))));
  assert.ok(nodes.filter(n=>n.type==='a').every(n=>n.props.href==='https://example.org/book'));
});

test('Pinned CDN integrity is the audited byte digest, not an arbitrary SRI string', () => {
  const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'vendor','cdn-integrity.json'),'utf8'));
  for(const item of Object.values(manifest)) {
    const script=[...html.matchAll(/<script\b([^>]*\bsrc="([^"]+)"[^>]*)>/g)].find(m=>m[2]===(item===manifest.tailwind ? '/assets/vendor/tailwind.3.4.17.176e894661aa.js' : item.src));
    assert.ok(script, 'Expected audited CDN source is present');
    assert.ok(script[1].includes('integrity="'+item.integrity+'"'), 'CDN integrity matches audited bytes');
  }
  const digest='sha384-'+require('node:crypto').createHash('sha384').update(fs.readFileSync(path.join(__dirname,'vendor','marked-17.0.5.umd.js'))).digest('base64');
  assert.equal(digest,manifest.marked.integrity,'Test lexer is byte-identical to pinned browser lexer');
});

function identityRuntime(initial = {}, options = {}) {
  const block=html.match(/\/\/ MAQAM_ANONYMOUS_ID_START([\s\S]*?)\/\/ MAQAM_ANONYMOUS_ID_END/);
  assert.ok(block, 'Anonymous identity helper is present');
  const values=new Map(Object.entries(initial));let generated=0;
  const storage={getItem(key){if(options.readFails)throw Error('Storage denied');return values.get(key)??null;},setItem(key,value){if(options.writeFails)throw Error('Storage full');values.set(key,value);},removeItem(key){if(options.writeFails)throw Error('Storage denied');values.delete(key);}};
  const ctx={localStorage:storage,crypto:{randomUUID(){generated++;return generated===1?'11111111-1111-4111-8111-111111111111':'22222222-2222-4222-8222-222222222222';}}};
  vm.runInNewContext(block[1]+'\nthis.getAnonymousUserId=getAnonymousUserId;this.readConversationId=readConversationId;this.setStoredConversationId=setStoredConversationId;',ctx);
  return {ctx,values,generated:()=>generated};
}
test('Anonymous browser ID is stable, persisted and role-namespaced',()=>{
  const {ctx,values,generated}=identityRuntime();
  const visitor=ctx.getAnonymousUserId('visitor'),student=ctx.getAnonymousUserId('student');
  assert.equal(visitor,'visitor_11111111-1111-4111-8111-111111111111');
  assert.equal(student,'student_11111111-1111-4111-8111-111111111111');
  assert.equal(ctx.getAnonymousUserId('visitor'),visitor);assert.equal(generated(),1);
  assert.equal(values.get('maqam_uid'),'11111111-1111-4111-8111-111111111111');
});
test('Existing canonical UUID is reused and corrupt identifiers are replaced',()=>{
  const existing=identityRuntime({maqam_uid:'33333333-3333-4333-8333-333333333333'});
  assert.equal(existing.ctx.getAnonymousUserId('student'),'student_33333333-3333-4333-8333-333333333333');assert.equal(existing.generated(),0);
  for(const corrupt of ['guest_101','null','{}','BAD','11111111-1111-4111-8111-11111111111Z']){
    const {ctx,values}=identityRuntime({maqam_uid:corrupt});ctx.getAnonymousUserId('visitor');assert.equal(values.get('maqam_uid'),'11111111-1111-4111-8111-111111111111');
  }
});
test('Denied/full storage falls back to one shared in-memory identity and conversation state',()=>{
  for(const options of [{readFails:true,writeFails:true},{writeFails:true}]){
    const {ctx,generated}=identityRuntime({},options);
    const first=ctx.getAnonymousUserId('visitor');assert.equal(ctx.getAnonymousUserId('visitor'),first);
    assert.equal(ctx.getAnonymousUserId('student').slice(8),first.slice(8));assert.equal(generated(),1);
    ctx.setStoredConversationId('visitor','44444444-4444-4444-8444-444444444444');
    assert.equal(ctx.readConversationId('visitor'),'44444444-4444-4444-8444-444444444444');assert.equal(ctx.readConversationId('student'),'');
  }
});
test('Legacy shared conversation is discarded and current conversations are owned by role and UUID',()=>{
  const {ctx,values}=identityRuntime({maqam_dify_conv_id:'44444444-4444-4444-8444-444444444444'});
  assert.equal(ctx.readConversationId('visitor'),'');assert.ok(!values.has('maqam_dify_conv_id'));
  ctx.setStoredConversationId('visitor','55555555-5555-4555-8555-555555555555');
  assert.equal(ctx.readConversationId('visitor'),'55555555-5555-4555-8555-555555555555');assert.equal(ctx.readConversationId('student'),'');
  assert.equal(values.get('maqam_dify_conv_id:visitor_11111111-1111-4111-8111-111111111111'),'55555555-5555-4555-8555-555555555555');
  ctx.setStoredConversationId('visitor','');assert.equal(ctx.readConversationId('visitor'),'');
});
test('Both chat request branches use the anonymous helper instead of shared identities',()=>{
  assert.ok(html.includes("user: getAnonymousUserId('visitor')"));assert.ok(html.includes("user: getAnonymousUserId('student')"));
  assert.ok(!html.includes('guest_101'));assert.ok(!html.includes("user: 'student_maqam'"));
});

test('Vendored Tailwind is audited immutable bytes served from this origin',()=>{
 const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'vendor','cdn-integrity.json'),'utf8'));
 const src='/assets/vendor/tailwind.3.4.17.176e894661aa.js';
 assert.ok(html.includes('src="'+src+'"'), 'Tailwind uses same-origin immutable artifact');
 const bytes=fs.readFileSync(path.join(__dirname,'..',src.slice(1)));
 assert.equal('sha384-'+require('node:crypto').createHash('sha384').update(bytes).digest('base64'),manifest.tailwind.integrity);
 assert.equal(require('node:crypto').createHash('sha256').update(bytes).digest('hex').slice(0,12),'176e894661aa');
});
