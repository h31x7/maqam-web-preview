const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const repo = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(repo, 'maqamooo.html'), 'utf8');
const publishingSource = source.slice(source.indexOf('// FEEDBACK_PUBLISHING_START'), source.indexOf('const SheikhDashboard ='));
function api() {
 const block = source.match(/\/\/ FEEDBACK_PUBLISHING_START([\s\S]*?)\/\/ FEEDBACK_PUBLISHING_END/);
 assert.ok(block, 'Publishing validators must exist before the feature can save');
 const ctx = {Date, Math, Number, String, Object, Array, JSON, Set, RegExp};
 vm.runInNewContext(block[1] + '\nthis.api={fbValidateLessonFile,fbRiyadhInputToISO,fbValidatePublication,fbPublicationCollection,fbPublicationState,fbPublishingItems,fbApplyPublication,fbPersistPublication:typeof fbPersistPublication==="function"?fbPersistPublication:undefined};', ctx);
 return ctx.api;
}
const NOW = Date.parse('2026-10-22T12:00:00.000Z');
const form = (extra={}) => ({type:'announcement',title:'تنبيه علمي',subject:'الحديث',details:'تعليمات منشورة',publishMode:'now',publishDate:'',publishTime:'',dueDate:'',dueTime:'',...extra});
test('Recorded lesson file validates extension, MIME, zero size and 50MB boundary', () => {
 const a=api();
 for(const [name,type] of [['lesson.mp4','video/mp4'],['صوت.mp3','audio/mpeg'],['درس.pdf','application/pdf'],['audio.ogg','audio/ogg']]) assert.equal(a.fbValidateLessonFile({name,type,size:1024}),null);
 assert.equal(a.fbValidateLessonFile({name:'clip.webm',type:'',size:50*1024*1024}),null);
 for(const file of [{name:'x.mp4',type:'text/html',size:1},{name:'x.html',type:'video/mp4',size:1},{name:'x.pdf',type:'application/pdf',size:0},{name:'x.mp3',type:'audio/mpeg',size:50*1024*1024+1}]) assert.equal(typeof a.fbValidateLessonFile(file),'string');
});
test('Riyadh input conversion is exact and rejects impossible calendar values', () => {
 const a=api();
 assert.equal(a.fbRiyadhInputToISO('2026-10-22','15:30'),'2026-10-22T12:30:00.000Z');
 for(const [d,t] of [['2026-02-30','10:00'],['2026-13-01','10:00'],['2026-10-22','24:00'],['2026-10-22','10:60'],['','10:00']]) assert.equal(a.fbRiyadhInputToISO(d,t),null);
 assert.equal(a.fbRiyadhInputToISO('2028-02-29','00:00'),'2028-02-28T21:00:00.000Z');
});
test('Publishing now preserves entered content without pretending server delivery', () => {
 const a=api(),result=a.fbValidatePublication(form(),null,NOW);
 assert.equal(result.errors.length,0); assert.equal(result.item.title,'تنبيه علمي');
 assert.equal(result.item.publishAt,new Date(NOW).toISOString()); assert.equal(result.item.origin,'local-publishing');
 assert.equal(result.item.studentSubmitted,undefined); assert.equal(result.item.viewsCount,undefined);
 assert.equal(a.fbPublicationCollection('announcement'),'announcements');
});
test('Scheduled publish validates actual future time, title, details and assignment deadline', () => {
 const a=api();
 assert.ok(a.fbValidatePublication(form({publishMode:'schedule',publishDate:'2026-10-22',publishTime:'14:59'}),null,NOW).errors.length);
 assert.ok(a.fbValidatePublication(form({publishMode:'schedule',publishDate:'2026-10-22',publishTime:'15:00'}),null,NOW).errors.length);
 assert.ok(a.fbValidatePublication(form({title:' '}),null,NOW).errors.length);
 assert.ok(a.fbValidatePublication(form({details:' '}),null,NOW).errors.length);
 assert.equal(a.fbValidatePublication(form({publishMode:'schedule',publishDate:'2026-10-22',publishTime:'15:01'}),null,NOW).errors.length,0);
 assert.ok(a.fbValidatePublication(form({type:'assignment',dueDate:'2026-10-22',dueTime:'14:00'}),null,NOW).errors.length);
 assert.ok(a.fbValidatePublication(form({type:'assignment',publishMode:'schedule',publishDate:'2026-10-23',publishTime:'12:00',dueDate:'2026-10-23',dueTime:'11:59'}),null,NOW).errors.length);
 assert.equal(a.fbValidatePublication(form({type:'assignment',dueDate:'2026-10-24',dueTime:'12:00'}),null,NOW).errors.length,0);
});
test('Quiz publishing needs a real question, distinct options, correct answer and explanation', () => {
 const a=api();
 assert.ok(a.fbValidatePublication(form({type:'quiz'}),null,NOW).errors.length);
 const q={type:'quiz',question:'ما معنى الاستنثار؟',options:['إخراج الماء من الأنف','غسل القدمين','مسح الرأس','غسل اليدين'],correct:0,explanation:'الاستنثار إخراج الماء من الأنف بعد استنشاقه.'};
 const result=a.fbValidatePublication(form(q),null,NOW); assert.equal(result.errors.length,0); assert.equal(result.item.questions[0].correct,0);
 assert.ok(a.fbValidatePublication(form({...q,options:['واحد','واحد','ثلاثة','أربعة']}),null,NOW).errors.length);
 assert.ok(a.fbValidatePublication(form({...q,explanation:''}),null,NOW).errors.length);
});
test('Recorded lesson requires a selected file or retained existing Blob reference', () => {
 const a=api();
 assert.ok(a.fbValidatePublication(form({type:'lecture'}),null,NOW).errors.length);
 assert.equal(a.fbValidatePublication(form({type:'lecture',file:{name:'lesson.mp4',type:'video/mp4',size:10}}),null,NOW).errors.length,0);
 const existing={id:'kept',type:'lecture',fileId:'blob-1',fileName:'lesson.mp4',fileType:'video/mp4',createdAt:'2026-10-01T00:00:00.000Z'};
 const result=a.fbValidatePublication(form({type:'lecture'}),existing,NOW);
 assert.equal(result.errors.length,0); assert.equal(result.item.id,'kept'); assert.equal(result.item.fileId,'blob-1'); assert.equal(result.item.createdAt,existing.createdAt);
 assert.ok(a.fbValidatePublication(form({type:'lecture',removeFile:true}),existing,NOW).errors.length);
});
test('Saved publishing list contains only authoritative local items, with truthful statuses', () => {
 const a=api(); const store={assignments:[{id:'seed',type:'assignment'},{id:'a',origin:'local-publishing',type:'assignment',publishAt:'2026-10-23T00:00:00Z'}],lectures:[{id:'l',origin:'local-publishing',type:'lecture',publishAt:'2026-10-21T00:00:00Z'}],quizzes:[],announcements:[]};
 const rows=a.fbPublishingItems(store); assert.equal(rows.length,2);
 assert.equal(a.fbPublicationState(rows.find(x=>x.id==='a'),NOW),'scheduled'); assert.equal(a.fbPublicationState(rows.find(x=>x.id==='l'),NOW),'published');
 assert.equal(a.fbPublicationState({cancelled:true},NOW),'cancelled');
 const updated=a.fbApplyPublication(store,{id:'a',type:'assignment',origin:'local-publishing',title:'محدث'});
 assert.equal(updated.assignments.length,2); assert.equal(updated.assignments.filter(x=>x.id==='a').length,1); assert.equal(store.assignments[1].title,undefined);
});
test('Publisher UI has real local persistence, inline validation and no alert or fake delivery', () => {
 api();
 assert.match(publishingSource,/await fbPutFile\(/); assert.match(publishingSource,/await fbDeleteFile\(/); assert.match(publishingSource,/fbGetFile\(/);
 assert.match(publishingSource,/onDrop=/); assert.match(publishingSource,/type="file"/); assert.match(publishingSource,/<progress/); assert.match(publishingSource,/role="alert"/);
 assert.doesNotMatch(publishingSource,/\balert\s*\(/); assert.doesNotMatch(publishingSource,/وإرساله للطلاب فوراً|نشر وإرسال للطلاب فوراً/);
});

test('Blob write failure never publishes JSON or deletes a retained file', async () => {
 const a=api(); assert.equal(typeof a.fbPersistPublication,'function'); let updates=0,deletes=[];
 await assert.rejects(a.fbPersistPublication(form({type:'lecture',file:{name:'lesson.mp4',type:'video/mp4',size:10}}),null,{now:NOW,putFile:async()=>{throw new Error('quota');},update:()=>{updates++;},deleteFile:async id=>deletes.push(id)}));
 assert.equal(updates,0); assert.equal(deletes.length,0);
});
test('JSON storage failure removes only the new Blob and leaves existing published content untouched', async () => {
 const a=api(); assert.equal(typeof a.fbPersistPublication,'function'); const deletes=[];
 const old={id:'old',type:'lecture',fileId:'retained',fileName:'old.mp4'};
 await assert.rejects(a.fbPersistPublication(form({type:'lecture',file:{name:'new.mp4',type:'video/mp4',size:10}}),old,{now:NOW,putFile:async()=>({id:'new-blob',name:'new.mp4',type:'video/mp4',size:10}),update:()=>{throw new Error('JSON full');},deleteFile:async id=>deletes.push(id)}));
 assert.deepEqual(deletes,['new-blob']); assert.equal(old.fileId,'retained');
});
test('Replacing a recording commits its metadata before retiring the old Blob', async () => {
 const a=api(),order=[]; assert.equal(typeof a.fbPersistPublication,'function');
 const item=await a.fbPersistPublication(form({type:'lecture',file:{name:'new.mp4',type:'video/mp4',size:10}}),{id:'old',type:'lecture',fileId:'retained',fileName:'old.mp4'},{now:NOW,putFile:async()=>{order.push('blob');return{id:'new-blob',name:'new.mp4',type:'video/mp4',size:10};},update:fn=>{order.push('metadata');const next=fn({assignments:[],lectures:[],quizzes:[],announcements:[]});assert.equal(next.lectures[0].fileId,'new-blob');},deleteFile:async id=>order.push('delete:'+id)});
 assert.equal(item.id,'old'); assert.deepEqual(order,['blob','metadata','delete:retained']);
});

test('PDF lesson attachments are not offered to the mini player as video', () => {
 const block=source.match(/\/\/ FEEDBACK_NAV_START([\s\S]*?)\/\/ FEEDBACK_NAV_END/);assert.ok(block);
 const ctx={URL};vm.runInNewContext(block[1]+';this.media=fbMediaSource;',ctx);
 const result=ctx.media({fileType:'application/pdf',blobUrl:'blob:https://maqam.example/local-pdf'});
 assert.notEqual(result.kind,'video','A PDF attachment must show its document action or an honest non-audio state, never a video element');
});

function navReviewApi(){const block=source.match(/\/\/ FEEDBACK_NAV_START([\s\S]*?)\/\/ FEEDBACK_NAV_END/);const ctx={URL};vm.runInNewContext(block[1]+';this.api={scholarList:typeof fbScholarLectureList==="function"?fbScholarLectureList:undefined,audioTrack:typeof fbAudioTrackState==="function"?fbAudioTrackState:undefined};',ctx);return ctx.api;}
test('fictional instructor matches the same name with the Sheikh prefix without matching another instructor',()=>{const a=navReviewApi(),lecture={id:'demo',sheikh:'ناصر السلمي'};assert.equal(a.scholarList({name:'الشيخ ناصر السلمي'},[],[lecture]).length,1);assert.equal(a.scholarList({name:'الشيخ خالد العتيبي'},[],[lecture]).length,0);assert.equal(a.scholarList({name:''},[],[{id:'unknown',title:'بلا شيخ'}]).length,0);});

test('Choosing another queued recording resets stale playback state and rate',()=>{
 const a=navReviewApi();assert.equal(typeof a.audioTrack,'function');
 const next={id:'next',title:'المحاضرة التالية',sheikh:'الشيخ د. حسن بخاري'};
 const state=a.audioTrack(next);
 assert.equal(state.item,next);assert.equal(state.playing,false);assert.equal(state.position,0);assert.equal(state.duration,0);assert.equal(state.rate,1);assert.equal(state.error,'');
});
test('Editing released content updates stale notices and emits a real change; cancellation removes actionable release',()=>{
 const a=api(); const original={id:'changed',type:'lecture',title:'old',origin:'local-publishing',publishAt:'2020-01-01T00:00:00Z'};
 const data={assignments:[],quizzes:[],lectures:[original],announcements:[],notifications:[{id:'release:lectures:changed',title:'old',target:{view:'lecture',payload:{id:'changed'}}}]};
 const edited=a.fbApplyPublication(data,{...original,title:'new',updatedAt:'2026-10-22T12:00:00Z'});
 assert.equal(edited.notifications.some(n=>n.type==='schedule'&&n.title.includes('new')),true);
 assert.equal(edited.notifications.some(n=>n.title==='old'),false);
 const cancelled=a.fbApplyPublication(edited,{...edited.lectures[0],cancelled:true,updatedAt:'2026-10-22T12:01:00Z'});
 assert.equal(cancelled.notifications.some(n=>n.id.startsWith('release:')),false);
 assert.equal(cancelled.notifications[0].target.view,'notifications');
});
