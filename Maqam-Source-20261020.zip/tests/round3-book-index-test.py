"""Validate every published physical-page record without rerunning OCR."""
import collections, hashlib, json, pathlib, re, unicodedata
ROOT = pathlib.Path(__file__).resolve().parents[1]
WORK = ROOT.parents[1] / 'work/round3'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def norm(s):
 s=unicodedata.normalize('NFKC',s)
 return re.sub(r'\s+',' ',re.sub('[\u064b-\u065f\u0670\u0640]','',s)).strip()
books=read(ROOT/'data/books.json'); manifest=read(ROOT/'data/book-indexes/manifest.json'); stats=[]
assert [b['id'] for b in books]==[f'book-{n}' for n in range(1,8)]
assert [b['book'] for b in manifest]==[b['id'] for b in books]
for book,entry in zip(books,manifest):
 path=ROOT/'data/book-indexes'/(book['id']+'.json'); data=read(path); pages=data['pages']; total=book['pages']
 assert entry=={k:data[k] for k in entry}
 assert data['book']==book['id'] and data['totalPages']==data['indexedPages']==total
 assert data['complete'] is True and data['citationNotice']
 assert [p['page'] for p in pages]==list(range(1,total+1))
 for p in pages:
  assert p['book']==book['id'] and type(p['page']) is int
  assert isinstance(p['text'],str) and isinstance(p['searchText'],str) and p['searchText']==norm(p['text'])
  assert '\t' not in p['text']
  assert not re.search(r'level\s+page_num\s+block_num|word_num\s+left\s+top|tessedit_create_tsv',p['text'])
  if book['id'] in ('book-3','book-5'):
   assert p['method']=='pdf-text' and p['quality']=='text-layer-unreviewed'
  else:
   assert p['method'] in ('tesseract-ara-200dpi','tesseract-ara-300dpi')
   c=p['confidence']; assert isinstance(c,(float,int)) and 0<=c<=100
   assert p['quality']==('ocr-unreviewed' if c>=65 else 'ocr-low-confidence')
   assert p==read(WORK/'ocr/pages'/book['id']/f"{p['page']}.json")
 if book['id'] in ('book-3','book-5'):
  raw=read(WORK/'assets/pdf-text'/pathlib.Path(book['sourceFile']).with_suffix('.json'))
  assert len(raw)==len(pages)
  for original,p in zip(raw,pages):
   assert original['page']==p['page'] and unicodedata.normalize('NFKC',original['text'])==p['text']
 pdf=ROOT/book['pdf'].lstrip('/'); assert pdf.stat().st_size==book['bytes']
 assert hashlib.sha256(pdf.read_bytes()).hexdigest()==book['sha256']
 stats.append(dict(book=book['id'],pages=total,searchable=sum(bool(p['text']) and p['quality']!='ocr-low-confidence' for p in pages),blank=sum(not p['text'].strip() for p in pages),qualities=dict(collections.Counter(p['quality'] for p in pages)),methods=dict(collections.Counter(p['method'] for p in pages)),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
assert sum(s['pages'] for s in stats)==3639
print(json.dumps(stats,ensure_ascii=False,indent=2))
print('PASS: 3,639 physical pages, source/cache provenance, normalization, quality and PDF integrity')
