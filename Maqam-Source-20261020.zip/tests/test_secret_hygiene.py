"""Check current publishable source without ever echoing credential contents."""
from pathlib import Path
import re
import unittest

ROOT=Path(__file__).resolve().parents[1]
PATTERN=re.compile(rb'\bapp-[A-Za-z0-9]{20,}\b')

class SecretHygiene(unittest.TestCase):
    def test_no_embedded_provider_credential_in_current_text_tree(self):
        offenders=[]
        for path in ROOT.rglob('*'):
            if '.git' in path.parts or not path.is_file() or path.suffix not in {'.html','.js','.py','.md','.json','.txt','.yaml','.yml'}:
                continue
            if PATTERN.search(path.read_bytes()):
                offenders.append(str(path.relative_to(ROOT)))
        self.assertEqual(offenders, [], 'Credential-shaped literals found; values intentionally withheld')

if __name__=='__main__':unittest.main()
