"""Regression tests for the Maqam hardening contract."""
