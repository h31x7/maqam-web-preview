const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const context={window:{},console,URL,AbortController,DOMException,setTimeout,clearTimeout};
vm.createContext(context);
vm.runInContext(fs.readFileSync(__dirname+'/../maqamooo.html','utf8').split('// ROUND4_VISION_DOMAIN_START')[1].split('// ROUND4_VISION_DOMAIN_END')[0],context);
const domain=context.window.Round4Vision;
test('OCR uncertainty uses actual confidence and markers',()=>{
 assert.equal(typeof domain.ocrResult,'function');
 const out=domain.ocrResult({text:'الصلاة واجبة',confidence:72,words:[{text:'الصلاة',confidence:90},{text:'واجبة',confidence:40}]});
 assert.equal(out.confidence,72);assert.match(out.text,/واجبة \[غير واضح\]/);
 assert.equal(domain.ocrResult({text:'نص'}).confidence,null);
});
test('review requires exact statement and evidence before a supported verdict',()=>{
 assert.equal(typeof domain.parseReview,'function');
 const source={id:'book-1:2',book:'book-1',page:2,excerpt:'الوضوء شرط للصلاة'};
 const payload={extracted_text:'الوضوء شرط للصلاة',statements:[{statement:'الوضوء شرط للصلاة',verdict:'صحيح',basis:'النص صريح',source_ids:[]}]};
 let result=domain.parseReview(JSON.stringify(payload),payload.extracted_text,[source]);
 assert.equal(result.statements[0].verdict,'غير مؤكد');
 payload.statements[0].source_ids=['book-1:2'];
 result=domain.parseReview(JSON.stringify(payload),payload.extracted_text,[source]);
 assert.equal(result.statements[0].verdict,'غير مؤكد');
 payload.statements[0].evidence_quote='الوضوء شرط للصلاة';
 result=domain.parseReview(JSON.stringify(payload),payload.extracted_text,[source]);
 assert.equal(result.statements[0].verdict,'صحيح');
 payload.statements[0].statement='invented statement';
 assert.equal(domain.parseReview(JSON.stringify(payload),payload.extracted_text,[source]),null);
 assert.equal(domain.parseReview('A genuine plain answer','text',[]),null);
});
test('prompt stays bounded, identifies untrusted notes and does not invent evidence',()=>{
 assert.equal(typeof domain.reviewPrompt,'function');
 const prompt=domain.reviewPrompt('x'.repeat(1800),[{id:'book-1:2',excerpt:'real'.repeat(500)}]);
 assert.ok(prompt.length<=4000);assert.match(prompt,/غير مؤكد/);assert.match(prompt,/book-1:2/);
 assert.throws(()=>domain.reviewPrompt('x'.repeat(1801),[]));
});
test('transcription never treats a plain answer as extracted notes',()=>{
 assert.equal(typeof domain.transcription,'function');
 assert.equal(domain.transcription('I cannot read this'),null);
 const result=domain.transcription('{"extracted_text":"الصلاة واجبة","uncertain_words":["واجبة"]}');
 assert.match(result.text,/واجبة \[غير واضح\]/);
 assert.equal(result.confidence,null);
});

test('image dimensions are rejected before decompression',()=>{
 assert.equal(typeof domain.headerDimensions,'function');
 const raw=new Uint8Array(32);raw.set([137,80,78,71,13,10,26,10]);raw.set([73,72,68,82],12);new DataView(raw.buffer).setUint32(16,50000);new DataView(raw.buffer).setUint32(20,50000);
 assert.throws(()=>domain.headerDimensions(raw,'image/png'));
 new DataView(raw.buffer).setUint32(16,100);new DataView(raw.buffer).setUint32(20,200);
 assert.deepEqual(Array.from(domain.headerDimensions(raw,'image/png')),[100,200]);
});
test('prompt rejects escaped text that exceeds the server query limit',()=>{
 assert.throws(()=>domain.reviewPrompt('"'.repeat(1800),[{id:'book-1:2',excerpt:'a'.repeat(350)},{id:'book-2:3',excerpt:'b'.repeat(350)},{id:'book-3:2',excerpt:'c'.repeat(350)}]));
});

test('OCR cancellation stops pending startup and terminates a late worker',async()=>{
 let finish;let terminated=false;
 context.window.MAQAM_OCR={workerPath:'fixed-worker',corePath:'fixed-core',langPath:'fixed-local-data'};
 context.window.Tesseract={createWorker:()=>new Promise(resolve=>{finish=resolve;})};
 const request=new AbortController();const pending=domain.recognize({}, {signal:request.signal});
 request.abort();await assert.rejects(pending,error=>error.name==='AbortError');
 finish({terminate:async()=>{terminated=true;}});await new Promise(resolve=>setTimeout(resolve,0));
 assert.equal(terminated,true);
});
