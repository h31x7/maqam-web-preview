import base64
import json
import socket
import struct
import unittest
import zlib
from unittest import mock
import test_server as support

UPLOAD_ID = 'd55403fd-b8d1-4e76-82ac-198c0f8f389b'
def png(width=10, height=10):
    def chunk(name, data):
        return struct.pack('>I',len(data))+name+data+struct.pack('>I',zlib.crc32(name+data)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(b'\0'+b'\0'*width*3))+chunk(b'IEND',b'')

class ImageTests(unittest.TestCase):
    request = support.ServerContractTests.request
    def setUp(self):
        support.ServerContractTests.setUp(self)
        # Parameters cache fixture: production queries the real bounded endpoint.
        if hasattr(self.module,'VisionState'):
            self.server.vision_state.save_capability(True)
        self.upstream_body = json.dumps({'id':UPLOAD_ID}).encode()
    def upload(self, **changes):
        return self.request('POST','/api/upload',{'user':support.VISITOR,'name':'notes.png','type':'image/png','data':base64.b64encode(png()).decode(),**changes})
    def test_unconfigured_capabilities_are_honest(self):
        self.module.DIFY_API_KEY = ''
        status, _, body = self.request('GET','/api/capabilities')
        self.assertEqual(status,200)
        self.assertEqual(json.loads(body),{'configured':False,'vision':False})
        self.assertEqual(self.upstream_calls,[])
    def test_parameters_are_bounded_cached_and_projected(self):
        self.server.vision_state.capability = None
        self.upstream_body = json.dumps({'file_upload':{'image':{'enabled':True}},'secret':'never return'}).encode()
        for _ in range(2):
            status, _, body = self.request('GET','/api/capabilities')
            self.assertEqual(status,200)
            self.assertEqual(json.loads(body),{'configured':True,'vision':True})
        self.assertEqual(len(self.upstream_calls),1)
        self.assertEqual(self.upstream_calls[0].full_url,'https://api.dify.ai/v1/parameters')
    def test_upload_returns_owned_local_identifier_and_maps_chat(self):
        status,_,body = self.upload()
        self.assertEqual(status,200)
        result=json.loads(body)
        local_id=result['upload_id']
        self.assertNotEqual(local_id,UPLOAD_ID)
        self.assertEqual(self.upstream_calls[0].full_url,'https://api.dify.ai/v1/files/upload')
        self.assertIn(b'Content-Type: image/png',self.upstream_calls[0].data)
        self.upstream_body=json.dumps({'answer':'real review'}).encode()
        status,_,_=self.request('POST','/api/chat',{'query':'review','user':support.VISITOR,'files':[local_id]})
        self.assertEqual(status,200)
        self.assertEqual(json.loads(self.upstream_calls[-1].data)['files'],[{'type':'image','transfer_method':'local_file','upload_file_id':UPLOAD_ID}])
        self.assertEqual(self.request('POST','/api/chat',{'query':'review','user':support.STUDENT,'files':[local_id]})[0],400)
    def test_unknown_or_url_files_rejected(self):
        for files in ([UPLOAD_ID],['https://evil.test/a.png'],[{'upload_file_id':UPLOAD_ID}],[],[UPLOAD_ID]*4,'bad'):
            self.assertEqual(self.request('POST','/api/chat',{'query':'x','user':support.VISITOR,'files':files})[0],400)
        self.assertEqual(self.upstream_calls,[])
    def test_malformed_mime_dimensions_names_schema(self):
        for change in ({'type':'image/svg+xml'},{'name':'../notes.png'},{'name':'bad\r\nX.png'},{'type':'image/jpeg'},{'data':'not base64'},{'data':base64.b64encode(b'<svg/>').decode()},{'data':base64.b64encode(png(4097,1)).decode()},{'url':'https://evil.test'},{'user':'x'}):
            self.assertEqual(self.upload(**change)[0],400,change)
        self.assertEqual(self.upstream_calls,[])
    def test_size_origin_rate(self):
        self.assertEqual(self.upload(data=base64.b64encode(b'x'*(2097153)).decode())[0],413)
        self.assertEqual(self.request('POST','/api/upload',{},headers={'Origin':'https://evil.test'})[0],403)
        for _ in range(20): self.upload(type='bad')
        self.assertEqual(self.upload()[0],429)
    def test_provider_invalid_redirect_timeout_and_unavailable(self):
        for body in (b'{}',b'{"id":"../bad"}',b'x'*1048577):
            self.upstream_body=body
            self.assertEqual(self.upload()[0],502)
        self.upstream_status=302
        self.upstream_headers={'Location':'https://untrusted.invalid/'}
        self.assertEqual(self.upload()[0],502)
        self.upstream_exception=socket.timeout()
        self.assertEqual(self.upload()[0],504)
        self.module.DIFY_API_KEY=''
        self.assertEqual(self.upload()[0],503)
    def test_ownership_expiry_and_capacity(self):
        state=self.server.vision_state
        for i in range(600): state.issue(support.VISITOR,UPLOAD_ID)
        self.assertLessEqual(len(state.uploads),512)
        local=state.issue(support.VISITOR,UPLOAD_ID)
        self.assertEqual(state.owned(local,support.VISITOR),UPLOAD_ID)
        self.assertIsNone(state.owned(local,support.STUDENT))
        with mock.patch('time.monotonic',return_value=10**12):
            self.assertIsNone(state.owned(local,support.VISITOR))
    def test_multipart_upload(self):
        boundary='maqam-boundary-test'
        raw=(f'--{boundary}\r\nContent-Disposition: form-data; name="user"\r\n\r\n{support.VISITOR}\r\n--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="notes.png"\r\nContent-Type: image/png\r\n\r\n').encode()+png()+f'\r\n--{boundary}--\r\n'.encode()
        self.assertEqual(self.request('POST','/api/upload',raw_body=raw,headers={'Content-Type':f'multipart/form-data; boundary={boundary}'})[0],200)
    def test_webp_canvas_dimensions_cannot_hide_oversized_frame(self):
        def chunk(name,data): return name+struct.pack('<I',len(data))+data+(b'\0' if len(data)%2 else b'')
        header=b'\0\0\0\0'+(9).to_bytes(3,'little')+(9).to_bytes(3,'little')
        frame=b'\0\0\0\x9d\x01\x2a'+struct.pack('<HH',4097,10)
        chunks=chunk(b'VP8X',header)+chunk(b'VP8 ',frame)
        raw=b'RIFF'+struct.pack('<I',len(chunks)+4)+b'WEBP'+chunks
        self.assertEqual(self.upload(name='notes.webp',type='image/webp',data=base64.b64encode(raw).decode())[0],400)
    def test_capability_schema_failures_timeout_and_redirect_are_not_vision(self):
        for body in (b'{}',b'{"file_upload":{"enabled":true,"allowed_file_types":["image"],"allowed_file_upload_methods":"local_file"}}',b'[]',b'x'*1048577):
            self.server.vision_state.capability=None
            self.upstream_body=body
            status,_,raw=self.request('GET','/api/capabilities')
            self.assertEqual(status,200)
            self.assertEqual(json.loads(raw),{'configured':True,'vision':False})
        self.server.vision_state.capability=None
        self.upstream_exception=socket.timeout()
        self.assertFalse(json.loads(self.request('GET','/api/capabilities')[2])['vision'])
        self.upstream_exception=None
        self.upstream_status=302
        self.upstream_headers={'Location':'https://untrusted.invalid/'}
        self.server.vision_state.capability=None
        self.assertFalse(json.loads(self.request('GET','/api/capabilities')[2])['vision'])
        self.assertFalse(any('untrusted.invalid' in call.full_url for call in self.upstream_calls))
    def test_modern_parameters_and_expiry(self):
        self.server.vision_state.capability=None
        self.upstream_body=json.dumps({'file_upload':{'enabled':True,'allowed_file_types':['image'],'allowed_file_upload_methods':['local_file']}}).encode()
        self.assertTrue(json.loads(self.request('GET','/api/capabilities')[2])['vision'])
        self.server.vision_state.capability=(0,True)
        self.upstream_body=b'{}'
        self.assertFalse(json.loads(self.request('GET','/api/capabilities')[2])['vision'])
    def test_malformed_multipart_is_rejected_without_provider_call(self):
        for raw in (b'garbage',b'--x\r\nContent-Disposition: form-data; name="file"; filename="notes.png"\r\nContent-Type: image/png\r\n\r\n'+png()+b'\r\n--x--\r\n'):
            self.assertEqual(self.request('POST','/api/upload',raw_body=raw,headers={'Content-Type':'multipart/form-data; boundary=x'})[0],400)
        self.assertEqual(self.upstream_calls,[])
    def test_upload_requires_origin_and_disallows_chunked_framing(self):
        self.assertEqual(self.request('POST','/api/upload',{},headers={'Transfer-Encoding':'chunked'})[0],400)
        self.assertEqual(self.request('POST','/api/upload',{},headers={'Origin':''})[0],403)
        self.assertEqual(self.upstream_calls,[])
