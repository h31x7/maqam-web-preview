import json
import os
from unittest import mock
import unittest
import test_server


class GroqContractTests(unittest.TestCase):
    request = test_server.ServerContractTests.request
    def setUp(self):
        test_server.ServerContractTests.setUp(self)
        patch = mock.patch.dict(os.environ, {'TTS_PROVIDER': '', 'GROQ_API_KEY': 'test-only-groq-secret', 'GROQ_TRANSLATE_MODEL': 'tested-fixture-model'})
        patch.start()
        self.addCleanup(patch.stop)
        pause = mock.patch.object(self.module.time, 'sleep')
        pause.start()
        self.addCleanup(pause.stop)
        self.upstream_body = json.dumps({'choices': [{'message': {'content': json.dumps({'translations': ['one', 'two']})}}]}).encode()

    def batch(self, **extra):
        return self.request('POST', '/api/translate', {'sentences': ['أ', 'ب'], 'target': 'en', **extra})

    def test_groq_batch_order(self):
        status, _, body = self.batch()
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body), {'translations': ['one', 'two'], 'engine': 'groq', 'model': 'tested-fixture-model'})
        payload = json.loads(self.upstream_calls[0].data)
        self.assertEqual(payload['temperature'], 0)
        self.assertEqual(payload.get('max_tokens'), 150)
        self.assertEqual(payload['model'], 'tested-fixture-model')

    def test_groq_malformed_once(self):
        self.upstream_body = b'{"choices":[{"message":{"content":"{}"}}]}'
        status, _, body = self.batch()
        self.assertEqual(status, 502)
        self.assertEqual(len(self.upstream_calls), 2)
        self.assertEqual(json.loads(body)['code'], 'groq_invalid_response')

    def test_groq_missing_model(self):
        with mock.patch.dict(os.environ, {'GROQ_TRANSLATE_MODEL': ''}):
            self.assertEqual(self.batch()[0], 503)
        self.assertFalse(self.upstream_calls)

    def test_groq_retries_rate_and_server(self):
        for status in (429, 503):
            self.upstream_calls.clear()
            self.upstream_status = status
            self.upstream_headers = {'Retry-After': '2'}
            response = self.batch()
            self.assertEqual(response[0], 429 if status == 429 else 503)
            self.assertEqual(response[1]['Retry-After'], '2')
            self.assertEqual(len(self.upstream_calls), 3)
            self.assertNotIn(b'test-only-groq-secret', response[2])

    def test_speech_capability_and_validation(self):
        status, _, body = self.request('GET', '/api/speech')
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)['maxCharacters'], 200)
        for payload in ({'text': 'x'*201, 'language': 'en'}, {'text': 'x', 'language': 'en', 'voice': 'fahad'}, {'text': 'x', 'language': 'fr'}, {'text': 'x', 'language': 'en', 'extra': True}):
            self.assertEqual(self.request('POST', '/api/speech', payload)[0], 400)
        self.assertFalse(self.upstream_calls)

    def test_speech_wav_and_bad_audio(self):
        import io, wave
        buf = io.BytesIO()
        with wave.open(buf, 'wb') as wav:
            wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(24000); wav.writeframes(b'\0\0'*24)
        self.upstream_body = buf.getvalue()
        status, headers, body = self.request('POST', '/api/speech', {'text': 'hello', 'language': 'en'})
        self.assertEqual(status, 200)
        self.assertEqual(headers['Content-Type'], 'audio/wav')
        self.assertEqual(body, self.upstream_body)
        self.upstream_body = b'not wav'
        self.assertEqual(self.request('POST', '/api/speech', {'text': 'hello', 'language': 'en'})[0], 502)

    def test_groq_strict_batch(self):
        for extra in ({'sentences': []}, {'sentences': ['x', 2]}, {'sentences': ['x'*4001]}, {'target': 'invalid'}, {'extra': 1}):
            self.assertEqual(self.batch(**extra)[0], 400)
        self.assertFalse(self.upstream_calls)

    def test_speech_origin_rate_and_secret_boundary(self):
        self.assertEqual(self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'}, headers={'Origin': 'https://evil.invalid'})[0], 403)
        for _ in range(20):
            self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})
        status, headers, body = self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})
        self.assertEqual(status, 429)
        self.assertTrue(headers['Retry-After'])
        self.assertNotIn(b'test-only-groq-secret', body)
        for path in ('/.env', '/server.py', '/.env.example'):
            self.assertEqual(self.request('GET', path)[0], 404)

    def test_groq_redirect_and_oversize_blocked(self):
        self.upstream_status = 302
        self.upstream_headers = {'Location': 'https://untrusted.invalid/steal'}
        self.assertEqual(self.batch()[0], 502)
        self.assertEqual(len(self.upstream_calls), 1)
        self.upstream_calls.clear()
        self.upstream_status = 200
        self.upstream_body = b'x' * (self.module.GROQ_AUDIO_MAX + 1)
        self.assertEqual(self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})[0], 502)

    def test_groq_retry_once_then_success_and_wrong_length(self):
        good = self.upstream_body
        with mock.patch.object(self.module, '_groq_request', side_effect=[b'{}', good]) as transport:
            self.assertEqual(self.batch()[0], 200)
            self.assertEqual(transport.call_count, 2)
        self.upstream_body = json.dumps({'choices': [{'message': {'content': '{"translations":["one"]}'}}]}).encode()
        self.assertEqual(self.batch()[0], 502)

    def test_environment_loader_subset_and_process_precedence(self):
        path = self.root / 'fixture-config'
        path.write_text('GROQ_TRANSLATE_MODEL=alternate\nDIFY_API_KEY=should-not-be-loaded\nGROQ_TTS_VOICE_EN="daniel"\n', encoding='utf-8')
        with mock.patch.dict(os.environ, {'GROQ_TRANSLATE_MODEL': 'process-model'}):
            self.module.load_groq_environment(path)
            self.assertEqual(os.environ['GROQ_TRANSLATE_MODEL'], 'process-model')
            self.assertEqual(os.environ['GROQ_TTS_VOICE_EN'], 'daniel')
            self.assertNotEqual(os.environ.get('DIFY_API_KEY'), 'should-not-be-loaded')

    def test_model_validation_sanitized_and_alternate_voice(self):
        self.upstream_body = b'{"data":[]}'
        with self.assertLogs(self.module.LOGGER, level='WARNING') as captured:
            self.module.validate_groq_models()
        self.assertNotIn('test-only-groq-secret', str(captured.output))
        with mock.patch.dict(os.environ, {'GROQ_TTS_MODEL_EN': 'custom-tested', 'GROQ_TTS_VOICE_EN': 'customvoice'}):
            caps = self.module._groq_capabilities()['languages']['en']
            self.assertEqual(caps['voices'], ['customvoice'])
            self.assertTrue(caps['available'])
        with mock.patch.dict(os.environ, {'GROQ_TTS_VOICE_EN': 'fahad'}):
            self.assertFalse(self.module._groq_capabilities()['languages']['en']['available'])

    def test_surrogate_and_provider_secret_never_relayed(self):
        self.assertEqual(self.request('POST', '/api/translate', raw_body=json.dumps({'sentences': ['\ud800'], 'target': 'en'}, ensure_ascii=True))[0], 400)
        self.upstream_body = json.dumps({'choices': [{'message': {'content': json.dumps({'translations': ['test-only-groq-secret', 'safe']})}}]}).encode()
        status, _, body = self.batch()
        self.assertEqual(status, 502)
        self.assertNotIn(b'test-only-groq-secret', body)

    def test_public_model_and_voice_settings_never_echo_key(self):
        secret = 'test-only-groq-secret'
        for setting in ('GROQ_TRANSLATE_MODEL', 'GROQ_TTS_MODEL_AR', 'GROQ_TTS_MODEL_EN', 'GROQ_TTS_VOICE_AR', 'GROQ_TTS_VOICE_EN'):
            for value in (secret, 'prefix-' + secret, secret + '-suffix'):
                with self.subTest(setting=setting, value_kind=len(value)), mock.patch.dict(os.environ, {setting: value}):
                    status, _, body = self.request('GET', '/api/speech')
                    self.assertEqual(status, 200)
                    self.assertNotIn(secret.encode(), body)
                    if setting == 'GROQ_TRANSLATE_MODEL':
                        self.assertEqual(self.batch()[0], 503)
        self.assertFalse(self.upstream_calls)

    def test_speech_model_terms_has_safe_actionable_error_without_retry(self):
        self.upstream_status = 400
        self.upstream_body = json.dumps({'error': {'code': 'model_terms_required', 'message': 'private provider diagnostic test-only-groq-secret'}}).encode()
        status, _, body = self.request('POST', '/api/speech', {'text': 'hello', 'language': 'en'})
        self.assertEqual(status, 503)
        parsed = json.loads(body)
        self.assertEqual(parsed['code'], 'groq_terms_required')
        self.assertIn('Groq', parsed['error'])
        self.assertNotIn(b'private provider', body)
        self.assertNotIn(b'test-only-groq-secret', body)
        self.assertEqual(len(self.upstream_calls), 1)

    def test_terms_mapping_does_not_match_freeform_provider_text(self):
        self.upstream_status = 400
        for payload in ({'error': {'message': 'model_terms_required'}}, {'error': {'code': 'other'}}, {'error': ['model_terms_required']}):
            self.upstream_body = json.dumps(payload).encode()
            status, _, body = self.request('POST', '/api/speech', {'text': 'hello', 'language': 'en'})
            self.assertEqual(status, 502)
            self.assertEqual(json.loads(body)['code'], 'groq_unavailable')
            self.assertNotIn(b'model_terms_required', body)
