import asyncio
import os
from unittest import mock
import unittest
import test_server

VOICES = [
    {'ShortName': 'ar-SA-HamedNeural', 'Locale': 'ar-SA'},
    {'ShortName': 'en-US-JennyNeural', 'Locale': 'en-US'},
    {'ShortName': 'en-GB-SoniaNeural', 'Locale': 'en-GB'},
    {'ShortName': 'ur-PK-AsadNeural', 'Locale': 'ur-PK'},
    {'ShortName': 'fa-IR-DilaraNeural', 'Locale': 'fa-IR'},
]
MP3 = bytes([0xff, 0xf3, 0x84, 0xc0]) + b'\x11' * 96

class EdgeContractTests(unittest.TestCase):
    request = test_server.ServerContractTests.request
    def setUp(self):
        test_server.ServerContractTests.setUp(self)
        env = mock.patch.dict(os.environ, {'TTS_PROVIDER': 'edge'})
        env.start(); self.addCleanup(env.stop)
        async def voices():
            return VOICES
        async def stream(text, voice):
            yield {'type': 'audio', 'data': MP3[:40]}
            yield {'type': 'WordBoundary', 'text': 'ignored'}
            yield {'type': 'audio', 'data': MP3[40:]}
        self.voice_mock = mock.patch.object(self.module, '_edge_list_voices', voices, create=True)
        self.stream_mock = mock.patch.object(self.module, '_edge_stream', stream, create=True)
        self.voice_mock.start(); self.stream_mock.start()
        self.addCleanup(self.voice_mock.stop); self.addCleanup(self.stream_mock.stop)

    def test_edge_capabilities_discover_locale_and_base_with_no_groq_key(self):
        with mock.patch.dict(os.environ, {'GROQ_API_KEY': ''}):
            status, _, body = self.request('GET', '/api/speech')
        self.assertEqual(status, 200)
        caps = __import__('json').loads(body)
        self.assertEqual(caps['provider'], 'edge')
        self.assertEqual(caps['maxCharacters'], 200)
        self.assertEqual(caps['languages']['ur']['model'], 'edge-tts')
        self.assertEqual(caps['languages']['en']['voices'], ['en-GB-SoniaNeural', 'en-US-JennyNeural'])
        self.assertEqual(caps['languages']['en-US']['voices'], ['en-US-JennyNeural'])
        self.assertTrue(caps['languages']['fa']['available'])

    def test_edge_speech_mp3_and_strict_voice_language(self):
        status, headers, body = self.request('POST', '/api/speech', {'text': 'hello', 'language': 'en', 'voice': 'en-US-JennyNeural'})
        self.assertEqual(status, 200); self.assertEqual(headers['Content-Type'], 'audio/mpeg'); self.assertEqual(body, MP3)
        for payload in ({'text': 'hi', 'language': 'ur', 'voice': 'en-US-JennyNeural'}, {'text': 'hi', 'language': 'en-US', 'voice': 'en-GB-SoniaNeural'}, {'text': 'hi', 'language': 'zz'}, {'text': 'x'*201, 'language': 'en'}, {'text': 'hi', 'language': 'en', 'url': 'https://evil.invalid'}):
            self.assertEqual(self.request('POST', '/api/speech', payload)[0], 400)
        self.assertFalse(self.upstream_calls)

    def test_edge_audio_size_and_format_reject_safely(self):
        async def bad(text, voice):
            yield {'type': 'audio', 'data': b'not-audio'}
        with mock.patch.object(self.module, '_edge_stream', bad):
            self.assertEqual(self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})[0], 502)
        async def huge(text, voice):
            yield {'type': 'audio', 'data': MP3 + b'x' * self.module.GROQ_AUDIO_MAX}
        with mock.patch.object(self.module, '_edge_stream', huge):
            status, _, body = self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})
            self.assertEqual(status, 502); self.assertNotIn(b'not-audio', body)

    def test_edge_timeout_and_exception_are_generic(self):
        async def timeout(text, voice):
            raise asyncio.TimeoutError('private provider diagnostic')
            yield
        with mock.patch.object(self.module, '_edge_stream', timeout):
            status, _, body = self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})
            self.assertEqual(status, 504); self.assertNotIn(b'private provider', body)
        async def failure(text, voice):
            raise RuntimeError('private provider diagnostic')
            yield
        with mock.patch.object(self.module, '_edge_stream', failure):
            status, _, body = self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})
            self.assertEqual(status, 503); self.assertNotIn(b'private provider', body)

    def test_voice_discovery_failure_and_cache_are_bounded(self):
        calls = []
        async def voices():
            calls.append(1); return VOICES
        with mock.patch.object(self.module, '_edge_list_voices', voices, create=True):
            self.request('GET', '/api/speech'); self.request('GET', '/api/speech')
        self.assertEqual(len(calls), 1)

    def test_discovery_strips_invalid_or_mismatched_voice_records(self):
        async def voices():
            return VOICES + [{'ShortName': 'https://evil.invalid', 'Locale': 'en-US'}, {'ShortName': 'en-US-JennyNeural', 'Locale': 'ur-PK'}, {'ShortName': '__proto__', 'Locale': '__proto__'}]
        with mock.patch.object(self.module, '_edge_list_voices', voices, create=True):
            status, _, body = self.request('GET', '/api/speech')
            self.assertEqual(status, 200); self.assertNotIn(b'evil.invalid', body); self.assertNotIn(b'__proto__', body)

    def test_edge_origin_and_existing_rate_limits_remain(self):
        self.assertEqual(self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'}, headers={'Origin': 'https://evil.invalid'})[0], 403)
        for _ in range(20): self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})
        self.assertEqual(self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})[0], 429)

    def test_discovery_failure_has_cooldown_and_does_not_invent_voices(self):
        calls = []
        async def unavailable():
            calls.append(1); raise RuntimeError('private metadata diagnostic')
        with mock.patch.object(self.module, '_edge_list_voices', unavailable):
            first = self.request('GET', '/api/speech')
            second = self.request('GET', '/api/speech')
            self.assertEqual(first[0], 200); self.assertEqual(second[0], 200)
            self.assertEqual(__import__('json').loads(first[2])['languages'], {})
            self.assertNotIn(b'private metadata', first[2])
            self.assertEqual(self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})[0], 503)
        self.assertEqual(len(calls), 1)

    def test_edge_rate_error_and_oversized_voice_discovery_are_safe(self):
        class Limited(Exception):
            status = 429
        async def limited(text, voice):
            raise Limited('private provider rate diagnostic')
            yield
        with mock.patch.object(self.module, '_edge_stream', limited):
            status, headers, body = self.request('POST', '/api/speech', {'text': 'hi', 'language': 'en'})
            self.assertEqual(status, 429); self.assertEqual(headers['Retry-After'], '30'); self.assertNotIn(b'private provider', body)
        self.server.edge_speech = self.module.EdgeSpeechState()
        async def huge(): return VOICES * 300
        with mock.patch.object(self.module, '_edge_list_voices', huge):
            status, _, body = self.request('GET', '/api/speech')
            self.assertEqual(status, 200); self.assertEqual(__import__('json').loads(body)['languages'], {})

    def test_dotenv_loader_accepts_provider_without_changing_process_precedence(self):
        path = self.root / 'fixture-provider-config'
        path.write_text('TTS_PROVIDER=groq\nUNRELATED_SETTING=ignored\n', encoding='utf-8')
        self.module.load_groq_environment(path)
        self.assertEqual(os.environ['TTS_PROVIDER'], 'edge')
        self.assertNotEqual(os.environ.get('UNRELATED_SETTING'), 'ignored')

    def test_local_launcher_loads_environment_before_listener_without_touching_real_file(self):
        import importlib.util
        from pathlib import Path
        spec = importlib.util.spec_from_file_location('maqam_launcher_fixture', Path(__file__).resolve().parents[1] / 'launch_local.py')
        launcher = importlib.util.module_from_spec(spec); spec.loader.exec_module(launcher)
        listener = mock.Mock()
        calls = []
        with mock.patch.object(launcher.server, 'load_groq_environment', side_effect=lambda path: calls.append('load')), mock.patch.object(launcher.server, 'create_server', side_effect=lambda *args: (calls.append('listen'), listener)[1]), mock.patch.object(launcher.threading, 'Thread'), mock.patch.object(launcher.sys, 'argv', ['launch_local.py', '--no-browser']), mock.patch('builtins.print'):
            launcher.main()
        self.assertEqual(calls, ['load', 'listen'])
        listener.serve_forever.assert_called_once(); listener.server_close.assert_called_once()

    def test_pinned_dependency_and_venv_launcher(self):
        from pathlib import Path
        root = Path(__file__).resolve().parents[1]
        self.assertIn('edge-tts==7.3.1', (root / 'requirements.txt').read_text(encoding='utf-8'))
        self.assertIn('.venv\\Scripts\\python.exe', (root / 'Start-Maqam.cmd').read_text(encoding='utf-8'))

class EdgeVoiceTransportTests(unittest.TestCase):
    def test_catalog_transport_is_bounded_before_json_and_rejects_redirects(self):
        import importlib.util
        if not importlib.util.find_spec('edge_tts'):
            self.skipTest('optional Edge dependency is not installed')
        import server
        class Content:
            async def iter_chunked(self, size):
                yield b'x' * (1048576 + 1)
        class Response:
            status = 200
            headers = {}
            content = Content()
            async def __aenter__(self): return self
            async def __aexit__(self, *args): pass
            def raise_for_status(self): pass
            async def text(self): return '[{"Locale":"en-US","ShortName":"' + 'x' * 1048576 + '"}]'
        response = Response()
        calls = []
        class Session:
            def __init__(self, **kwargs): calls.append(('session', kwargs))
            async def __aenter__(self): return self
            async def __aexit__(self, *args): pass
            def get(self, url, **kwargs): calls.append(('get', kwargs)); return response
        with mock.patch('aiohttp.ClientSession', Session), mock.patch.object(server, '_parse_json') as parse:
            with self.assertRaises(ValueError): asyncio.run(server._edge_list_voices())
            parse.assert_not_called()
            response.status = 302
            with self.assertRaises(ValueError): asyncio.run(server._edge_list_voices())
        self.assertTrue(all(c[1].get('allow_redirects') is False for c in calls if c[0] == 'get'))
        self.assertTrue(all(c[1].get('trust_env') is False for c in calls if c[0] == 'session'))

    def test_catalog_transport_preserves_strict_json(self):
        import importlib.util
        if not importlib.util.find_spec('edge_tts'):
            self.skipTest('optional Edge dependency is not installed')
        import server
        class Content:
            async def iter_chunked(self, size): yield b'[{"Locale":"en-US","Locale":"ur-PK"}]'
        class Response:
            status=200
            headers={}
            content=Content()
            async def __aenter__(self): return self
            async def __aexit__(self,*args): pass
            def raise_for_status(self): pass
            async def text(self): return '[{"Locale":"en-US","Locale":"ur-PK"}]'
        class Session:
            def __init__(self,**kwargs): pass
            async def __aenter__(self): return self
            async def __aexit__(self,*args): pass
            def get(self,*args,**kwargs): return Response()
        with mock.patch('aiohttp.ClientSession', Session):
            with self.assertRaises(ValueError): asyncio.run(server._edge_list_voices())
