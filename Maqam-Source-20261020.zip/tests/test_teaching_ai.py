import json
import os
import unittest
from unittest import mock
import test_server

class TeachingAI(unittest.TestCase):
    request = test_server.ServerContractTests.request
    def setUp(self):
        test_server.ServerContractTests.setUp(self)
        p = mock.patch.dict(os.environ, {'GROQ_API_KEY':'teaching-test-secret', 'GROQ_TRANSLATE_MODEL':'fixture-model'})
        p.start(); self.addCleanup(p.stop)
    def response(self, value):
        self.upstream_body = json.dumps({'choices':[{'message':{'content':json.dumps(value, ensure_ascii=False)}}]}).encode()
    def grade(self, **extra):
        return self.request('POST','/api/grade', {'mode':'homework','model_answer':'الرق','student_answer':'القتل','total':1, **extra})
    def test_grade_draft_and_budget(self):
        expected={'verdict':'خاطئ','score':0,'total':1,'wrong_points':['الصواب: الرق'],'notes':'راجع الشيخ'}
        self.response(expected)
        status,_,body=self.grade()
        self.assertEqual(status,200)
        self.assertEqual(json.loads(body),expected)
        payload=json.loads(self.upstream_calls[0].data)
        self.assertEqual(payload['max_tokens'],750)
        self.assertIn('untrusted',payload['messages'][0]['content'])
        self.assertEqual(self.grade()[0],429)
    def test_input_and_origin_boundaries(self):
        for payload in ({'model_answer':''},{'student_answer':'a'*1801},{'total':True},{'total':101},{'extra':'x'},{'mode':'other'}):
            self.assertEqual(self.grade(**payload)[0],400)
        self.assertEqual(self.request('POST','/api/grade',{},headers={'Origin':'https://evil.invalid'})[0],403)
        self.assertFalse(self.upstream_calls)
    def test_missing_key_is_clear(self):
        with mock.patch.dict(os.environ, {'GROQ_API_KEY':''}):
            status,_,body=self.grade()
        self.assertEqual(status,503)
        self.assertIn('غير مهيأة',json.loads(body)['error'])
    def test_reject_wrong_total_and_unknown_properties(self):
        self.response({'verdict':'صحيح','score':2,'total':2,'wrong_points':[],'notes':''})
        self.assertEqual(self.grade()[0],502)
    def test_unclear_never_gets_score(self):
        self.response({'verdict':'غير واضح','score':1,'total':1,'wrong_points':[],'notes':'النص غير مقروء'})
        self.assertEqual(self.grade()[0],502)
    def test_quiz_all_fifteen_corrections_survive(self):
        expected={'verdict':'خاطئ','score':0,'total':15,'wrong_points':[f'السؤال {i}: الصواب الرق' for i in range(1,16)],'notes':''}
        self.response(expected)
        status,_,body=self.grade(mode='quiz',total=15)
        self.assertEqual(status,200)
        self.assertEqual(json.loads(body)['wrong_points'],expected['wrong_points'])
    def test_truncated_answer_never_becomes_grade(self):
        self.upstream_body=json.dumps({'choices':[{'finish_reason':'length','message':{'content':'{}'}}]}).encode()
        self.assertEqual(self.grade()[0],502)
    def test_unclear_result_has_no_grade(self):
        expected={'verdict':'غير واضح','score':None,'total':1,'wrong_points':[],'notes':'أعد التصوير'}
        self.response(expected)
        self.assertEqual(json.loads(self.grade()[2]),expected)
    def test_summary_five_bounded_calls(self):
        values=[{'prompt':f'العبارة {i} ____','answer':'الرق','explanation':'من موانع الإرث'} for i in range(5)]
        def provider(route,payload,**kwargs):
            self.assertEqual(payload['max_tokens'],150)
            return json.dumps({'choices':[{'message':{'content':json.dumps(values.pop(0))}}]}).encode()
        with mock.patch.object(self.module,'_groq_request',side_effect=provider):
            status,_,body=self.request('POST','/api/summary-questions',{'summary':'من موانع الإرث الرق','lectureId':'lesson-1'})
        self.assertEqual(status,200)
        qs=json.loads(body)['questions']; self.assertEqual(len(qs),5)
        self.assertEqual(len({q['id'] for q in qs}),5)
    def test_active_teaching_job_blocks_even_after_quota_window(self):
        self.assertTrue(hasattr(self.server,'teaching_slots'),'Active teaching guard required')
        self.server.teaching_slots.acquire()
        try:
            status,_,body=self.grade()
            self.assertEqual(status,429)
            self.assertEqual(json.loads(body)['code'],'teaching_busy')
            self.assertFalse(self.upstream_calls)
        finally: self.server.teaching_slots.release()
    def test_teaching_slot_released_after_invalid_provider_response(self):
        self.response({})
        self.assertEqual(self.grade()[0],502)
        self.assertTrue(hasattr(self.server,'teaching_slots'),'Active teaching guard required')
        self.assertTrue(self.server.teaching_slots.acquire(blocking=False))
        self.server.teaching_slots.release()
    def test_summary_shares_one_absolute_deadline(self):
        clock=[100.0];deadlines=[]
        def complete(instruction,data,**kwargs):
            deadlines.append(kwargs.get('deadline'))
            clock[0]+=30
            return {'prompt':f"سؤال {len(deadlines)} ____",'answer':'أ','explanation':'ب'}
        with mock.patch.object(self.module.time,'monotonic',side_effect=lambda:clock[0]), mock.patch.object(self.module,'_teaching_completion',side_effect=complete):
            status,_,body=self.request('POST','/api/summary-questions',{'summary':'ملخص','lectureId':'a'})
        self.assertEqual(status,504)
        self.assertEqual(len(deadlines),3)
        self.assertTrue(all(d==175 for d in deadlines))
    def test_expired_provider_deadline_never_opens_transport(self):
        with self.assertRaises(self.module.GroqFailure) as failure:
            self.module._groq_request('chat/completions',{},deadline=self.module.time.monotonic()-1)
        self.assertEqual(failure.exception.status,504)
        self.assertFalse(self.upstream_calls)
    def test_summary_rejects_two_blanks(self):
        self.response({'prompt':'____ و ____','answer':'أ','explanation':'ب'})
        self.assertEqual(self.request('POST','/api/summary-questions',{'summary':'نص','lectureId':'a'})[0],502)

if __name__=='__main__': unittest.main()
