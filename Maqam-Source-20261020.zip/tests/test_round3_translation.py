import json
import unittest
import test_server as support

class TranslationTests(unittest.TestCase):
    request = support.ServerContractTests.request
    def setUp(self):
        support.ServerContractTests.setUp(self)
        self.upstream_body = json.dumps([[["Hello", "مرحبا", None, None]], None, "ar"]).encode()
    def translate(self, **changes):
        return self.request('POST', '/api/translate', {'text':'مرحبا','target':'en','source':'ar',**changes})
    def test_translation_and_cache(self):
        for _ in range(2):
            status, _, body = self.translate()
            self.assertEqual(status, 200)
            self.assertEqual(json.loads(body), {'text':'Hello','target':'en'})
        self.assertEqual(len(self.upstream_calls), 1)
        self.assertTrue(self.upstream_calls[0].full_url.startswith('https://translate.googleapis.com/translate_a/single?'))
    def test_invalid_translation_inputs(self):
        for change in ({'url':'http://127.0.0.1'}, {'source':'en'}, {'target':'gd'}, {'target':'iw'}, {'target':'https://evil.test'}, {'text':'x\r\nInjected'}, {'text':'x'*4001}):
            self.assertEqual(self.translate(**change)[0], 400, change)
        self.assertEqual(self.upstream_calls, [])
    def test_upstream_429_is_honest(self):
        self.upstream_status = 429
        status, headers, _ = self.translate()
        self.assertEqual(status, 429)
        self.assertTrue(headers.get('Retry-After'))
    def test_redirect_and_malformed_response_fail(self):
        self.upstream_status = 302
        self.upstream_headers = {'Location':'https://untrusted.invalid/'}
        self.assertEqual(self.translate()[0], 502)
        self.assertEqual(len(self.upstream_calls), 1)
        self.upstream_status = 200
        self.upstream_body = b'{"answer":"wrong format"}'
        self.assertEqual(self.translate()[0], 502)
    def test_cross_origin_is_denied(self):
        self.assertEqual(self.request('POST','/api/translate', {'text':'hi','target':'en','source':'ar'},headers={'Origin':'https://evil.test'})[0],403)

    def test_body_encoding_keys_and_framing(self):
        for body in (b'{"text":"hi","target":"en","source":"ar","target":"he"}', b'\xff', b'{"text":"hi","target":"en","source":"ar","host":"evil.test"}'):
            self.assertEqual(self.request('POST','/api/translate',raw_body=body)[0],400)
        self.assertEqual(self.request('POST','/api/translate',raw_body=b'x'*16385)[0],413)
        self.assertEqual(self.upstream_calls,[])
    def test_normalized_targets_and_ambiguous_codes(self):
        self.assertIn('he', self.server.translation_targets)
        self.assertIn('jv', self.server.translation_targets)
        for target in ('gd','jw','iw','ber','bat','rhg','bal','bci','tum','tiv','dyo','lmo','mad'):
            self.assertNotIn(target, self.server.translation_targets)
    def test_global_throttle_cache_and_cooldown_bounds(self):
        state = self.server.translation_state
        for i in range(60):
            self.assertTrue(state.admit(str(i))[0])
        self.assertFalse(state.admit('different-ip')[0])
        for i in range(300):
            state.save((str(i),'en'),'hello')
        self.assertEqual(len(state.cache),256)
        self.upstream_status = 429
        self.server.translation_state = self.module.TranslationState()
        self.assertEqual(self.translate()[0],429)
        self.assertEqual(self.translate()[0],429)
        self.assertEqual(len(self.upstream_calls),1)
    def test_upstream_size_timeout_invalid_are_errors(self):
        import socket
        for body in (b'x'*65537,b'[]',b'[[[null]]]',b'[[[" "]]]'):
            self.upstream_body = body
            self.assertEqual(self.translate()[0],502)
        self.upstream_exception = socket.timeout()
        self.assertEqual(self.translate()[0],502)

    def test_plain_text_newline_tab_are_query_encoded(self):
        import urllib.parse
        text = "سطر أول\nسطر ثان\tنص"
        self.assertEqual(self.translate(text=text)[0],200)
        url = self.upstream_calls[0].full_url
        self.assertNotIn("\n",url)
        self.assertNotIn("\t",url)
        self.assertIn("%0A",url)
        self.assertEqual(urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)['q'],[text])
        self.assertIn('ny',self.server.translation_targets)
