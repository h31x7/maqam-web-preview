const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync(require('node:path').join(__dirname,'../maqamooo.html'),'utf8');
test('glossary traverses existing translation wrappers and fragments, never interactive elements',()=>{
 let code=source.split('function MaqamGlossary({children}){')[1].split('\nfunction TeachingGlossaryAnswer')[0];code=code.slice(0,code.lastIndexOf('return <>{React.Children.map(children,walk)}</>}'))+'return React.Children.map(children,walk);';
 code=code.replace('<MaqamGlossaryText text={n}/>','({type:"definition",props:{text:n}})').replace('<MaqamGlossaryTranslatedText {...n.props}/>','({type:"translated-definition",props:n.props})');
 const ctx={children:null,Round3TranslatedText:{},Round3SourceContext:{Provider:{}},Round3TranslatedElement:{},React:{Fragment:{},isValidElement:n=>!!n?.type,cloneElement:(n,p,children)=>({...n,props:{...n.props,...p,children}}),Children:{map:(a,f)=>Array.isArray(a)?a.map(f):f(a)}}};
 const translated={type:ctx.Round3TranslatedText,props:{source:'موانع الإرث'}};
 ctx.children={type:ctx.Round3SourceContext.Provider,props:{value:true,children:{type:ctx.React.Fragment,props:{children:{type:'h3',props:{children:translated}}}}}};
 const run=()=>vm.runInNewContext('(function(children){'+code+'})(children)',ctx);assert.equal(run().props.children.props.children.props.children.type,'translated-definition');
 ctx.children={type:ctx.Round3TranslatedElement,props:{tag:'button',children:translated}};assert.equal(run(),ctx.children);
 ctx.children={type:'textarea',props:{children:translated}};assert.equal(run(),ctx.children);
});
test('stopped flashcards do not announce an incorrect answer',()=>assert.match(source,/\{\['correct','wrong'\]\.includes\(status\)&&<>/));
test('native page Escape handler yields to an open glossary before React handles it',()=>{const body=source.split('function FeedbackPageFrame(')[1],match=body.match(/const key=(e=>\{[\s\S]*?\});root.current.addEventListener/);assert.ok(match);let closed=0;const ctx={close:()=>closed++};vm.runInNewContext('this.key='+match[1],ctx);let prevented=false;ctx.key({key:'Escape',target:{closest:()=>({})},preventDefault:()=>prevented=true});assert.equal(closed,0);assert.equal(prevented,false);ctx.key({key:'Escape',target:{closest:()=>null},preventDefault:()=>prevented=true});assert.equal(closed,1);assert.equal(prevented,true);});
