const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const root = path.join(__dirname, '..');
const source=fs.readFileSync(path.join(root,'maqamooo.html'),'utf8').split('// ROUND4_DEMO_DOMAIN_START')[1].split('// ROUND4_DEMO_DOMAIN_END')[0];
const context = {Date, Intl, URL};
vm.runInNewContext(source+';this.api=Round4Data;',context);
const D = context.api;
const plain = value => JSON.parse(JSON.stringify(value));
const catalog = name => JSON.parse(fs.readFileSync(path.join(root, 'data', name + '.json'), 'utf8'));
const hash = value => crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
test('same seeded scenario survives fresh evaluation without shared mutable records', () => {
  assert.ok(D, 'Round4Data domain is available');
  const a=D.scenario(true),b=D.scenario(true);
  assert.equal(a.students.length,60);assert.equal(new Set(a.students.map(s=>s.name)).size,60);
  assert.deepEqual(plain(a),plain(b));a.students[0].name='changed';assert.notEqual(D.scenario(true).students[0].name,'changed');
  const fresh={Date,Intl,URL};vm.runInNewContext(source+';this.api=Round4Data;',fresh);assert.deepEqual(plain(b),plain(fresh.api.scenario(true)));
});
test('all sixty scores derive from completed quiz homework and attendance records', () => {
  assert.ok(D);const s=D.scenario(true),rows=D.ranking({demo:true});assert.equal(rows.length,60);assert.equal(rows[0].points,3892);
  assert.ok(new Set(rows.slice(1).map((r,i)=>rows[i].points-r.points)).size>10);
  rows.forEach((row,i)=>{if(i)assert.ok(rows[i-1].points>row.points);const records=s.records.filter(r=>r.studentId===row.id);for(const kind of ['quiz','homework','attendance'])assert.ok(records.some(r=>r.kind===kind));const points=records.reduce((n,r)=>n+(r.kind==='quiz'?r.correct:r.kind==='homework'&&r.submitted?5:r.kind==='attendance'&&r.present?1:0),0);assert.equal(row.points,points);});
});
test('mode off exposes actual records without generating fake data',()=>{
 assert.ok(D);const actual=[{id:'current',name:'طالب محلي',points:5}];assert.equal(D.scenario(false),null);assert.deepEqual(plain(D.ranking({demo:false,actual})),actual);assert.deepEqual(plain(D.grades({demo:false,term:1,year:1})),[]);assert.deepEqual(plain(D.activity({demo:false,actual:[{id:'real'}]})),[{id:'real'}]);assert.deepEqual(plain(D.notifications({demo:false,actual:[{id:'real'}]})),[{id:'real'}]);assert.deepEqual(plain(D.playlists(false)),[]);assert.deepEqual(plain(D.lectures([],false)),[]);
});
test('weekday curriculum and teacher profiles share exact five ordered subjects',()=>{
 assert.ok(D);const titles=['التفسير: مدارك التنزيل','أصول التفسير: مقدمة التفسير','العقيدة: العقيدة التدمرية','الحديث: بلوغ المرام','مصطلح الحديث: التقريرات السنية شرح البيقونية'];assert.deepEqual(plain(D.subjects.map(x=>x.title)),titles);assert.deepEqual(plain(D.subjects.map(x=>x.day)),[0,1,2,3,4]);assert.equal(D.teachers.length,5);assert.ok(D.teachers.every(t=>t.title==='الشيخ'&&!t.image&&!t.credentials&&t.announcements.length));const slots=catalog('haram-schedule');assert.equal(slots.length,5);assert.deepEqual(slots.map(s=>s.courses[0].title),titles);assert.ok(slots.every(s=>s.location==='القاعة الافتراضية'&&s.title==='الشيخ'));
});
test('term/year grades have bounded weights and unfinished current totals',()=>{
 assert.ok(D);for(const term of [1,2])for(const year of [1,2,3]){const rows=D.grades({demo:true,term,year});assert.equal(rows.length,5);for(const row of rows){const values=[row.homework,row.quiz,row.final,row.discipline];values.forEach((n,i)=>assert.ok(n===null||(n>=0&&n<=[20,30,40,10][i])));assert.equal(row.total,values.includes(null)?null:values.reduce((a,b)=>a+b,0));}if(term===1&&year===1){assert.ok(rows.every(r=>r.final===null));assert.equal(D.average(rows),null);}else assert.ok(Number.isFinite(D.average(rows)));}assert.deepEqual(plain(D.grades({demo:true,term:0,year:4})),[]);
});
test('demo notices preserve timestamps unread state and navigation targets',()=>{
 assert.ok(D);const rows=D.notifications({demo:true});assert.deepEqual(plain(rows.map(x=>x.title)),['مراجعة للمنهج بكرة','درجات الاختبار نزلت بالموقع']);assert.deepEqual(plain(rows.map(x=>x.target.view)),['timetable','grades']);assert.ok(rows.every(x=>x.read===false&&Number.isFinite(Date.parse(x.at))));assert.equal(D.notifications({demo:true,read:{[rows[0].id]:true}})[0].read,true);assert.equal(D.relativeTime(rows[0].at,Date.parse(rows[0].at)+120000),'قبل دقيقتين');assert.deepEqual(plain(D.notifications({demo:true}).map(x=>x.at)),plain(rows.map(x=>x.at)));
});
test('normalization preserves actual work and rejects corrupt demo state and weekends',()=>{
 assert.ok(D);const data={activity:[{id:'real'}],submissions:{a:{answer:'جواب'}},profile:{name:'اسم الطالب'},demoState:{ownStudentId:'bad',selection:{term:8,year:-1},notificationRead:{bad:true}}};const before=JSON.stringify(data),result=D.normalizeOwnData(data,true);assert.equal(JSON.stringify(data),before);assert.deepEqual(plain(result.activity),data.activity);assert.deepEqual(plain(result.submissions),data.submissions);assert.equal(result.profile.name,'اسم الطالب');assert.equal(result.demoState.ownStudentId,'demo-student-18');assert.deepEqual(plain(result.demoState.selection),{term:1,year:1});assert.equal(D.weekday('2026-10-24'),0);assert.equal(D.weekday('2026-10-23'),0);assert.equal(D.weekday('2026-10-22'),4);
});
test('demo teaching entries retain original media credit separately from fictional teacher',()=>{
 assert.ok(D);const samples=catalog('lectures').filter(x=>x.primary),demos=D.lectures(samples,true);assert.equal(demos.length,5);demos.forEach(l=>{const sample=samples.find(x=>x.videoId===l.youtubeId);assert.ok(sample);assert.equal(l.realCredit,sample.sheikh);assert.equal(l.demo,true);assert.ok(l.id.startsWith('demo-lecture-'));assert.notEqual(l.sheikh,l.realCredit);});
});
test('seven real credits and all source points/questions remain unchanged',()=>{
 assert.equal(catalog('lectures').length,16);assert.equal(hash(catalog('lectures').filter(x=>x.primary)),'66be4ac2696075f90e7bb2c368b1bec68f0657b482992fd0a9fd85093f04c0f3');assert.equal(hash(catalog('summaries').map(x=>({lectureRef:x.lectureRef,points:x.points}))),'521a0fd3f1b6ee215d8bc31428041b076af55c8f7aa99b455729a362a5280848');assert.equal(hash(catalog('quizzes').map(x=>({id:x.id,lectureRef:x.lectureRef,question:x.question,options:x.options,correctIndex:x.correctIndex,explanation:x.explanation,summaryPointIndex:x.summaryPointIndex,explanationKind:x.explanationKind}))),'556a2c6db2e7d516e2739576c04d2952b11cfb4b571c7b0cc29f9dfc994c008a');
});
test('nine secondary instructor headers are fictional and mutually consistent',()=>{
 assert.ok(D);for(const row of catalog('lectures').filter(x=>!x.primary)){assert.ok(D.teachers.some(t=>t.name===row.sheikh));assert.ok(row.sourceTitle.endsWith('الشيخ '+row.sheikh));assert.equal(row.sourceSheikh,'الشيخ: '+row.sheikh);assert.equal(catalog('summaries').find(s=>s.lectureRef===row.id).title,row.sourceTitle);assert.ok(catalog('quizzes').filter(q=>q.lectureRef===row.id).every(q=>q.sourceSheikh===row.sourceSheikh));}
});

test('uncompleted quiz and invalid awards cannot generate leaderboard points',()=>{
 assert.ok(D);assert.equal(D.recordPoints({kind:'quiz',correct:10,completed:false}),0);assert.equal(D.recordPoints({kind:'homework',submitted:false}),0);assert.equal(D.recordPoints({kind:'attendance',present:false}),0);assert.equal(D.recordPoints({kind:'other',points:999}),0);assert.equal(D.recordPoints({kind:'quiz',correct:101,completed:true}),100);
});

test('grade workflow step survives storage and corrupt step does not skip choices',()=>{
 assert.ok(D);assert.equal(D.readState({gradeStep:2,selection:{term:2,year:3}}).gradeStep,2);assert.equal(D.readState({gradeStep:99}).gradeStep,0);assert.equal(D.readState(null).gradeStep,0);
});

test('ranking periods derive only dated records and an inactive week stays empty',()=>{const now=Date.parse('2026-10-25T12:00:00+03:00');assert.equal(D.ranking({demo:true,period:'weekly',now}).length,0);const monthly=D.ranking({demo:true,period:'monthly',now});assert.ok(monthly.length>0);assert.ok(monthly[0].points<=D.ranking({demo:true,now})[0].points);assert.equal(D.readState({leaderboardPeriod:'monthly'}).leaderboardPeriod,'monthly');});
