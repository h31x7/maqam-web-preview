# Maqam original-source deployment

This release hosts the original uploaded Maqam application. The requested UI redesign has not been implemented.

The HTML is byte-identical to the upload. Image assets were absent from the archive.

The deployment copy of server.py removes the hardcoded API credential fallback and credential suffix logging. Runtime credentials are supplied only through Render environment variables; .env is excluded.

The index.html file is a byte-identical hosting alias for maqamooo.html. Production uses the existing server.serve_on_port(server.PORT) to listen on Render's assigned port. No application handlers or UI text are changed.
