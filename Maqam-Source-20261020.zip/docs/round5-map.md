# Round 5 architecture map — baseline and final status

The sections below retain the original read-only context audit before application edits; H/S references there are historical baseline references, not current line numbers. Final status and current anchors follow at the end.

Read-only context audit before application edits. References describe baseline maqamooo.html (H) and server.py (S); later changes may shift lines. No environment files or secret values inspected. This maps assumptions and dependencies, not vulnerability verdicts.

## Notes and persistence

- H617–649 Round4Study / Round4StudyStore owns IndexedDB `maqam_study_v1` version 1, stores `books`, `normalNotes`, `drafts`, keyed by id. Serialized transaction queue; subscribers fire after committed writes (632–635).
- Context normalization (624): quick; lecture {lectureId,title}; book {bookId,bookTitle,page, optional normalized x,y}. Note normalization (625): trimmed 1–8000-character text, bounded id, revision and timestamps. It reconstructs records and drops unknown fields. This is the durable thread/version schema seam.
- `mutateNote` (640; wrappers 644) implements put/delete, checks expected revision, increments note and affected book revisions, optionally removes draft in one transaction. `saveBook` (638) ALSO rewrites normalNotes, deletes absent book notes and clears book draft atomically. Metadata preservation and thread cascade deletion must cover both paths. Existing note-specific threads or durable note versions: nothing found.
- `loadBook` (637) joins book strokes with notes by context; `listNotes` (639) sorts newest first. `history/commit/undo/redo` (627–630) provide 40 in-memory reader snapshots, not durable note version history.
- Round4NotesPage (2858–2863) subscribes, filters text/context/source, opens reference pages and manually edits/deletes with expected revisions. Alive/request guards reject stale reads. Per-note action row is discussion entry seam.
- Floating quick action derives context from reader event, lecture payload or quick default (2865–2873). Round4QuickNoteCard / QuickDraftEditor (2875–2884) recover single `quick-note` draft. Submit commits via `putNote(...,0,'quick-note')`, then closes card. Retaining returned committed note is post-save discussion seam. Draft is separate from committed note.
- Round4BookReader (2895–2926) treats pins as normal notes. `apply` (2901) pushes reader history and schedules `book:<id>` draft after 500ms (2899–2900); editor changes are drafts until explicit `save` (2914) invokes saveBook. Dirty draft flushes on unmount (2907). `reloadSaved` preserves dirty draft (2915); recovery gated by book revision. `maqam:study-context` publishes book/page (2910). Visible reader pin does not imply committed note.

## Smart notes, chat and rendering

- Smart route H6119 mounts Round4ImageReview (2928–2991), persisting only `feedback.data.smartImageText` via onExtracted. Feedback normalization caps it to 1800 chars (2643,2651). No smart-note collection/stable note id. Confidence, result, attachment, sources are component state (2931). A durable identity/adapter is needed for per-note threads.
- Image review uses capability-based server vision then device OCR (2946–2965). Submit searches excerpts, calls Round4Vision.chat(reviewPrompt), validates verdicts (2969–2981). reviewPrompt (699–705) requires educational review/no fatwa/no invented sources. parseReview (678–697) accepts exact original statements, only three verdicts and known source ids, downgrading unsupported conclusions. Round4Vision.chat (744–749) always starts fresh conversation and returns no conversation id: policy precedent, not persistent chat controller.
- round3Chat (2595–2603) normalizes 20 chats/60 messages, 4000-char user and 12000-char assistant text, UUID conversation ids, ≤12 safe sources. Round3StudentChat (2605–2634) stores feedback.studentChats. FeedbackProvider.update (2764) persists before React state; storage key `maqam_feedback_v1` (2639), separate from note IndexedDB.
- send (2618–2629) persists user message, POSTs {query,user,conversation_id,inputs:{}} to /api/chat, validates answer and stores returned conversation. Busy/abort/unmount guards prevent duplicates/late writes. Retry clears backend context; regeneration of earlier answer branches to separate chat. Honest stop/retry explanations already exist.
- Reuse seams: r3-chat/r4-chat, bubbles, composer, sources, round4CopyText, regenerate and error/status actions are inline JSX at 2633, not separate exported components. Presentation device.compact and MaqamDialogFrame provide responsive/modal conventions (2606,2633).
- Anonymous identity (3690–3715): localStorage `maqam_uid` browser UUID, returned as student_UUID / visitor_UUID; namespace validated. New thread ownership must include browser user plus note id. Local thread id differs from provider conversation UUID.
- safeMarkdownUrl / renderMarkdownTokens / renderSafeMarkdown (3627–3685): allowlisted React elements, constrained link URLs, raw HTML rendered as text, images rendered as text, depth ≤24. Missing/failed marked returns plain text. Reuse for replies. Proposed note text requires explicit separate apply operation.

## Translation, word sync and playback

- Embedded MAQAM_LANGUAGE_SOURCE H470 mirrors data/languages.json. registry (475) normalizes legacy codes (473), RTL direction (474), disables duplicate/uncertain codes. Preserve picker behavior; actual provider availability remains runtime question.
- translateSegments (480) preserves array order, runs ≤3 requests concurrently with 300/600ms retries, validates nonempty output and supports abort/progress. requestTranslation (490–497) accepts ≤4000 chars: direct Google GET first; scalar /api/translate fallback only for fetch exception, not HTTP errors. Also called by UI translation: preserve its public contract when introducing batched lecture transport.
- Cache sourceIdentity (484) includes video id/source hash/Arabic texts. Key `maqam:subtitles:v4:<hash>:<code>` (485); readCache verifies full identity/count/nonempty strings (486); writes tolerate unavailable storage (487). Provider/model changes can use new namespace.
- segmentAt (476) requires matching video id, alignmentVerified=true, finite nonnegative time and positive durations. Timing is cumulative segment duration. visibleWords (477) reveals words proportionally to elapsed time, not word-level timestamps. Preserve verified-source binding.
- Round3LectureTranslation (3079–3105): language key `maqam:lecture-language:<lecture id/youtubeId/current>` (3081,3090–91), rate key `maqam:dubbing-rate` (.75/1/1.25/1.5). Prepared mode requires video identity/alignment (3083–84); otherwise transcript or summary is chunked (3088–89). Resolution order: built-in translations, cache, transport (3094–98). Abort/stale-result guards and honest errors/retry exist.
- Current play (3103) speaks current selectedText once via speechSynthesis, exact/base language voice matching (481), user-selected rate. Language/rate/unmount cancel speech; voices subscribe/cleanup (3093). No Groq speech, prefetch, timeline scheduling, ducking or video pause/seek/rate coupling in baseline. UI labels synthetic reading and unprepared text honestly (3104).
- Callers: LiveTranslationModal (1254) without player time; FeedbackLecture (3131) with real playerTime. Preserve optional standalone behavior.
- round3LoadYouTube (3117–18) shares loader promise, chains ready callback, resets after timeout/error. FeedbackLecture refs/state (3121–22) own private youtubeApi/nativeMedia/latestTime. Validates 11-character id (3123); YT.Player polls getCurrentTime every 250ms (3127). Expose narrow adapter for state/volume/rate rather than sharing opaque ref.
- Native video timeupdate (3131) advances subtitle clock; native audio lacks corresponding time updates. Watch progress stored under feedback.watchProgress[lecture.id], every 10sec and cleanup (3128). Playback ownership event fb:playback-owner (3065–68,3125) pauses lecture when mini owns playback. fbLectureMediaCommand (3071–75) only supports play/pause. New audio scheduler must stop and restore ducked volume on ownership transfer/unmount.

## Server boundaries

- S806–902 POST routes only chat/translate/upload; OPTIONS separate set at 789. _begin (644–675) validates Host and supplied Origin. One Content-Length, no Transfer-Encoding, UTF-8 JSON ≤16384 bytes, 10sec receive deadline. _parse_json (179–193) rejects duplicate keys and nonfinite constants.
- /api/chat (874–892) validates allowed fields; query ≤4000; canonical student_/visitor_ browser UUID (122–135); optional canonical conversation UUID; ≤20 scalar inputs, 4096 serialized bytes (196–209); owned upload ids. Socket-IP limit 20/minute shared with uploads (259–276,818–821), forwarding headers ignored.
- handle_dify_chat (983–1023): server environment config, HTTPS endpoint validation (169–176), no redirects, timeout 20sec, response ≤1MiB. Returns success/answer/conversation/message/sources. Citation metadata comes only from provider retrieval (225–248), titles/URLs bounded. Provider429→generic503, timeout→504, other upstream→502; no retries. No note-specific or religious policy established server-side.
- Existing translate exact schema {text,target,source}, source ar, scalar text ≤4000, bounded control chars, repository-derived target allowlist (865–873,542–547). handle_translation (904–954) calls Google translate with 8sec timeout/read deadline, ≤64KiB response, validated concatenated rows and ≤16000-char output {text,target}.
- TranslationState (499–539): lock-protected process LRU keyed (text,target), 256 entries/1hr TTL; IP/global60 requests/minute; upstream429 establishes60sec cooldown and Retry-After. Admission before cache. No batch Groq, speech/model discovery/backoff in baseline.
- Static _path (677–691) excludes hidden segments/traversal/encoding ambiguity. _serve (693–743) allows explicit HTML/data manifests and constrained asset extensions, root containment, no symlink components; /.env excluded. _json no-store (606–620); _error fixed generic responses (622–639); logs suppressed (593–595). Reuse bounded parsers, admission, errors, redirect refusal; add state in create_server (1026–1047).

## Assumptions and follow-through

Storage may fail; retain editable text and transaction errors. Reader book and note revisions are coupled; stale reader snapshots must not overwrite newer thread/version metadata. Backend may omit structured edits/citations: delimiter enforcement currently nothing found. Preserve normal-message fallback and treat model source names only as unverified text unless backend supplies citations. Live credentials, service availability and Groq models were not tested by this context pass.

Existing targeted tests: tests/round4-study.test.js, tests/client-security.test.js, tests/round3-translation.test.js (identity, seek-derived reveals, ordering/concurrency, abort/failure, voice matching, cache invalidation). Existing synchronized dubbing test: nothing found.


## Final implementation status — 2026-10-25

Initial UI integration: dfe5554; Group A: dfc9505; Groq server: 7393ab8; server hardening: 32dbc7c; Edge client: df141a7; Edge server/launcher: 02a78d6. The user subsequently explicitly approved completing and publishing, superseding the earlier publishing restriction and automatic approval rejection. Root is verifying release/deployment; no successful public deployment is claimed by this map yet.

- Complete in code: Group A durable per-note/browser discussions, shared Maajem presentation, explicit revision review/apply/ignore, versions/restore, quick/pin/lecture/smart entry points, privacy and active-panel refresh restore. Reader saves preserve live metadata; deleting notes/pins removes embedded threads. Note-only UI fixes include mobile bubble overflow and hiding the quick FAB while discussion is open.
- Complete in code: Group B strict Groq batch/speech and optional Edge MP3 server boundaries, server-only configuration, safe capability metadata, model setup checks, bounded retries/errors, v5 translation cache and explicit functioning legacy fallback, voice choice and cancellable timeline-reading scheduler/media adapter. Root added explicit selector labels and safe terms-required UI.
- Edge contract: provider=edge metadata advertises exact locale, lowercase alias and base-language entries with discovered voice IDs/defaults and model=edge-tts; maxCharacters remains 200. POST preserves exact {text,language,voice?}, strict membership and origin/rate checks; Edge returns audio/mpeg<=2MiB while Groq remains AR/EN WAV. Discovery cache is 6h with 30s failure cooldown, discovery deadline 10s and synthesis deadline 24s. edge-tts==7.3.1 is pinned, local launcher loads allowlisted environment and prefers ignored .venv. No key is required for Edge.
- Independent Edge client review: df141a7 matches the actual 02a78d6 server fields, voice associations, MP3 MIME/frame envelope and provider-specific WAV/MP3 handling. Provider selection remains server-only; existing generation cancellation/prefetch/volume logic is reused. No blocking mismatch identified for the current language registry (regional entries are zh-CN and zh-TW, both advertised by Edge). See round5-group-b-review.md for limits.
- Complete authorized addition: homepage stream removed; student stream retained and browser-verified.
- Automated evidence: 199 JavaScript tests pass; Python ran 92 tests with 2 skipped and no failures; JSX parses and diff whitespace checks pass. Differential reports are in round5-notes-review.md and round5-group-b-review.md.
- Browser/layout evidence: 16 baseline/final comparison screenshots at 390/1440, dark/light, RTL, plus 2 homepage/student scope captures in screenshots/round5. All dimensions were checked. Baseline is7720015. Eight language selections and unavailable/browser-fallback states exercised. Full screenshot index is in round5-changelog.md.
- Real fallback API: scalar translation returns 200/nonempty output for en,ur,tr,id,fr,ru,fa,bn with up to 3 workers. This does not prove synchronized subtitle playback; no captions/timings were invented.
- Current provider evidence: user-supplied qwen/qwen3.8-27b translation with max_tokens:150 returned 200 live. Edge discovery found 322 voices/75 base languages; Arabic, English and Urdu synthesis returned valid MP3 (25632/18576/20160 bytes). Edge is selected by server-only TTS_PROVIDER=edge; when omitted, optional Groq remains the default. Groq /models returned 200 and both Orpheus models exist, but Groq speech still requires unaccepted model terms (provider 400, local 503 groq_terms_required). Dify /api/chat remains locally 503; successful live note edits are not claimed.
- Source limitation: existing 7 real videos have no verified captions/transcript in this build; full synchronized subtitle/dubbing provider QA is blocked. Standalone mode remains explicitly labelled.
- Security evidence: local key is configured only in ignored .env/server environment; root's served/static/tracked checks found no key exposure. No actual key values were inspected for this map. CodeQL application extraction is blocked by host Java writable-directory checks; there is no application scan or clean finding count. See round5-codeql.md.
- Publishing is now explicitly user-authorized. Root is verifying the deployment and public URL; no successful deployment is asserted until its checks finish. Render/local setup and the remaining matrix are in round5-changelog.md.

## Current symbol index

Current anchors as of this draft; later formatting may shift lines. Symbols are authoritative search keys. H means maqamooo.html; S means server.py.

| Area | Current anchor | Final ownership/behavior |
|---|---|---|
| Translation/speech client domain | H530 Round5Media | Same-origin batch/speech, bounded split/cache/prefetch, generation cancellation, timeline/volume |
| Notes domain/store | H659 Round4Study; H705 Round4StudyStore | Existing IndexedDB normalNotes records own threads/versions |
| Atomic reader/note persistence | H689 saveBook; H691 mutateNote; H696 updateThread; H699 saveSmart | Merge live metadata; note/book revision versus thread revision; smart stale-save guard |
| Shared Maajem presentation | H2662 MaajemMessage; H2663 MaajemComposer | Used by H2712 Round3StudentChat and note discussion |
| Note prompt/revision parser | H2665 Round5NotePolicy | <=4000 complete query, <=1500 question, strict single bounded delimited proposal |
| Note overlay and responsive styles | H2671 Round5NoteChatStyles; H2672 Round5NoteChatHost; H2678 Round5NoteDiscussion | Active-frame host, durable selected note, apply/ignore/manual/history/privacy/errors |
| Smart adapter | H2704 Round5SmartNotes | Durable smart-current note, existing OCR review retained |
| Normal/quick/pin note UI | H2960 Round4NoteEditor; H2965 Round4NotesPage; H2972 Round4QuickNotes; H2986 Round4QuickDraftEditor | Discussion entry and saved-result actions |
| Reader and OCR | H2997 Round4BookReader; H3036 Round4ImageReview | Existing rendering/OCR and explicit reader save preserved |
| Active view overlay host | H3105 FeedbackPageFrame | Host lives inside active modal ownership; no inert sibling panel |
| Lecture controls/adapter | H3187 Round3LectureTranslation; H3228 FeedbackLecture | Shared language picker, explicit engine/voice/terms states, YouTube/native clock adapter |
| Speech/translation handlers | S946 handle_groq_translation; S970 handle_edge_speech; S985 handle_groq_speech | Strict batch output, bounded MP3 or validated PCM WAV |
| Public config and upstream | S1169 _groq_setting; S1205 _groq_request | Credential-copy rejection, fixed Groq HTTPS/no redirects, bounded transport, safe terms error |
| Edge discovery/audio | S1280 EdgeSpeechState; S1331 _speech_capabilities; S1366 _edge_audio | Discovered locale/base voices, provider dispatch, strict membership, bounded MP3 |
| Setup and listener | S1397 validate_groq_models; S1423 create_server | Background Groq/Edge setup checks, existing lifecycle/limiters retained |

The original baseline “nothing found” entries for threads, version history, structured edits and synced-reading tests are superseded by the implemented paths and tests above. The original absence of verified video captions remains an actual content limitation.
