# Final backend and grading review

Scope: integrated `maqamooo.html` and `server.py` diff against `80c179e`. Read-only review; only this report was written. No real provider calls or broad suite runs.

## Defects

### P2 — Deleting a reference leaves its original file permanently in IndexedDB

Locations: `maqamooo.html:3296` (save), `maqamooo.html:3307` (delete).

`saveModel` commits the original image/PDF through `fbPutFile`, then saves its metadata with `f.update`. The delete action removes only the teachingModels record and never invokes the existing `fbDeleteFile(attachment.id)`. The same orphan occurs when the file write succeeds but the following localStorage write fails. Repeatedly save and delete a10MB reference: the visible model list empties but every original remains in the shared files store. The20-model cap therefore does not bound disk use, and private originals remain after the user deletes the reference. Delete the owned attachment when deleting its model and roll back a newly written attachment when metadata persistence fails; report file-cleanup failure rather than silently declaring removal complete.

### P2 — Clearing the editable score silently approves zero

Location: `maqamooo.html:3303`.

After an incorrect draft arrives, clear its number input, keep the incorrect verdict and nonempty wrong-point list, and press اعتماد. Input onChange sets `draft.score` to the empty string. `Number(draft.score)` converts that empty string to0, and every subsequent validation passes. A missing grade is consequently persisted as an approved zero. Reject an empty/null score before numerical conversion; an explicit typed0 remains a valid score.

### P2 — Summary lifetime can outlast the client and overlap the next teaching budget

Locations: `maqamooo.html:3190`; `server.py:980`, `server.py:995`, `server.py:1289`.

The integrated client aborts after90seconds. The server generates five questions sequentially, and `_groq_request` has a fresh24-second deadline for each call, including its existing bounded retry behavior. There is no request-wide teaching deadline or disconnect check between calls. Five valid slow calls can therefore take approximately120seconds: the browser discards the result at90s and shows fallback while the server continues consuming the provider budget.

The one/minute teaching limiter is charged once at admission, not per actual provider call, and does not retain an active-work lease. At t=60 another grading request can be admitted while the first summary still has calls4/5 outstanding. Those two150-token outputs plus a750-token grading output reserve1050 tokens in the same subsequent minute, exceeding the intended1000 budget. This requires slow provider responses but follows directly from the supported deadlines. Give the operation a bounded total lifetime and prevent overlap with active teaching work, or account token reservations per upstream call. Keep client timeout compatible with the resulting total lifetime. This is separate from existing translation/speech usage, which already shares the upstream account and may cause normal provider429.

### P3 — Persisted teaching records do not enforce the invariants required for new records

Location: `maqamooo.html:2814`.

The new read parser preserves the fields, but admits an incorrect grade with score==total and no wrong_points, no mode/modelId/approvedAt; it also admits a homework model with total15. These are values the backend and approval path reject for newly created records. A bounded Node VM check against the actual FEEDBACK_DOMAIN block restored both `{id:'m',title:'x',text:'x',mode:'homework',total:15}` and `{id:'g',verdict:'خاطئ',score:15,total:15,wrong_points:[]}` unchanged. This primarily affects corrupted/imported local data, since normal creation writes valid values. Apply the same total/mode/verdict/score/correction invariants on read, and explicitly pick the intended fields rather than preserving every scalar through stringsOnly. No script execution was found: rendered reference text remains React text and nested objects are removed.

## Verification and checked boundaries

- `python -m unittest discover -s tests -p test_teaching_ai.py`:10 tests passed in0.667s. These cover strict input, cross-origin rejection, missing provider configuration, grade/total consistency, unclear null score,15 retained corrections, output truncation rejection and five one-blank summary questions.
- Node VM executed only the existing feedbackDomain code, confirming the read-parser examples and empty-string numeric conversion above.
- Endpoints inherit bounded Content-Length/JSON/content-type/body deadline and same-origin checks; new dedicated input and global teaching limiters are present. Model and paper image/PDF originals remain local; only bounded edited text is posted. Credential values are not included in the returned records; incomplete provider output is rejected. No new origin bypass or executable-content sink was identified in the reviewed diff.
- Approval is invalidated on paper/model selection changes and unknown/unclear drafts cannot be approved normally. Provider results do not directly alter the student gradebook or points.
- Browser/OCR/camera/provider latency behavior was not exercised in this review. The parent is performing browser verification.

## Documentation discrepancy

`docs/teaching-grading-map.md` says there are no automatic teaching retries and refers to20-second upstream calls. The reused `_groq_request` actually makes up to3 attempts for429/5xx under its24-second deadline. Update that statement when fixing or documenting the lifecycle; do not claim the teaching limiter guarantees actual total provider usage across overlapping work.

## Fix follow-up

The parent authorized implementation after this review. `server.py` now has one active teaching-job guard released in finally and a shared75-second teaching deadline passed to all Groq calls; the existing transport24-second ceiling remains and individual socket reads are clamped to the remaining deadline. Targeted Python checks increased from10 to14 and pass.

`work/teaching/grading.jsx` now rolls back newly written reference blobs when metadata persistence fails, deletes owned originals before metadata retirement with retryable errors, rejects blank scores and bounds edited corrections to the persisted schema. `work/teaching/storage-validation.js` supplies explicit model/grade validators, including model identity, numeric timestamps and consistent verdict/score/correction rules, for the parent to integrate. Nine targeted Node checks pass after red/green development; the updated JSX parses. This follow-up does not claim the parent HTML integration is complete or that past orphaned files have been migrated.
