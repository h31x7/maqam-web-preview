# Catalog machine transcripts — 2026-10-26

Six additional public recordings prepared and publication expressly authorized by the user, including Groq resource consumption. Seven registered recordings now have actual unreviewed Whisper-large-v3 transcripts. Catalog records with no videoId have no public source and remain unchanged. No UI, API, server, key, dependency or environment changes.

## Preparation

Existing bounded yt-dlp / range bridge / ffmpeg / Whisper path used. Full decoded audio coverage and strict timestamp validation retained. Private ASR cache keyed to extracted audio hash avoided repeated requests during validation. Whisper initially hallucinated repeated text in an entirely silent 599.943-second chunk with overshooting timestamps; the invalid result was rejected. Offline validation decoded actual local chunks to 16-bit mono PCM: entirely zero samples remain silence gaps, and rows whose whole available interval is exactly digital zero are omitted. No quiet-speech threshold, invented text or timestamp clamp used. Remaining rows pass the unchanged server schema. This is automated integrity validation, not human scholarly review.

All seven source files passed identity/duration/nonoverlap/size/segment validation. A fresh server seed created seven completed jobs. Exact counts and SHA-256 are in catalog-transcripts.json. C5b3LdzYkEc starts with a long silent introduction; subtitle absence there is intentional.

## Tests and differential review

214 JS tests and 19 focused source Python tests passed. Baseline ccbb55e: six new source JSON files plus documentation only; zero executable-source changes. No authentication, endpoint, handler, storage-key, dependency or security-policy changes. Sources enter existing _seed_prepared -> _lecture_validate_source -> completed job response -> bounded client translation/dubbing. Seven direct data files affect seven lecture views; zero new callable functions/routes. Existing source tests cover seed/schema/static boundaries. Prepared files remain outside static allowlist; packaging also scans for secrets.

Scoped risk low; zero security findings identified. Recommendation: approve after public source hashes match. No aggregate Python/CodeQL clean claim. No visual redesign; existing stop-control evidence retained. Deployment checks are documented separately after publication.

## Limits

All transcripts remain explicitly machine-generated and unreviewed; words/names may be wrong. The bundle does not implement unbounded live transcription. Fresh unbundled cloud acquisition failed in the observed Render probe; current seven sources avoid that step. No-source catalog records remain unavailable rather than fabricated.
