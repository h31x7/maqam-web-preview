# Final learning review

Scope: integrated `maqamooo.html` compared with baseline `80c179e`; plan `docs/teaching-feedback-plan.md`. Read-only source review; browser verification is still pending. No production edits made.

## Concrete defects

1. **P2 — New point activities are invisible in the activity screen.** `Round4Data.activity` (lines 666–670) discards its `actual` argument whenever demo mode is enabled. `Round4Activity` passes the persisted activities, but receives only generated records. A student can earn preparation/summary points and see the leaderboard rise without seeing that activity recorded in the displayed log. Outside demo mode, the same new records render with an empty title because the label map at line 3001 only covers quiz/homework/attendance. Merge recorded learning activities into the demo result and add labels for both new kinds.

2. **P2 — Flashcards do not expose the shared glossary.** `TeachingFlashcards` (lines 3185–3186) renders raw `card.prompt`, `card.answer` and missed-review strings. Terms including موانع الإرث، الموت الحكمي، العاصب therefore lack highlights/tooltips despite the explicit flashcard requirement. Wrap those text leaves with `MaqamGlossaryText`. The shared `MaqamGlossary` walker cannot repair this from outside because it intentionally skips custom components.

3. **P2 — Once-per-question protection expires after 1,000 summary awards.** `feedbackDomain.read` (line 2814) retains only the last 1,000 `learning.summaryBlanks` entries; `award` also keeps only the last 1,000 activity records (line 2857). With up to 500 stored lectures and five questions per lecture, normal content capacity exceeds this limit. After answering more than 1,000 questions and refreshing, an early question can have neither marker nor award ID remaining, so the same question earns another point. Retain a durable deduplication set independently of the bounded visible activity history.

## Checked without additional defects

- Five flashcards contain the exact requested question/answer strings. Deadline is 20 seconds, measured from absolute time; submission also checks the deadline. Timer/reveal effects clean up on stop and unmount. Final card exits through the result view before dereferencing a missing card.
- Prep stores the first attempt and its 50/10 award atomically through the existing feedback update. Persisted ordinary lesson IDs survive refresh; retry cannot replace the first result. Source question/title/generic selection follows the latest approved repair.
- Summary examples each contain one literal blank. The UI requires five valid questions, keeps per-run correct/wrong score separate from once-only points, and does not increase final score on future unanswered questions. Server IDs are deterministic `lectureId-blank-N`, preventing regeneration from creating new award IDs. Sample question keys are shared across lectures. Fetch cancellation, 90-second timeout and labeled independent fallback are present.
- Leaderboard includes recorded preparation/summary points in both demo and actual modes, respecting selected period.
- Weekly timetable renders five slots for each Sunday–Thursday (25 sessions), retaining all five existing subjects/teachers per day and week navigation. Calendar links include title, teacher, explicit start/end, Asia/Riyadh timezone and approved Teams URL when present; links use a separate tab with noopener.
- Removed employee routes are absent from the route allowlist and resolve to main. Sheikh routes remain.

## Integration follow-up — 2026-10-30
The findings above describe the pre-fix review. The integrated HTML now traverses intrinsic content and the existing translation/context wrappers, preserves interactive controls, and includes separate safe highlighted quiz-answer buttons. Flashcards, preparation, summary, lecture, homework and scholar lecture-list roots are covered; FeedbackNotice content is covered. First-tap opens idempotently; aliases/proclitics are matched. Audio failure keeps a manual Next path and scores, adds a bounded no-completion watchdog and common spoken Arabic option numbers. Summary client timeout is90s versus server75s. Preparation uses actual quiz metadata or a simple labelled fallback. Durable learning markers no longer expire at1000; recorded learning activity and labels appear in demo/non-demo activity views. Parent browser evidence and final verification are recorded in teaching-feedback-changelog.md.
