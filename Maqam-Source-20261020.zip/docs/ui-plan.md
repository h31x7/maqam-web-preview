# Maqam presentation rebuild — phased implementation plan

Goal: apply the supplied Teal depth direction while preserving every application behavior and Arabic word.

Architecture: retain React 18 UMD, Babel, Tailwind CDN and the single HTML. Canonical CSS tokens and presentational component hooks own the redesign. No application dependency, state, data or handler changes. server.py and .env remain byte-identical.

Specification: the user brief in this chat; source evidence is docs/ui-audit.md.

## Global constraints
- All props, event expressions, routes, conditional branches, hooks, endpoints, storage keys and data remain identical.
- Text remains word for word. Emoji used solely as chrome may be replaced by SVG, while strings/data stay unchanged.
- Existing accessibility and Google Translate logic remain intact.
- Screenshots: 390×844, 768×1024, 1440×1000, RTL.
- No new features or dependencies. Missing supplied assets and unreachable components are documented, never invented.

## Review focus
1. Arabic long labels at mobile width: wrap controls, never hide actions.
2. Calendar and reporting tables: contain horizontal scrolling inside their region.
3. Nested modals and floating controls: preserve original stacking and handlers.
4. Accessibility filters/reduced motion: preserve injected settings, use visible focus.
5. Chat error and pending states: retain original API/fallback behavior and transcript.

## Phases
- [x] Audit: component/behavior map before application edits.
- [ ] 0: capture baseline; define tokens, typography, shared CSS primitives, icon geometry.
- [ ] 1: entry/auth hierarchy, language/accessibility surfaces, focus and touch targets.
- [ ] 2: visitor home, Maajem, Wamadat, calendar, scholars, library and player/modal family.
- [ ] 3: student overview, academic tabs, homework/quiz/profile/lesson overlays; style unmounted Teams definition without mounting it.
- [ ] 4: teacher and organizer dashboards, reports/tables using the same tokens.
- [ ] 5: comprehensive static invariants, browser flows and responsive evidence; package deliverable.

Each phase: inspect affected component markup → add presentation hooks/CSS only → compare protected source against baseline → capture/review at all three widths when browser available → record differential review → commit locally. Stop progression on a proven regression; record unavailable checks honestly.

## Canonical owners
Runtime tokens: inline style#maqam-design-system. Existing components retain behavioral ownership. Shared button/input/nav/dialog/list/table CSS recipes own appearance. Existing LanguageSelectorModal, AccessibilityModal, ModernVideoPlayer, MiniFloatingAudioPlayer and HijriCalendarSchedule remain canonical.

## Execution ledger
2026-10-20: audit completed before application edits. Archive contains no assets. Native Python alias unavailable; bundled Python selected. Local server started but loopback access currently unavailable from shell and managed browser (timeouts). Baseline capture pending environment recovery; no fabricated evidence.
