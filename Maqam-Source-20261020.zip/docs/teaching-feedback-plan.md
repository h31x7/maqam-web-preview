# Teaching feedback implementation — 2026-10-29

User source: attached Pasted text7a5adb7c. Explicit request is modifying existing app, no redesign. Baseline HEAD80c179e. Newbranchfeat/teaching-learning-round. Existing styling viaDESIGN.md and shared fb components; Thmanyah headings/bodyfont unchanged. New server endpoints explicitly authorized in this request; existing .env and secrets untouched.

## Map and phases
1. MainScreen entry employee card; SplitAuthScreen employee branch; OrganizersDashboard/EmployeeDashboard; App whitelists/hashrestore/navigation/branch; fbDashboardBlocked. Remove employee UI/routes. Keep sheikh tools. Unknown hashes canonical main. Mobile new grading view remains available while existing desktop sheikh dashboards remain gated; roleentry opens grading directly on mobile (new camera requirement), directory remainsMore.
2. server.py request allowlist/readJSON/origin/limiters/Groq helpers → bounded /api/grade and /api/summary-questions. TeachingSmartGrading inline frontend, editable model/extraction, existing IDBfiles and local f.data models/results; result draft + manual approval. No automatic student marks or provider keys in browser.
3. TeachingAudioQuiz inline, Arabic synthesis/recognition with lifecycle cancellation and manual fallback; linked fromquizsection.
4. MaqamGlossary shared20entries, longestmatchboundaries, inlinefocus/taptooltips with reviewer note; wraps requestedcontent Reactnodes safely, noinnerHTML orDOMtextmutations.
5. Round4Timetable, sharedTeachingSchedule puremodule:25sessionsSun–Thu,5subjects rotated across5labeledfixedorganizational times; Calendarlinks URLencoded date/timeAsiaRiyadh and actualTeamslinkonly.
6. MaqamLearning andTeachingFlashcards,5exactcards20secdeadline, keyboardanswers/results/retry.
7. TeachingLessonPreparation nexttolessons andinsidelecture; firstattempt50/10 inlearning state andactivity atomically. Preserve sourceplayback/version history.
8. TeachingSummaryQuestions insideexisting summary;5real-summaryserverquestions whenavailable, labeledinheritancefallback otherwise,1pointpercorrectquestion once. Existinglocal leaderboard gets new activity kinds.

## Contract
Extend same feedback storage key with validated learning, teachingModels andteachingGrades only. No competing store or backend persistence claim. Extend award kinds while retaining originals, account once IDs inactivity. Existing local progress/drafts remain. AllnewUIRTLArabic fbclasses/no newglobalpalette. No additionaldependencies.

## Verification plan
TDD pureanswer/glossary/route/calendar/awardpersist tests plus backendvalidation/ratelimit/strictJSON tests. Full224baselineJSsuite andPythonappchecks. FreshBabelparse. Browseractualfeatures at1440×900,390×844,360×800 boththemes, unknownroutes, keyboardtooltip, timers,unsupported/deniedspeechstates andmanualfallback, modelrequired/uploads/OCR/PDF/grading missingkeyandactualknownfixture, points once+refresh. Externalmicrophonegrant requiresuseractionifnotavailable; reportlimitationshonestly. No publication required by this request; keep localworkingversion accessible.
