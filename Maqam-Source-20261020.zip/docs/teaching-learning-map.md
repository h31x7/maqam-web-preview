# Learning tools integration map

Owned fragment: `work/teaching/learning.jsx`. Insert into the existing React script after feedback globals. Render `<style>{TeachingLearningStyles}</style>` once in the existing shell. No new palette, storage key, dependency or backend call outside the documented summary endpoint.

## UI entry points

- `TeachingFlashcards`: student tool. Five exact requested cards, absolute 20-second deadline, answer typing, green/check and red/cross states, reduced-motion flip, six-second wrong-answer reveal, end score, missed answers and reset. Stop cancels interval/reveal callbacks; unmount cleans both. No point awards requested.
- `TeachingLessonPreparation({lecture})`: lesson tool; requires stable `lecture.id`, consumes string `lecture.summary`. Summary-based first-sentence recall shows source then three source-based/conservative points after answer. Missing summary explicitly labels a safe generic question. First attempt only awards 50/10 through existing points/activity logic.
- `TeachingSummaryQuestions({lecture})`: render alongside lecture summary. POST `/api/summary-questions` JSON `{summary,lectureId}` expects `{questions:[{id,prompt,answer,explanation}]}` with five unique IDs, exactly one literal `____` per question. Timeout 90 seconds; unmount/lesson/retry abort old request. Missing summary/service/error gives explicitly independent inheritance example, plus retry. It never describes sample questions as lecture content.

## Persistent state / parent obligations

`feedbackDomain.read` must preserve `learning` as `{preparation:{},summaryBlanks:{}}` in the existing store. Never create a new localStorage key. Immutable updates retain existing siblings.

- `learning.preparation[String(lecture.id)] = {correct:boolean,answer:string,at:ISO}`. First attempt writes result and `feedbackDomain.award(d,'preparation',lessonId,correct?50:10)` in one `f.update`. Persisted marker also prevents retry awards.
- `learning.summaryBlanks[questionKey] = {correct:true,at:ISO}`. `questionKey = (sample ? 'sample-inheritance-v1' : lectureId) + ':' + question.id`. Correct answer awards `feedbackDomain.award(d,'summary-blank',questionKey,1)` once. Sample IDs are shared across all lectures to avoid farming fallback points. Wrong attempts show answer/explanation and award nothing.
- Parent must allow `preparation` and `summary-blank` in award activity/ranking handling. Actual persisted activity is the scoring source.
- `MaqamLearning.normalize(text)` and `matchAnswer(given,expected,mode='text')` are shared pure exports. Mode `list` requires all tokens including extra-item rejection, ignores ordering and Arabic conjunctions. Text matching requires same word count/order, ignores diacritics/hamza and tolerates at most one edit per word of at least five letters; rejects changed negation. It does not use substring containment.

## Verification

`node --test tests/teaching-learning.test.js`: six domain checks pass (first observed red: missing marker). Covers normalization/list membership/order, missing/extra list items, negation, minor spelling, omission rejection, deadline clamp and sample schema. JSX/browser integration remains parent-owned because this fragment is deliberately not a standalone route. Browser checklist: complete flashcards correct/wrong/timeout; stop and navigate during reveal; reset; reduced motion; lesson first attempt/reopen; summary missing-key fallback and retry; five one-blank answers; refresh without duplicate points; narrow screen and keyboard focus.
