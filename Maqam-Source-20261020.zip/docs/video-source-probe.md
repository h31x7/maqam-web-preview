# Public video source probe

Tested 2026-10-25 21:08 UTC (2026-10-26 in Riyadh). Investigation only; no app code, secrets, cookies, authentication, proxies, or TLS changes used.

## Actual result

For the registered source `uJENBxFnDbU` (`data/lectures.json`, first record):

- `youtube-transcript-api==1.2.4` reports `TranscriptsDisabled`. No timed captions obtained.
- `yt-dlp==2026.10.21` independently returns empty `subtitles` and `automatic_captions` dictionaries.
- yt-dlp reports duration **4,395 seconds (73 minutes 15 seconds)**.
- Public HTTPS audio **format 139**, m4a / AAC (`mp4a.40.5`), **26,139,562 bytes**, exists. Formats 140 (m4a, 69,807,571 bytes), 249/250/251 (Opus/webm) also exist.
- An actual HTTP byte-range read against the extracted format-139 media URL succeeded: **206**, `Content-Type: audio/mp4`, `Content-Range: bytes 0-1023/26139562`, 1,024 bytes received, valid `ftyp` MP4 header. Thus metadata extraction is backed by a real usable audio read from this machine.
- yt-dlp warned that its optional EJS challenge solver was absent and some formats may be missing. The successful read above does not depend on installing it. Normal support should install a matched `yt-dlp[default]` distribution and supported JS runtime, rather than enabling arbitrary remote components dynamically.
- Signed media URLs were deliberately not written to evidence files. Extract afresh; never hardcode or treat them as permanent public assets.

Evidence/reproduction: `work/video-pipeline-probe/probe.py`, `result.json`, `audio_probe.py`, `audio-range-result.json`. Dependencies installed only into that scratch directory. Interpreter: bundled Codex Python; Node runtime supplied explicitly. No media file was downloaded beyond the 1KB range test. No paid/model API was invoked.

## Feasible application path and limits

Captions alone cannot repair this lecture. A feasible path is registered video ID -> bounded public audio extraction -> speech transcription with segment timestamps -> source transcript -> translation -> speech. A YouTube watch-page URL is HTML, not a speech-transcription media URL.

[Groq speech documentation](https://console.groq.com/docs/speech-to-text) supports a media `url` or file, `verbose_json`, segment/word timestamps, and common m4a/webm/mp3 formats. It documents 25 MB free / 100 MB developer file limits and a 25 MB attachment limit. This lecture's smallest exposed audio is above decimal 25 MB, so relying on a single free-tier request is unsafe. Transcode/chunk, transcribe every chunk, and add each chunk's start offset to returned timestamps. The full clip is 73m15s; a short excerpt must not be presented as a complete transcript or dub. Actual Groq retrieval of this signed URL, account limits, and transcription accuracy remain untested.

Local extraction success is **not evidence of extraction from Render**. The [youtube-transcript-api maintainer](https://github.com/jdepoix/youtube-transcript-api#working-around-ip-bans-requestblocked-or-ipblocked-exception) documents cloud-IP blocking. Probe the deployed host normally, and handle blocking as a source acquisition failure; no cookies, proxies or sign-in workarounds were used or recommended here.

[Render free service documentation](https://render.com/docs/free) says services sleep after 15 idle minutes, lose local changes on restart/spindown, may restart at any time, cannot attach persistent disks, and may be suspended for unusually high outbound traffic. Therefore long transcoding/transcription jobs need bounded concurrency, deadlines, visible job status, and durable storage for completed transcripts. In-memory or local-file completion cannot be assumed durable. None of those platform constraints are proof of a YouTube-specific block; only a real deployed-host test settles that.

[yt-dlp EJS documentation](https://github.com/yt-dlp/yt-dlp/wiki/EJS) describes the supported runtime and matching companion solver package. Keep extractor dependencies maintained because public-site extraction can change.
