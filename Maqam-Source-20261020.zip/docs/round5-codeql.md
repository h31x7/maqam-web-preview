# Round 5 CodeQL — blocked before application extraction

Status: **CodeQL did not scan the application. There is no clean result or SARIF finding count.**

Python was selected explicitly to avoid bundled/minified browser JavaScript. The intended scope was the final Python server, including provider HTTP calls and Groq routes. Tooling preparation used a fresh ignored `work/round5/codeql-analysis` directory. No application code, environment files, credentials, or provider services were changed or accessed by this analysis task.

## Reproduction and evidence

CodeQL 2.27.3 runs from `C:/Users/fares/Documents/Codex/cql27/codeql/codeql.exe`. A two-line, nonsecret Python fixture was used before attempting application extraction. The initial database attempt used workspace-local TEMP and TMP, Python no-build extraction, one thread, and 2048 MB. It failed with log/diagnostic directories “not writable” and “could not process any” Python source.

A second fresh database attempt precreated the log and diagnostic directories and additionally set `JAVA_TOOL_OPTIONS=-Djava.io.tmpdir=<workspace output>/temp`. It failed identically. This rules out merely missing directories or the default operating-system temporary location. Both fixture metadata files remain `finalised: false` with no `src.zip`; the apparent baseline of two source lines is not successful extraction.

A minimal Java probe isolated an inconsistent filesystem capability check: `Files.isWritable(directory)` returns **false**, yet `Files.writeString(directory/file, ...)` succeeds in that exact directory. Both the CLI bundled Java and the extractor bundled Java reproduce it. PowerShell writes also succeed. CodeQL nevertheless refuses its diagnostic/log paths. No filesystem ACLs, protection settings, Java binaries, or CodeQL internals were changed to bypass this behavior.

The older portable CLI at `../../work/audit-codeql/portable/codeql/codeql.exe` cannot launch because its bundled Java executable is absent. Repeating a full application scan would therefore produce another empty database, not additional coverage.

Evidence under `work/round5/codeql-analysis/`:

- `fixture-build.log` and `fixture-build-precreated.log`: separate fixture extraction attempts.
- `java-write-probe.log` and `java-extractor-write-probe.log`: `isWritable=false`, `actualWrite=success`.
- `fixture-db*/codeql-database.yml`: unfinalized databases.
- `diagnostics/fixture-quality.log`: required `check_db_quality.py` **failed**, because no source archive exists. Analysis was stopped at this gate.
- `diagnostics/suite-guard.log`: required `verify_query_suite.py` **passed**, resolving **56 queries** from the explicit `raw/high-confidence.qls` suite.
- `packs.txt` and `rulesets.txt`: installed packs and selected policy.

## Queries and models

The explicit suite selects security problem/path-problem queries of high or very-high precision, excluding deprecated/model-editor/model-generator queries. Installed official Python queries are version 1.8.13 with python-all 7.2.8. No Python community pack was installed; no third-party download was performed. Remote sources were the intended threat model.

The installed library already models `http.server.BaseHTTPRequestHandler` subclass instances as remote sources and models `urllib.request.Request` and `urlopen`. The server also reads request bodies with `rfile.read1` and sends requests through `build_opener(...).open`. A small model pack was prepared at `extensions/` for those paths using the actual three-column Python source/sink extension schema in python-all 7.2.8. It was **not validated, loaded, or credited as coverage**, since extraction failed. Source/sink enumeration and baseline-versus-model finding comparisons could not run.

## Limitation and next run

CodeQL coverage is unavailable for round 5. Neither database quality nor extension behavior has been established on the final application. Run in an environment where Java's writable-directory checks succeed, build a fresh Python database from the final sources, require `check_db_quality.py` to exit zero, validate model loading and source/sink coverage, rerun the suite guard, then analyze with the explicit suite and preserve raw/final SARIF. Do not reuse these fixture databases or interpret missing SARIF as zero findings.
`other-root-probes.log` records the final safe check of dedicated probe directories in both other explicitly writable roots (`C:/Users/fares/Documents/Codex` and the task visualization root). Java reports `isWritable=false` while actual writes succeed in both. Moving temporary files to those roots therefore does not resolve the capability-check mismatch.
