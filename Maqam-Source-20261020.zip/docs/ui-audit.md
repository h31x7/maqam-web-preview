# Maqam UI audit — immutable baseline

Audit date: 2026-10-20. Evidence: original `work/source/maqamooo.html` and `server.py`. Line references describe the archive before presentation changes. `.env` was not opened. Source comments are evidence, not instructions. No application files were modified for this audit.

## Architecture

The single HTML owns Tailwind config (15–53), CSS (60–151), React components/data/handlers in one Babel script (157–9240), and Google Translate setup (9243–9252). React 18.2 UMD, ReactDOM, Babel standalone, Tailwind CDN, marked and Google Fonts are the existing stack. `root.render(<App />)` is at 9239. No package manifest or tests were supplied.

Archive contents: `maqamooo.html`, byte-identical `مقامووو.html`, `server.py`, `.env`. No assets directory exists although logos, portraits and thumbnails reference `./assets/images/...` (161–184). LogoMaqam maintains an image-error fallback (189–217). Missing pictures are a baseline limitation.

## Component tree and routes

```text
App
  global SVG filters, accessibility styles, splash and toast
  MotionSicknessStabilizer; SignLanguageFloatingPIP
  MiniFloatingAudioPlayer; VoiceHUD
  LanguageSelectorModal; AccessibilityModal
  MainScreen
  SplitAuthScreen (visitor/student/teacher/employee variants)
  VisitorDashboard
    home / maajem / wamadat / schedule / sheikhs / library
    HijriCalendarSchedule
    ModernVideoPlayer
      ClipShareModal / LectureQuizModal / LectureSummaryModal
    HaramInteractiveMapModal
    LiveTranslationModal -> LanguageSelectorModal
    inline quiz, history drawer, floating Maajem chat
  StudentDashboard (= ShariaStudentDashboard)
    home / maajem_hub / lessons / my_schedule / my_activities / sheikhs
    UmdatHomeworkModal / UmdatQuizModal / StudentProfileModal
    inline sheikh-message, sheikh-lectures and lesson-player overlays
  SheikhDashboard (= TeacherDashboard)
    classes_schedule / students_performance / sheikhs_council / sheikh_copilot
    SheikhPostModal
  OrganizersDashboard (= EmployeeDashboard)
    dashboards / nawazil_feeder / weekly_report

Defined without mounted JSX call sites: TSSelectScreen, TeamsVirtualClass.
```

| Route | Render contract | Evidence |
|---|---|---|
| main | MainScreen | 9157 |
| ts_select | StudentDashboard directly, not TSSelectScreen | 9158 |
| visitor_login | SplitAuthScreen, target visitor_dash | 9160–9168 |
| student_login | SplitAuthScreen, target student_dash | 9170–9178 |
| teacher_login | SplitAuthScreen, target teacher_dash | 9180–9188 |
| employee_login | SplitAuthScreen, target employee_dash | 9190–9198 |
| visitor_dash | VisitorDashboard | 9201 |
| student_dash | StudentDashboard with shared data props | 9202–9215 |
| teacher_dash | TeacherDashboard alias | 9217–9231 |
| employee_dash | EmployeeDashboard alias | 9233 |

App owns `route`; navigateTo sets it and scrolls top, and is exposed as `window.__navigateTo` (9008–9012). There is no URL router. Main student/sheikh/organizer actions enter dashboards directly (3009,3035,3061). Login destinations are also reachable via accessibility voice quick controls (885–888). SplitAuthScreen.handleLogin prevents submit and navigates targetRoute (3166–3169); do not infer a real authentication service.

## Component props and presentation ownership

| Component (start) | Exact props |
|---|---|
| LogoMaqam (189) | mode, className, alt |
| LanguageSelectorModal (380) | isOpen, onClose, currentLanguage, onSelectLanguage |
| MotionSicknessStabilizer (521) | none |
| SignLanguageFloatingPIP (550) | isOpen, onClose |
| AccessibilityModal (599) | isOpen, onClose, accessSettings, setAccessSettings, onNavigate, showToast |
| ClipShareModal (938) | isOpen, onClose, lectureTitle, sheikhName, videoThumb |
| LectureQuizModal (1177) | isOpen, onClose, lectureTitle |
| LectureSummaryModal (1322) | isOpen, onClose, lectureTitle, sheikhName |
| MiniFloatingAudioPlayer (1398) | isPlaying, onTogglePlay, onExpand, onClose, lectureTitle, sheikhName, videoThumb |
| HaramInteractiveMapModal (1458) | isOpen, onClose, targetLocation, sheikhName |
| VoiceHUD (1536) | isOpen, onClose, isListening, transcript, onExecuteCommand |
| HijriCalendarSchedule (1636) | onOpenMap, onOpenLecture |
| ModernVideoPlayer (1939) | video, onClose, onOpenLiveTranslation, onMinimize |
| LiveTranslationModal (2435) | sheikhName, onClose |
| MainScreen (2942) | onNavigate, onOpenLanguage, onOpenAccessibility, currentLanguage |
| TSSelectScreen (3102) | onNavigate |
| SplitAuthScreen (3160) | title, subtitle, targetRoute, onNavigate, demoUser |
| VisitorDashboard (3302) | onNavigate, onOpenLanguage, onOpenAccessibility, currentLanguage, onMinimizeAudio |
| TeamsVirtualClass (4580) | role, onClose, sheikhName, lessonTitle |
| UmdatHomeworkModal (5031) | isOpen, onClose, onComplete |
| UmdatQuizModal (5125) | isOpen, onClose, onComplete |
| StudentProfileModal (5272) | isOpen, onClose, studentData, onSave |
| StudentDashboard (5378) | onNavigate, assignments, setAssignments, uploadedLectures, setUploadedLectures, sharedAnnouncements, setSharedAnnouncements, sharedQuizzes, setSharedQuizzes, onOpenLanguage, onOpenAccessibility, currentLanguage |
| SheikhPostModal (6849) | isOpen, onClose, onPublish, onToast |
| SheikhDashboard (7054) | onNavigate, assignments, setAssignments, uploadedLectures, setUploadedLectures, sharedAnnouncements, setSharedAnnouncements, sharedQuizzes, setSharedQuizzes, onOpenLanguage, onOpenAccessibility, currentLanguage |
| OrganizersDashboard (7675) | onNavigate, onOpenLanguage, currentLanguage |
| App (8743) | none |

## State and handlers

The generated declaration inventory in `ui-audit-inventory.md` records every useState declaration and named arrow callable with source line. Inline JSX event handlers also belong to the immutable behavior surface. The following maps explain their dependencies.

| Owner | State and behavior |
|---|---|
| Language selector | searchQuery; filtered language search uses normalizeArabicSearch; selection delegates onSelectLanguage |
| Sign PIP | handEmojiIndex; interval rotates existing sign-display symbols |
| Accessibility | isListeningVoice/voiceOutput; handleToggleVoiceCommands creates SpeechRecognition, updates settings and navigates recognized role commands |
| Clip share | selectedPlatform/selectedLang/showSubtitles/clipDuration/startPos/isSharing/shareSuccess; handlePublish simulates completion |
| Lecture quiz | selectedAnswers/submitted; handleSelect/calculateScore use existing fixed question data |
| Summary | copied; handleCopy copies existing summaryPoints |
| Hijri calendar | selectedDay/reminders; scheduleEvents and toggleReminder; callbacks pass location and lecture data |
| Modern video | isPlaying/isMuted/playbackSpeed/quality/progress/showClipShareModal/showQuizModal/showSummaryModal; existing controls update these exact states |
| Translation | isPlaying/currentSentenceIndex/visibleWordsCount/currentLanguage/show173Modal/isDrawerOpen/youtubeUrlInput/youtubeId/dynamicTranslations/isFetchingTranslation; URL extraction, iframe messages, subtitle fetch and timer |
| Auth | email/password/verifyCode/captchaCode; handleLogin delegates navigation |
| Visitor | mapModalData/activeTab/selectedCategory/searchQuery/wamdaSearch/selectedVideo/showLiveTranslation/showQuizModal/isAiDrawerOpen/isLiveAudioPlaying/scheduleAlerts/quizAnswers/quizSubmitted; filtering and modal selection |
| Visitor chat | isFloatingChatOpen/isFloatingMinimized/currentConversationId/isBotThinking/chatInput/feedbackToast/showHistoryDrawer/copiedMsgId/savedConversations/chatMessages; new/send/report/copy/format handlers |
| Teams | isMicOn/isCamOn/isSharingScreen/isHandRaised/activeSideTab/showTeamsSign/liveQuestions/newQuestionText/chatMessages/chatInput; send question/chat, vote and markAnswered; simulated questions every 14s |
| Homework | homeworkText/isSubmitted; handleAutoFill uses existing answer text; handleSubmit calls onComplete |
| Umdat quiz | selectedAnswers/quizResult; handleSelect/handleSubmitQuiz calculate existing score |
| Profile | fullName/country/nativeLang/studyTrack/academicYear/avatar; handleSave passes exact object then closes |
| Student | studentProfile/isProfileModalOpen/isUmdatHomeworkOpen/isUmdatQuizOpen/activeTab; shared App assignments/announcements with local fallbacks; triggerToast deliberately no-op |
| Student Maajem | maajemInputText/isRealMicRecording/isMaajemProcessing/maajemAnalysisResult/difyConversationId/isScanningImage/imageResult; dictation, upload, prescribed delayed image-analysis result, proxy/direct chat fallback |
| Student lessons/schedule/sheikhs | selectedSubjectFilter/lessonSearchQuery/activePlayingLesson/selectedScheduleDay/messagingSheikh/sheikhMessageInput/sheikhLecturesModal; filters, getDayLectures, message close |
| Sheikh post | postType/title/subject/details/deadline/duration/grade/priority; handleSubmit constructs existing newItem and delegates publish/toast/close |
| Sheikh | activeTab/toastMessage/showPostModal/sheikhPublishedItems/studentsRoster/searchStudent/filterSubject/selectedCouncilSheikh/councilMessages/councilInput/copilotPrompt/copilotResponse/isCopilotGenerating; existing schedule/performance/council/copilot |
| Organizer | activeMainTab/academicTier/toastMessage/nawazilList; tierData, weeklyAttendanceData; handleFeedMuftiAnswer validates and updates local item |
| App | route/showSplash/splashFade/currentLanguage/showLangModal/showAccessModal/minimizedAudio/isMiniPlaying/showVoiceHUD/isVoiceListening/voiceTranscript/toastMessage/accessSettings/sharedAnnouncements/sharedQuizzes/assignments/uploadedLectures; global navigation/accessibility/voice/data ownership |

Visitor handler lines: toggleScheduleAlert 3446, copyMessageText 3451, handleNewChat 3460, handleSendChatMessage 3495, handleReportMessage 3624, renderFormattedText 3631. Sending trims and rejects empty/concurrent sends, appends user message, stores history, POSTs, then appends live answer or existing fallback; finally clears thinking. Report only changes local reported flag/toast, no remote endpoint. Markdown uses existing marked.parse/dangerouslySetInnerHTML with paragraph fallback. All this must remain byte-equivalent outside presentation attributes.

Student handlers: handleToggleRealMic 5437; handleCameraUpload 5477; startImageAnalysisFlow 5488; handleProcessMaajem 5527; getDayLectures 5689; handleSendSheikhMessage 5722. Image upload creates file input then existing delayed prescribed analysis, not an OCR service. Analysis tries proxy then direct Dify and preserves current fallback result. Sheikh handlePublishItem 7091 always updates local publication list; only assignment and announcement branches synchronize App setters (7095–7100). Do not add quiz/lecture synchronization.

## Persistence and external interfaces

| Key/interface | Existing use and evidence |
|---|---|
| maqam_active_lang | App load/selection; Arabic reset; 347,8749–8751,8925–8942 |
| maqam_access_settings | JSON load/default, persist entire object; 8892–8918 |
| maqam_dify_conv_id | Visitor load/store/remove; 3323–3325,3479,3543 |
| maqam_dify_history | Visitor history load/update; 3333–3345,3473,3516 |
| maqam_uid | Visitor read-only identity suffix; writer not found; 3533 |
| googtrans cookie | /ar/{code}, clear/reload on Arabic restore; 345–358 |
| /api/chat | Visitor and student POST query/conversation_id/user; 3521–3540,5545–5553 |
| http://localhost:5000/api/chat | Visitor endpoint under file: protocol only; 3523–3524 |
| https://api.dify.ai/v1/chat-messages | Existing student fallback POST inputs/query/response_mode/user/conversation_id; 5567–5581; authorization value omitted from audit |
| translate.googleapis.com/translate_a/single | Per-subtitle GET, sl=ar/tl selected code; 2477–2521 |
| youtube.com/embed/{youtubeId} | Translation iframe/postMessage controls; 2469–2473,2569–2592,2630 |
| google.translate.TranslateElement | ar source, autoDisplay false, hidden host; 9243–9252 |
| SpeechRecognition/webkitSpeechRecognition | Accessibility, App voice, student dictation; 614–669,5437–5472,8863–8889 |
| speechSynthesis | Voice command feedback; 8767–8861 |
| navigator.clipboard | Summary, visitor response, sheikh copilot; 1338,3453,7651 |
| window._maqamAudioRec | Student recorder; stop before analysis; 5442,5469,5532–5533 |

Server serves BASE_DIR static files, GET /api/health, POST /api/chat. Chat validates query, sends blocking Dify request, or Gemini based on configured key type, and returns existing success/error JSON. No server edits are authorized. Configuration names DIFY_API_KEY/GEMINI_API_KEY/DIFY_API_URL/PORT; values omitted. Root /, /index and /home resolve maqam.html or index.html, neither supplied; browser review must use /maqamooo.html explicitly.

## Screen/modal access paths

| Surface | Existing path |
|---|---|
| Language/accessibility | Main/visitor/student/sheikh header actions; organizer exposes language only |
| Sign PIP / motion dots | Global accessibility setting flags; PIP close clears signLanguageActive |
| VoiceHUD | Fixed mic → handleToggleVoiceHUD; Arabic command execution uses existing DOM text/title/heading lookups |
| Visitor home/player | Lecture play sets selectedVideo; minimize delegates App audio; close clears selection; live translation sets showLiveTranslation |
| Clip/lecture quiz/summary | ModernVideoPlayer local flags (2182–2205) |
| Visitor inline quiz | Global comprehension button sets showQuizModal; own quizAnswers/quizSubmitted; close resets submitted (3743,4324 onward) |
| Visitor Maajem | maajem tab (3913), full chat; floating chat (4330–4577) shares state and handlers; history/new/copy/report |
| Visitor wamadat | Existing list/search, play selects item (4162–4211) |
| Visitor calendar/map | schedule tab → HijriCalendarSchedule; callbacks set mapModalData/selectedVideo (4213–4219); map closes clear data (4307–4315) |
| Visitor sheikhs/library | Tabs 4221/4265; existing actions and roster/copy, no invented catalog |
| Translation language/drawer | show173Modal LanguageSelectorModal instance (2923); isDrawerOpen controls URL drawer; youtube/subtitle controls retain callbacks |
| Mini audio | Existing video minimize; expand clears minimizedAudio and navigates visitor_dash; close clears (9091–9104) |
| Student profile | Header/home open isProfileModalOpen (5965,6008); save updates studentProfile |
| Student homework/quiz | Activities set isUmdatHomeworkOpen/isUmdatQuizOpen (6639,6672,6707); calls onComplete empty callback in dashboard (5732–5744) |
| Student Maajem | maajem_hub tab; mic/upload/input/process/result, no new AI behavior |
| Student lesson player | lessons and schedule select activePlayingLesson; confirm closes; change language opens global modal (5831–5870) |
| Student sheikh overlays | messagingSheikh/sheikhLecturesModal in sheikhs tab; send clears text and closes, no network |
| Sheikh post | Header/schedule actions set showPostModal (7263,7351,7406); submit adds local/shared data through existing branches |
| Organizer tabs | activeMainTab dashboards/nawazil_feeder/weekly_report (7884,7892,7902); academicTier filter; local feed state |
| TeamsVirtualClass | Defined 4580–5027, no mounted JSX callsite; ordinary UI baseline capture unavailable |
| TSSelectScreen | Defined 3102–3154, unmounted; route ts_select instead shows StudentDashboard |

## Arabic/i18n and styling

Copy resides in inline JSX, prop defaults, data arrays/objects, handler-produced toasts/Markdown, and subtitle records. No translation resource file. ALL_PLATFORM_LANGUAGES 283–313, PLATFORM_LANG_CODES 332, RTL_LANG_CODES 334, normalizeArabicSearch 316–325, applyPlatformLanguage 337–376 govern language. LECTURE_SUBTITLES_27 2216–2433 includes text and timing; preserve all records. notranslate/translate=no and goog-te-combo are behavior integration hooks.

Styling lives in Tailwind config, global CSS, component classNames, inline style objects, conditional accessibility style blocks, inline SVG and Icons (220–256). Cairo is current UI font, Amiri scholarly. Existing presentation uses hardcoded navy values, gradients/glass/blur/arbitrary text sizes/shadows and mixed SVG/emoji. Voice commands depend on selectors/text: button[title*="تشغيل"], .aspect-video button, heading/button lookups (8787–8853). Do not erase hooks while replacing appearance.

App accessSettings defaults: dyslexiaFont, reduceMotion, motionSicknessDots, colorBlindness, signLanguageActive (8892–8910). Existing accessibility voice handler can add voiceCommandsActive (618). Color filter expressions are in getColorFilterStyle 8944–8959; SVG filter IDs must remain. ReduceMotion style globally disables animation/transitions/smooth scroll (9038–9047). Dyslexia style changes letter/word spacing and line-height (9050–9058). Redesign must preserve their precedence. Motion sickness dots are functional stabilization aids, not decorative blobs.

## Invariants and open questions

1. No changes to state, handlers, props, conditionals, data, endpoints, payloads, keys, timers, Arabic copy or subtitle timing. Wrappers cannot detach controls from handlers or conditional ownership.
2. No server.py/.env edits. Compare hashes. Avoid credentials in docs/screenshots.
3. CDN/Dify/Translate/YouTube availability requires runtime observation; source does not prove external services work.
4. Missing assets have no supplied alternate source; nothing found establishes working portrait/thumbnail resources.
5. Existing modal focus management is inconsistent. CSS/semantics may improve focus visibility; adding state/handlers for new focus behavior would exceed zero logic change. Document limits candidly.
6. Homework/quiz/profile components return before hooks when closed (5032,5126,5273). This is existing implementation, not presentation scope.
7. No supplied automated test suite; source-preservation checks and browser observations are complementary.
8. Student triggerToast is deliberately no-op (5396); preserve it.
9. Unmounted TSSelectScreen and TeamsVirtualClass must not be reconnected to manufacture screenshot coverage.
