# Group A differential review

Scope: maqamooo.html note persistence/discussion, shared Maajem presentation extraction, tests/round5-notes.test.js, DESIGN.md and UX-CONTRACT.md. Baseline UI/store introduced in 4b8ed1d; latest HTML baseline 388d751. No server, credentials, media, lecture data, translation or publishing changes owned by this group.

Risk: medium data-integrity change plus existing high-risk external-chat/render boundaries. No unresolved security finding identified in this focused review. Conditional acceptance pending integrated browser QA and actual-provider verification. No claim of complete application security audit.

## Changed paths and blast radius
- saveBook: one runtime caller (reader). It now merges live embedded metadata and only appends text history when text changes. Existing book revision checks and foreign-note identity checks remain.
- putNote: three runtime callers (notes page, quick save, manual discussion edit); deleteNote: one. They retain the original expected revision transaction, book invalidation and draft cleanup while merging history/thread metadata.
- updateThread: two note-chat call sites. Atomic compare-and-swap on note/browser thread revision; missing note rejects. Thread-only writes do not increment note/book annotation revisions.
- applyRevision / restoreVersion: one runtime call site each, checking the original expected note revision in the actual write transaction.
- saveSmart: two adapter call sites; durable smart-current identity, revision guard against stale OCR save/delete, and no-op for unchanged text.
- MaajemMessage and MaajemComposer: two consumers each (student/note). Original Markdown allowlist, backend-only source list, keyboard composition guard, student copy/regenerate/feedback/voice/image controls remain.

## Adversarial cases checked
Late response after deletion cannot recreate a record. Stale reader snapshot cannot erase newer text or embedded conversations. A reader save during thread-only updates succeeds and merges latest metadata. Concurrent tabs cannot overwrite thread state with an old thread revision. A proposal generated before a manual edit is visibly stale and cannot apply. Invalid/multiple/reversed/empty/oversized edit delimiters remain normal messages; fallback replacement requires a separate explicit before/after review. Invalid identities/prototype names, provider UUIDs and unsafe citation URLs are rejected or normalized. Stored revisions are finite safe nonnegative integers. Note excerpts and questions fit the existing 4000-character query boundary. No browser provider keys or provider endpoint added.

## Evidence and limits
Targeted tests were observed failing before implementation, then passing; final full JavaScript suite and JSX parser commands are recorded in the handoff. Security/Markdown and existing student chat suites remain included. Strict Frontend Design Premium static audit scoped to a current copy of canonical HTML reported zero findings (work/round5-premium-audit.json); it does not execute JSX workflows. The initial unscoped audit was interrupted because it traversed private scratch dependencies; no success is claimed for it.

Browser QA belongs to the integrating root agent: 390/1440, RTL, light/dark, keyboard, note types, fixtures/live chat, save/apply/undo/refresh/delete, slow/error/stop. No actual provider reply was used in this group and no simulated answer was placed in product code. Religious accuracy remains a provider obligation constrained by the educational/no-fatwa/source prompt, not a guaranteed client verdict. Smart OCR review keeps its existing 1800-character editor; longer AI-edited text stays intact in the durable note and discussion, with an explicit excerpt notice in OCR view. History bounds: 20 prior texts, 40 messages per browser thread, 8 browser identities per note.
