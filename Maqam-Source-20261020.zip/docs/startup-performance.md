# Startup latency investigation — 25 October 2026

Live service: maqam-source-20261020, srv-dbbsrqei0phs73e3q6cg, confirmed F's workspace, current compute plan free. No hosting configuration, paid upgrade or publication performed during this investigation.

Two consecutive external GET measurements with gzip accepted: first response headers 33.00 s, completed 33.27 s; subsequent response headers 0.46 s, completed 0.77 s. Both HTTP 200, gzip and no-cache. The long first-response delay is consistent with idle wake-up of the confirmed free instance; measurements include network time and do not isolate every network component. Render documents free service sleep after 15 minutes and about a minute to wake: https://render.com/docs/free#spinning-down-on-idle . Paid compute starts at $7/month on the published pricing page: https://render.com/pricing . Changing the workspace subscription alone does not remove free service sleep.

## Prepared code improvements
- PDF.js 6.4.299 stays pinned with integrity/import map, but its roughly 459 KB module is now requested only when entering a reader. Removed eager module preload. The same MAQAM_PDF_READY contract returns one cached promise, with retry after a failed import. No new dependency or source architecture change.
- Google Translate loads asynchronously, so the optional external widget does not hold parsing/DOMContentLoaded and Babel startup. Existing callback and translation-ready event remain intact.
- Initial splash fade/removal shortened from 1200/1700 ms to 150/350 ms. Text, skip interaction and application navigation unchanged.
- No server.py or .env edits. Existing Render compression is already active; no redundant gzip change.

## Validation
Three targeted tests failed before implementation and passed after: no PDF import at startup, single cached import, retry after rejection, async translation/no eager preload. Full JavaScript suite 166 passing; JSX parse passes; diff whitespace check passes. Browser local home and reader exercised, reader next-page control enabled and no console error entries. These code optimizations are local and not yet deployed; no claim that the measured live first-response delay is removed.

## Remaining decision
Keeping the same web-service URL while reliably eliminating free-instance idle wake-up requires paid compute. Await explicit spending authorization before changing the service plan. No keepalive automation or artificial traffic added.
