# Teaching grading and summary endpoint map

## Existing behavior and boundary
- `MaqamProxyHandler.do_POST`: existing host/origin checks, bounded Content-Length, strict JSON parsing, JSON content type, 10-second body deadline. Teaching endpoints reuse these checks. Original camera/photo and model attachments never leave the browser: local Round4Vision OCR and local PDF.js extraction supply editable text.
- Existing `fbPutFile` stores optional model originals in the existing IndexedDB files store. `f.update` writes the existing feedback store. HTML integration must preserve `teachingModels` and `teachingGrades` in `feedbackDomain.read`, which otherwise drops unknown fields on refresh.
- PDF helper in this checkout is `window.loadMaqamPDF`, not `round3LoadPDFJS`. PDF text extraction: <=10 MB, <=30 pages, <=20,000 temporary extracted characters; user must edit to <=1,800 before saving. Scanned PDF has no guess/OCR fallback: ask for a clear image or typed reference. JPEG/PNG/WebP images use existing local OCR. OCR truncation is rejected and uncertain markers block grading until corrected from original.

## Integration
Insert `work/teaching/grading.jsx` into the existing Babel React scope before overlays. Route Sheikh tool to `<TeachingSmartGrading/>`. Reuses `FeedbackButton`, `FeedbackNotice`, `useFeedback`, `.fb-stack`, `.fb-panel`, `.fb-field`, `.fb-actions` and `.fb-check`.

New persisted feedback fields:
- `teachingModels`: max20 `{id,title,text,mode,total,attachment,createdAt}`. Text/title strings <=1800/100; mode homework or quiz; total integer1..100 (homework1). Attachment optional fbPutFile metadata. Validate data read from browser storage as untrusted; only render strings as text.
- `teachingGrades`: max100 `{id,modelId,mode,verdict,score,total,wrong_points,notes,approvedAt}`. Local manual approval only. No student gradebook/points mutation.

## Strict HTTP contracts
POST `/api/grade`: exactly `{mode,model_answer,student_answer,total}`. mode homework/quiz; each nonempty text <=1800 chars; total integer1..100, homework1. Returns exactly `{verdict,score,total,wrong_points,notes}`. Verdict صحيح/خاطئ/غير واضح. Unclear has null score and no wrong_points. Correct must have full score and no wrong_points; incorrect must have score below total and nonempty correction list. Bounded correction strings. Model output total must equal request total; no extra JSON properties. `finish_reason=length` or malformed/partial output ->502, never partial credit.

POST `/api/summary-questions`: exactly `{summary,lectureId}`. Nonempty summary<=1800 chars; lectureId1..100 ASCII alphanumeric/_/-. Returns `{questions:[{id,prompt,answer,explanation}]}` exactly5 distinct prompts, exactly one `____` blank each. IDs lectureId-blank-1..5. Partial generation fails the whole request; caller may fall back to explicitly labelled built-in sample questions.

## Provider and operational limits
Both endpoints use server-only GROQ_API_KEY and configured GROQ_TRANSLATE_MODEL. No new credentials or defaults. Missing either ->503 with clear Arabic setup message. No speculative Dify fallback. Supplied content is serialized as data behind system instructions to ignore embedded instructions, and output is structurally validated. This is a draft against the teacher reference, not a source of religious rulings.

One grading call max_tokens750; summaries five sequential calls max_tokens150 each. Existing translation max_tokens150 remains unchanged. Dedicated shared teaching quota admits one request/minute globally; pre-validation input guard20/min/IP. Each admitted teaching operation reserves at most750 output tokens. One active teaching operation is permitted globally, with a finally-released guard and a shared75-second deadline across all upstream calls; concurrent existing translation/speech has independent provider usage and can still trigger provider429. The existing Groq transport may retry up to three times for 429/5xx within its own 24-second deadline; it receives the shared teaching deadline so retries cannot extend that operation budget. `Retry-After` plus Arabic body `retryAfter` for teaching quota. Malformed input does not consume provider-output budget. JSON body maximum16384 bytes from existing boundary. Complete strict JSON required; long papers can exceed output budget and must be shortened rather than guessed. Text bounds support short worksheets; no claim of unlimited image-sheet grading.

## Verification
- `python -m unittest discover -s tests -p test_teaching_ai.py`: 14 tests, expected red before implementation, then green. Covers configured/missing provider, strict input/origin, draft schema, preserved15 corrections, truncated output rejection, unclear no-score,5 bounded summary calls and multiple blank rejection. Transport fixture only; no real API credit used.
- Parent should verify browser: two mode choices; missing-model block; save/reload/select model; input text; gallery/camera preview and retake; low-confidence OCR and editable confirmation; PDF extraction/no-text and oversize rejection; provider error/retry; editable draft; manual approval persisted locally; keyboard; mobile360/390 and desktop1440 overflow.
