# Round 3 implementation map
Base b2a59ab, branch feat/team-feedback-round-3. Audit precedes application edits.
Detailed item/component/line/state maps: [UI](round3-ui-context.md), [server](round3-server-context.md), [assets](round3-assets-context.md).

| Item | Component/files | Initial status |
|---|---|---|
| Assets | data JSON; brand, books, covers; server.py | Audited, not integrated |
| 1 Translation | LanguageSelectorModal/applyPlatformLanguage/LiveTranslationModal | Google layer exists; source library pending |
| 2 Reminders | FeedbackProvider/FeedbackNotificationsButton | Lecture subscription missing |
| 3 Live | MainScreen/Student/voice | Recording presented as live; config pending |
| 4 Cards | Visitor/Student/shared CSS | Targeted refinement pending |
| 5 Filters | Student lessons | Always expanded |
| 6 Watch | FeedbackLecture/AudioPlayer | Three-button footer/dubbing pending |
| 7 Playlists | Provider/Pages/More | Missing |
| 8 Activities | Student/my_activities | Explanatory text present |
| 9 Leaderboard | FeedbackLeaderboard/domain | Actual local activity; layout pending |
| 10 Stabilizer | MotionSicknessStabilizer/CSS | Alternating colors |
| 11 Timetable | FeedbackSchedule/Calendar/HijriCalendarSchedule | Monthly code to replace |
| 12 Student chat | student maajem_hub/visitor shared chat | Single-response view |
| 13 Smart notes | student ai_center/notes/More | Rename/route pending |
| 14 Research | Sheikh copilot/book indexes | Grounded search pending |
| 15 Mobile sheikhs | More/directory/profile | Existing; unresolved component reference |
| 16 Library | visitor/library/book data | Provided books not integrated |
| 17 Teams | TeamsButton/PublishingPanel | Safe opener; saved link editor missing |

Statuses are findings, not completion claims. Follow round3-changelog.md for verification.

Initial findings above are preserved. Current implementation/remaining acceptance: [2026-10-24 checkpoint](round3-checkpoint-2026-10-24.md).
