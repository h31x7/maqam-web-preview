# UI source declaration inventory

| Owner | Line | State | Setter |
|---|---:|---|---|
| LogoMaqam | 190 | imgError | setImgError |
| LanguageSelectorModal | 381 | searchQuery | setSearchQuery |
| SignLanguageFloatingPIP | 551 | handEmojiIndex | setHandEmojiIndex |
| AccessibilityModal | 607 | isListeningVoice | setIsListeningVoice |
| AccessibilityModal | 608 | voiceOutput | setVoiceOutput |
| ClipShareModal | 939 | selectedPlatform | setSelectedPlatform |
| ClipShareModal | 940 | selectedLang | setSelectedLang |
| ClipShareModal | 941 | showSubtitles | setShowSubtitles |
| ClipShareModal | 942 | clipDuration | setClipDuration |
| ClipShareModal | 943 | startPos | setStartPos |
| ClipShareModal | 944 | isSharing | setIsSharing |
| ClipShareModal | 945 | shareSuccess | setShareSuccess |
| LectureQuizModal | 1178 | selectedAnswers | setSelectedAnswers |
| LectureQuizModal | 1179 | submitted | setSubmitted |
| LectureSummaryModal | 1323 | copied | setCopied |
| HijriCalendarSchedule | 1637 | selectedDay | setSelectedDay |
| HijriCalendarSchedule | 1638 | reminders | setReminders |
| ModernVideoPlayer | 1940 | isPlaying | setIsPlaying |
| ModernVideoPlayer | 1941 | isMuted | setIsMuted |
| ModernVideoPlayer | 1942 | playbackSpeed | setPlaybackSpeed |
| ModernVideoPlayer | 1943 | quality | setQuality |
| ModernVideoPlayer | 1944 | progress | setProgress |
| ModernVideoPlayer | 1945 | showClipShareModal | setShowClipShareModal |
| ModernVideoPlayer | 1946 | showQuizModal | setShowQuizModal |
| ModernVideoPlayer | 1947 | showSummaryModal | setShowSummaryModal |
| LiveTranslationModal | 2436 | isPlaying | setIsPlaying |
| LiveTranslationModal | 2437 | currentSentenceIndex | setCurrentSentenceIndex |
| LiveTranslationModal | 2438 | visibleWordsCount | setVisibleWordsCount |
| LiveTranslationModal | 2439 | currentLanguage | setCurrentLanguage |
| LiveTranslationModal | 2440 | show173Modal | setShow173Modal |
| LiveTranslationModal | 2441 | isDrawerOpen | setIsDrawerOpen |
| LiveTranslationModal | 2444 | youtubeUrlInput | setYoutubeUrlInput |
| LiveTranslationModal | 2445 | youtubeId | setYoutubeId |
| LiveTranslationModal | 2448 | dynamicTranslations | setDynamicTranslations |
| LiveTranslationModal | 2449 | isFetchingTranslation | setIsFetchingTranslation |
| SplitAuthScreen | 3161 | email | setEmail |
| SplitAuthScreen | 3162 | password | setPassword |
| SplitAuthScreen | 3163 | verifyCode | setVerifyCode |
| SplitAuthScreen | 3164 | captchaCode | setCaptchaCode |
| VisitorDashboard | 3303 | mapModalData | setMapModalData |
| VisitorDashboard | 3304 | activeTab | setActiveTab |
| VisitorDashboard | 3305 | selectedCategory | setSelectedCategory |
| VisitorDashboard | 3306 | searchQuery | setSearchQuery |
| VisitorDashboard | 3307 | wamdaSearch | setWamdaSearch |
| VisitorDashboard | 3308 | selectedVideo | setSelectedVideo |
| VisitorDashboard | 3309 | showLiveTranslation | setShowLiveTranslation |
| VisitorDashboard | 3310 | showQuizModal | setShowQuizModal |
| VisitorDashboard | 3311 | isAiDrawerOpen | setIsAiDrawerOpen |
| VisitorDashboard | 3312 | isLiveAudioPlaying | setIsLiveAudioPlaying |
| VisitorDashboard | 3314 | scheduleAlerts | setScheduleAlerts |
| VisitorDashboard | 3315 | quizAnswers | setQuizAnswers |
| VisitorDashboard | 3316 | quizSubmitted | setQuizSubmitted |
| VisitorDashboard | 3321 | isFloatingChatOpen | setIsFloatingChatOpen |
| VisitorDashboard | 3322 | isFloatingMinimized | setIsFloatingMinimized |
| VisitorDashboard | 3323 | currentConversationId | setCurrentConversationId |
| VisitorDashboard | 3326 | isBotThinking | setIsBotThinking |
| VisitorDashboard | 3327 | chatInput | setChatInput |
| VisitorDashboard | 3328 | feedbackToast | setFeedbackToast |
| VisitorDashboard | 3329 | showHistoryDrawer | setShowHistoryDrawer |
| VisitorDashboard | 3330 | copiedMsgId | setCopiedMsgId |
| VisitorDashboard | 3333 | savedConversations | setSavedConversations |
| VisitorDashboard | 3347 | chatMessages | setChatMessages |
| TeamsVirtualClass | 4581 | isMicOn | setIsMicOn |
| TeamsVirtualClass | 4582 | isCamOn | setIsCamOn |
| TeamsVirtualClass | 4583 | isSharingScreen | setIsSharingScreen |
| TeamsVirtualClass | 4584 | isHandRaised | setIsHandRaised |
| TeamsVirtualClass | 4585 | activeSideTab | setActiveSideTab |
| TeamsVirtualClass | 4586 | showTeamsSign | setShowTeamsSign |
| TeamsVirtualClass | 4589 | liveQuestions | setLiveQuestions |
| TeamsVirtualClass | 4594 | newQuestionText | setNewQuestionText |
| TeamsVirtualClass | 4597 | chatMessages | setChatMessages |
| TeamsVirtualClass | 4602 | chatInput | setChatInput |
| UmdatHomeworkModal | 5033 | homeworkText | setHomeworkText |
| UmdatHomeworkModal | 5034 | isSubmitted | setIsSubmitted |
| UmdatQuizModal | 5127 | selectedAnswers | setSelectedAnswers |
| UmdatQuizModal | 5128 | quizResult | setQuizResult |
| StudentProfileModal | 5274 | fullName | setFullName |
| StudentProfileModal | 5275 | country | setCountry |
| StudentProfileModal | 5276 | nativeLang | setNativeLang |
| StudentProfileModal | 5277 | studyTrack | setStudyTrack |
| StudentProfileModal | 5278 | academicYear | setAcademicYear |
| StudentProfileModal | 5279 | avatar | setAvatar |
| StudentDashboard | 5379 | studentProfile | setStudentProfile |
| StudentDashboard | 5388 | isProfileModalOpen | setIsProfileModalOpen |
| StudentDashboard | 5389 | isUmdatHomeworkOpen | setIsUmdatHomeworkOpen |
| StudentDashboard | 5390 | isUmdatQuizOpen | setIsUmdatQuizOpen |
| StudentDashboard | 5393 | activeTab | setActiveTab |
| StudentDashboard | 5426 | maajemInputText | setMaajemInputText |
| StudentDashboard | 5427 | isRealMicRecording | setIsRealMicRecording |
| StudentDashboard | 5428 | isMaajemProcessing | setIsMaajemProcessing |
| StudentDashboard | 5429 | maajemAnalysisResult | setMaajemAnalysisResult |
| StudentDashboard | 5430 | difyConversationId | setDifyConversationId |
| StudentDashboard | 5433 | isScanningImage | setIsScanningImage |
| StudentDashboard | 5434 | imageResult | setImageResult |
| StudentDashboard | 5627 | selectedSubjectFilter | setSelectedSubjectFilter |
| StudentDashboard | 5628 | lessonSearchQuery | setLessonSearchQuery |
| StudentDashboard | 5629 | activePlayingLesson | setActivePlayingLesson |
| StudentDashboard | 5671 | selectedScheduleDay | setSelectedScheduleDay |
| StudentDashboard | 5718 | messagingSheikh | setMessagingSheikh |
| StudentDashboard | 5719 | sheikhMessageInput | setSheikhMessageInput |
| StudentDashboard | 5720 | sheikhLecturesModal | setSheikhLecturesModal |
| SheikhPostModal | 6850 | postType | setPostType |
| SheikhPostModal | 6851 | title | setTitle |
| SheikhPostModal | 6852 | subject | setSubject |
| SheikhPostModal | 6853 | details | setDetails |
| SheikhPostModal | 6854 | deadline | setDeadline |
| SheikhPostModal | 6855 | duration | setDuration |
| SheikhPostModal | 6856 | grade | setGrade |
| SheikhPostModal | 6857 | priority | setPriority |
| SheikhDashboard | 7055 | activeTab | setActiveTab |
| SheikhDashboard | 7056 | toastMessage | setToastMessage |
| SheikhDashboard | 7057 | showPostModal | setShowPostModal |
| SheikhDashboard | 7065 | sheikhPublishedItems | setSheikhPublishedItems |
| SheikhDashboard | 7106 | studentsRoster | setStudentsRoster |
| SheikhDashboard | 7139 | searchStudent | setSearchStudent |
| SheikhDashboard | 7140 | filterSubject | setFilterSubject |
| SheikhDashboard | 7172 | selectedCouncilSheikh | setSelectedCouncilSheikh |
| SheikhDashboard | 7173 | councilMessages | setCouncilMessages |
| SheikhDashboard | 7177 | councilInput | setCouncilInput |
| SheikhDashboard | 7195 | copilotPrompt | setCopilotPrompt |
| SheikhDashboard | 7196 | copilotResponse | setCopilotResponse |
| SheikhDashboard | 7197 | isCopilotGenerating | setIsCopilotGenerating |
| OrganizersDashboard | 7677 | activeMainTab | setActiveMainTab |
| OrganizersDashboard | 7680 | academicTier | setAcademicTier |
| OrganizersDashboard | 7682 | toastMessage | setToastMessage |
| OrganizersDashboard | 7749 | nawazilList | setNawazilList |
| App | 8744 | route | setRoute |
| App | 8745 | showSplash | setShowSplash |
| App | 8746 | splashFade | setSplashFade |
| App | 8749 | currentLanguage | setCurrentLanguage |
| App | 8752 | showLangModal | setShowLangModal |
| App | 8755 | showAccessModal | setShowAccessModal |
| App | 8758 | minimizedAudio | setMinimizedAudio |
| App | 8759 | isMiniPlaying | setIsMiniPlaying |
| App | 8762 | showVoiceHUD | setShowVoiceHUD |
| App | 8763 | isVoiceListening | setIsVoiceListening |
| App | 8764 | voiceTranscript | setVoiceTranscript |
| App | 8891 | toastMessage | setToastMessage |
| App | 8892 | accessSettings | setAccessSettings |
| App | 8978 | sharedAnnouncements | setSharedAnnouncements |
| App | 8979 | sharedQuizzes | setSharedQuizzes |
| App | 8980 | assignments | setAssignments |
| App | 9004 | uploadedLectures | setUploadedLectures |

## Named handlers/helpers

| Owner | Line | Callable |
|---|---:|---|
| LogoMaqam | 189 | LogoMaqam |
| normalizeArabicSearch | 316 | normalizeArabicSearch |
| applyPlatformLanguage | 337 | applyPlatformLanguage |
| LanguageSelectorModal | 380 | LanguageSelectorModal |
| MotionSicknessStabilizer | 521 | MotionSicknessStabilizer |
| SignLanguageFloatingPIP | 550 | SignLanguageFloatingPIP |
| AccessibilityModal | 613 | handleToggleVoiceCommands |
| ClipShareModal | 938 | ClipShareModal |
| ClipShareModal | 949 | handlePublish |
| LectureQuizModal | 1177 | LectureQuizModal |
| LectureQuizModal | 1219 | handleSelect |
| LectureQuizModal | 1224 | calculateScore |
| LectureSummaryModal | 1322 | LectureSummaryModal |
| LectureSummaryModal | 1335 | handleCopy |
| MiniFloatingAudioPlayer | 1398 | MiniFloatingAudioPlayer |
| HaramInteractiveMapModal | 1458 | HaramInteractiveMapModal |
| VoiceHUD | 1536 | VoiceHUD |
| HijriCalendarSchedule | 1636 | HijriCalendarSchedule |
| HijriCalendarSchedule | 1763 | toggleReminder |
| ModernVideoPlayer | 1939 | ModernVideoPlayer |
| LiveTranslationModal | 2435 | LiveTranslationModal |
| LiveTranslationModal | 2452 | extractYoutubeId |
| LiveTranslationModal | 2459 | applyYoutubeUrl |
| LiveTranslationModal | 2486 | fetchLanguageSubtitles |
| LiveTranslationModal | 2523 | getCurrentSentenceText |
| LiveTranslationModal | 2569 | togglePlayPause |
| LiveTranslationModal | 2584 | handleRestart |
| LiveTranslationModal | 2595 | handlePrevSentence |
| LiveTranslationModal | 2602 | handleNextSentence |
| LiveTranslationModal | 2614 | formatTime |
| MainScreen | 2942 | MainScreen |
| TSSelectScreen | 3102 | TSSelectScreen |
| SplitAuthScreen | 3160 | SplitAuthScreen |
| SplitAuthScreen | 3166 | handleLogin |
| VisitorDashboard | 3302 | VisitorDashboard |
| VisitorDashboard | 3446 | toggleScheduleAlert |
| VisitorDashboard | 3451 | copyMessageText |
| VisitorDashboard | 3460 | handleNewChat |
| VisitorDashboard | 3495 | handleSendChatMessage |
| VisitorDashboard | 3624 | handleReportMessage |
| VisitorDashboard | 3631 | renderFormattedText |
| TeamsVirtualClass | 4580 | TeamsVirtualClass |
| TeamsVirtualClass | 4621 | handleSendQuestion |
| TeamsVirtualClass | 4630 | handleSendChat |
| TeamsVirtualClass | 4639 | toggleVote |
| TeamsVirtualClass | 4643 | markAnswered |
| UmdatHomeworkModal | 5031 | UmdatHomeworkModal |
| UmdatHomeworkModal | 5036 | handleAutoFill |
| UmdatHomeworkModal | 5045 | handleSubmit |
| UmdatQuizModal | 5125 | UmdatQuizModal |
| UmdatQuizModal | 5178 | handleSelect |
| UmdatQuizModal | 5182 | handleSubmitQuiz |
| StudentProfileModal | 5272 | StudentProfileModal |
| StudentProfileModal | 5281 | handleSave |
| StudentDashboard | 5378 | StudentDashboard |
| StudentDashboard | 5396 | triggerToast |
| StudentDashboard | 5437 | handleToggleRealMic |
| StudentDashboard | 5477 | handleCameraUpload |
| StudentDashboard | 5488 | startImageAnalysisFlow |
| StudentDashboard | 5527 | handleProcessMaajem |
| StudentDashboard | 5689 | getDayLectures |
| StudentDashboard | 5722 | handleSendSheikhMessage |
| SheikhPostModal | 6849 | SheikhPostModal |
| SheikhPostModal | 6861 | handleSubmit |
| SheikhDashboard | 7054 | SheikhDashboard |
| SheikhDashboard | 7059 | triggerToast |
| SheikhDashboard | 7091 | handlePublishItem |
| SheikhDashboard | 7179 | handleSendCouncilMessage |
| SheikhDashboard | 7199 | handleGenerateCopilot |
| OrganizersDashboard | 7675 | OrganizersDashboard |
| OrganizersDashboard | 7683 | triggerToast |
| OrganizersDashboard | 7822 | handleFeedMuftiAnswer |
| App | 8743 | App |
| App | 8767 | executeVoiceCommand |
| App | 8863 | handleToggleVoiceHUD |
| App | 8920 | showToast |
| App | 8925 | handleSelectLanguage |
| App | 8944 | getColorFilterStyle |
| App | 9008 | navigateTo |

## Baseline hashes
C:\Users\fares\Documents\Codex\2026-10-20\role-you-are-redesigning-the-entire-2\work\source\maqamooo.html SHA256 8AE62EC488A539C8F0221BB38B1531D2E29695C77D19E5D61670B02E1AF7EF03
C:\Users\fares\Documents\Codex\2026-10-20\role-you-are-redesigning-the-entire-2\work\source\server.py SHA256 462B78E62F059635A59BCEE7E7B645DEAAACA96DACF19B53AC94451DD6D26AAD
