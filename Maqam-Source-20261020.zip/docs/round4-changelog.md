# Round 4 implementation log

Branch: feat/team-feedback-round-4. Work in progress; this document does not certify all 17 items complete.

## Implemented and checked so far
- A1/A2: PDF.js 6.4.299 module pinned from cdnjs with SHA-384 integrity; matching local worker and vendor cmap/font/wasm resources explicitly allowlisted. Dedicated IndexedDB study store holds normalized vectors, reader drafts and normal notes. In-app reader replaces library/source opening links. Explicit save and conflict handling; quick notes and More notes route. Browser opened a 552-page scanned book, placed a pin, saved, refreshed and recovered it. Drawing coordinate/history/storage unit tests pass; full pointer-device matrix remains.
- B3: lecture video precedes services; removed separate cover. Actual original recording credit remains on demo media.
- B4: bell is visual only. Per-lecture boolean persists; no permission request, scheduling or navigation. Old lesson-reminder delivery effect removed; real homework/publication notifications remain.
- B5: created-list sheet with checkboxes, create-and-add, remove via uncheck. No suggested default list name. Existing user data is retained.
- B6: full YouTube URL without timing; clipboard API with honest execCommand fallback; exact success text only after successful copying. Browser clipboard verified.
- B7: sample nocookie live embed, demo badge and enter-live autoplay payload; real config/empty state when demo disabled.
- C8/D10–12/E13–14: deterministic isolated 60-student demo model, five weekday subjects and fictional instructors, grade term/year workflow, ranking, relative notices and activity. Seven original recording credits and all original source summaries/quiz answers remain unchanged, checked by hashes. Home now reuses current timetable/notices rather than the obsolete poster and hardcoded GPA/attendance.
- E15: centered chat, collapsible history, four curriculum prompts, plain assistant text, safe existing Markdown, stop, voice, image review entry, autogrowing composer, latest-message control; answer copy, per-answer regeneration in a new conversation and locally persisted helpfulness. Real backend only; no fabricated response.
- E16: bounded validated same-origin capabilities/upload endpoints, Dify file ownership/expiry and optional image chat; Arabic OCR fallback and evidence-checked statement review. Smart-notes legacy canned image result removed. Local backend lacks Dify credentials; live provider vision is unverified.
- F17: dashboard guard uses width below 768 only; public Sheikhs entry remains on mobile.

## Sources and limits
Two source PDFs downloaded unchanged and independently inspected: ACO/AUB 1936 introduction (44 pages, scanned) and IslamHouse Bulugh (215 pages, Arabic text layer fragmented). Separate OCR indexes are generated; uncertain pages excluded from research search. Three other editions remain metadata-only pending affirmative redistribution permission. See library-sources.md.

PDF.js standard fonts are vendor rendering resources, unrelated to licensed Thmanyah UI font originals. No originals or font archives added. server.py changes are confined to round-4 endpoints, bounded upload handling, explicit reader/OCR asset paths and narrowly required CSP hosts/workers; .env untouched.

CodeQL could not extract any source in this Windows host due diagnostic/temp permission failure; no clean scan claimed. Python boundary tests remain the available automated evidence.

## Verification status
JSX parses. Existing plus new JavaScript suite: 150 passing before the latest library metadata adjustment. Python suite re-run in progress after extending the explicit manifest. Before images: docs/screenshots/round4-before. After images: docs/screenshots/round4-after. Full screen/theme matrix, all original UI name cleanup and final differential review are still pending; do not treat this checkpoint as release approval.

## Assumptions
No Render/GitHub use or deployment this round. DEMO_MODE and SHOW_DEMO_BADGES are the single top config block. Historical book/source authors are retained; fictional instructors are platform-only. Browser sample records used for verification stay local. Optional annotated PDF download omitted to keep annotation saving independent of rewriting the original PDF.

## Final local verification update
Current suite: 163 JavaScript tests pass; 64 Python tests run successfully with two Windows symlink privilege skips. Reader/notes pin save, last-page restore and zoom checked; quick lecture note appears in Notes alongside book pins. Mobile public directory, profiles, announcements and actual sample listen playback checked; management route blocked at 390. No console error entries in current traversed flows.

Local run: Start-Round4.cmd, http://127.0.0.1:5004/. Existing Start-Maqam.cmd retained. The separate port avoids the old server already using 5000. Screenshot lists: round4-before-screenshots.md and round4-after-screenshots.md; final review: round4-review.md.

The main HTML is an atomic integration of shared A/B/D/E/F component boundaries; asset/data and server boundary work are committed separately. This keeps intermediate single-file dependencies coherent. Legacy seeded assignments migrate to the five curriculum tasks while retaining assignment IDs/local work; user-created assignments are retained. Default-name migration changes only the old generated list label, preserving list IDs and membership. Existing weekly/monthly/all-time ranking filters remain; a week with no seeded activity has an honest empty state.

Not completed/verified: optional annotated-PDF export omitted as permitted; three books remain pending rights as permitted; no reliable Bulugh research pages passed the OCR confidence gate; live provider vision/answer review cannot be verified without configuration, and no genuine handwritten mistake fixture or physical mouse/stylus/touch drawing matrix was available to this run. CodeQL extraction is blocked by the Windows host. These limitations are not hidden by placeholder answers or success messages.
