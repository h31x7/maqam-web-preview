# Maqam UI implementation changelog
2026-10-21 — approved D.2, branch ui-redesign.

## System
Noto Kufi Arabic UI; Amiri scholarly text/headings. Dark teal background #071e21 with surfaces #102b2e/#173539/#1c3d40, borders #305054, text #ecf2eb/#afc2bd/#94ada7, gold #d6b571. Light background #f3f7f3, surfaces white/#eaf1ec/#e3ece5, borders #b8cec3, text #183e37/#4e685f/#526d63, gold #826528. Media retains a dark surface. Shared tokens include danger/success; see DESIGN.md for full values and rationale.

Shared buttons, fields, tabs, chips, rows, dialogs, media controls, focus states and 160ms transitions. RTL desktop right rail 248px; tablet icon rail 84px; mobile drawer and bottom navigation. Appearance is session-only; no storage key added.

## Phases and differential review
| Phase | Presentation changes | Preservation result |
|---|---|---|
| 0 | Audit, tokens, fonts, presentation context and primitives | PASS |
| 1 | Entry/auth hierarchy; language/accessibility surfaces and keyboard dialog wrapper | PASS |
| 2 | Visitor six tabs, scholarly Q&A, broadcast arch, divided lectures/library, players/overlays | PASS |
| 3 | Student six tabs, academic panels/rosters/forms; shared lesson/quiz/profile styling | PASS |
| 4 | Sheikh four tabs and Organizer three tabs, tables/content forms | PASS |
| 5 | Mini-player separation, mobile nav position, play/pause icons, focus restoration, opaque dialogs, filtered viewport anchoring, compact calendar | PASS; verification scope below |

PASS compares all 50 original declarations outside JSX; original callbacks and non-style props; ordered Arabic text; rendered child conditions. server.py and .env are byte-identical. New helpers contain presentation/theme/device/focus/layout behavior only. Original data, business state, API calls, handlers and storage keys were preserved. Details: phase-0-review.md through phase-5-review.md.

## Evidence
Baseline: screenshots/baseline/verified-*.jpg now contains 60 fresh viewport captures (entry + all 19 dashboard tabs × 3 widths); concepts/baseline/ retains 27 earlier representative views. Phase captures: docs/screenshots/phase-*.jpg. Final viewport images: docs/screenshots/final/. See screenshot-matrix.md and screenshot-manifest.json. The final tab set covers all 19 dashboard tabs in both themes at 390/768/1440, plus entry/auth and sampled overlays. verified-layout.json records 120 width/RTL/overflow checks, all passing.

## Assumptions and limits
- Archive omits referenced local images/assets; original paths retained, no portraits invented.
- TSSelectScreen, TeamsVirtualClass and employee login remain at their original reachability; no route added merely to screenshot them.
- External Google Translate/YouTube/microphone services depend on provider/network/permission. Existing integration retained; full external playback/recognition is not asserted.
- Homework/grade/attendance submission and teaching publication/council messages were not executed. Automated approval review rejected the consequential homework-submission test.
- Original authentication recovery href="#" remains a static-audit finding under zero functional change.
- Earlier phase/full-page captures may distort fixed-position elements or have stale viewport dimensions. Final dashboard images were recaptured as viewport images; earlier screenshots are historical evidence, not exhaustive proof.
- Babel still emits an informational oversized-generated-code styling notice (reported at error level by the browser tool); input size reduction did not eliminate this generated-output notice. No React runtime exception was observed.
- Additional exhaustive overlay/state and external-service validation remains before asserting the full definition of done. No new deployment was performed for this redesign.
