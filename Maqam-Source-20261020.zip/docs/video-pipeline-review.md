# Video pipeline independent review

Reviewed 2026-10-26: client commit `38ff4bb` and working server preparation implementation. No environment files, credentials, signed source URLs or provider responses were inspected. This review does not establish deployed or live-provider success.

## Verified client behavior

Independent command `node --test tests/round3-translation.test.js tests/round5-media.test.js tests/round3-watch.test.js`: 41 passed, 0 failed. Source preparation is actionable without existing transcript text; matching source results feed translation; absolute start/end retain initial and interior silence; Play can arm during gaps. Abort checks prevent stale source completion after leaving. Five-second polling is about twelve requests per minute, below the twenty/minute shared capability admission limit, although simultaneous capability calls may legitimately exhaust it. Failed jobs do not deduplicate into a permanent failed result: resubmission creates fresh work. Client and server source fields agree on videoId, source hash, whisper-large-v3, unreviewed transcript, duration and rows.

## Server review and follow-ups

Registered public lecture IDs are the only preparation input. Media redirects are revalidated, all DNS addresses must be public, the chosen address is pinned while preserving TLS hostname verification, and environment proxies are bypassed. Provider redirects are rejected; failures return an allowlisted code instead of subprocess/provider diagnostics. Jobs and completed cache are outside public static files, bounded by age/count/size; restore validates source data, and completed writes replace atomically. Temporary media is scoped to the job and subprocess trees are terminated on deadline failures.

The stream bridge change is being reviewed while its owner finishes. Concrete follow-ups sent to that owner: align the server per-row text limit with the client's 16,000-character limit, enforce same-origin GET evidence when Origin is absent, and apply a deadline/socket timeout to bridge writes. Final server tests and final change review remain pending and must supersede this interim section.

## Required evidence before claiming complete operation

A source duration alone does not prove recognition of the full recording. The final implementation must decode every chunk, verify contiguous chunk coverage to the actual source duration, call Whisper on every chunk, and retain absolute chunk offsets. Empty recognition rows can be legitimate silence and must not be filled with fabricated text. The unit fixture containing one short segment in a 4,395-second result is a schema fixture only. Actual whole-recording Whisper, translation and Edge audio evidence and a hosted extraction check are owned by the main task and remain outside this review's verification.

## Live-probe-driven client blocker found by main task

The initial client translates the entire transcript before publishing any `texts`. For a full lecture, the 150-token completion cap requires many small translation requests; whole-transcript preparation can encounter provider limits and fallback limits before the Play control becomes available. The main task is replacing this with progressive translation of the current/next window and a scheduler that safely tolerates untranslated rows. This is a release blocker until the replacement and seek/language/source cancellation tests are reviewed. The 41 passing tests above did not establish practical full-lecture translation throughput.

## Progressive client follow-up review

The full-transcript throughput blocker now has a bounded window controller: at most six nearby rows/about thirty seconds, sparse null entries for unrequested rows, abort on stale seek/window/source/language, and transcript/timestamp/language/model cache identity. The scheduler does not synthesize missing entries. It retains the same scheduler when translated slots arrive and pauses only playback it owns while current translation is missing, using an intent version to avoid resuming after user interaction. Independent review identified an asynchronous YouTube pause-acknowledgement race; the owner added pending/observed pause state and a regression test before signoff. Waiting status is cleared and incremental text updates retain the initial character bound.

Independent focused re-run after those changes: 45 tests passed, 0 failed (`round5-media`, `round3-translation`, `round3-watch`). No remaining concrete blocker found in the scoped client logic. This replaces the initial whole-transcript release blocker above; it does not establish provider throughput or full hosted playback. Automatic resume can still be denied by browser/player policy, requiring manual Play.

## Final server static decision

Final working server and source tests reviewed after the main task's bridge fixes. No remaining concrete blocker found for the Linux/Render path in this static scope. The bridge now holds its lock only around counters, admits at most four simultaneous range streams, caps aggregate bytes/request count, and bounds downstream writes to ten seconds. The concurrent-seek regression exercises a second request while the first is blocked, addressing the observed global-lock deadlock. The 16,000-character row cap agrees with the browser. Fixed extractor/EJS/ffmpeg dependencies are pinned. Each chunk must pass duration/manifest continuity checks and all chunks are transcribed before completion; silence is not filled with invented rows.

The GET policy is an explicit accepted scope decision: UUID job handles expose only registered public lecture results; absent Origin is permitted, a supplied wrong Origin is rejected, and cross-site browser fetch metadata is rejected. POST still requires a matching Origin. This supersedes the earlier stricter GET follow-up and is not a private-source authorization model.

Verification distinction: the main task reports all 15 source tests passing with loopback permission. My independent re-run passed the twelve non-loopback tests, while the three loopback bridge tests were blocked by Windows socket access restrictions (`WinError 10013`); that run is not recorded as passing. The 45 focused client tests above passed independently. Live full-recording and hosted provider verification remain the main task's separate work, not this static signoff.

Platform limitation: POSIX timeout cleanup kills the subprocess group. Windows uses native `process.kill()` for the immediate child; it does not guarantee termination of Node descendants spawned by yt-dlp. Therefore the earlier statement about terminating subprocess trees applies to the production POSIX path, with this Windows limitation retained explicitly.
