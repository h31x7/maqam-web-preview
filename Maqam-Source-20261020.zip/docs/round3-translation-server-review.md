# Round 3 translation proxy review

Scope: `server.py`, `tests/test_round3_translation.py`; the existing CSP assertion includes the newly required exact YouTube script host. No HTML, environment file, credentials, deployment or Git operation was changed by this subtask.

## Contract and boundary

`POST /api/translate` accepts exactly `{text, target, source}`; source must be `ar`. It returns `{text, target}` only after a valid provider response. Text is nonempty, at most 4000 Unicode characters, rejects NUL, surrogates, CR and other ASCII control characters except legitimate LF/TAB text. The existing 16384-byte framing limit, strict UTF-8 JSON parsing, duplicate-property rejection, content-type/charset checks, client read deadline, Host and same-origin validation apply before translation.

The destination is a literal HTTPS Google hostname and path (`translate.googleapis.com/translate_a/single`) with fixed `client=gtx`, source and response mode. Request values are URL encoded as query parameters. No destination, URL, key, host, redirect or source-language override is accepted. Redirects are rejected by the existing urllib redirect handler. Target codes come from canonical repository `data/languages.json`; the ambiguous `gd` code, legacy `iw`/`jw` and the supplied known defective/unsupported codes are excluded. Synonymous `ny` entries coalesce into one eligible target. Normalized `he` and `jv` are accepted. This eligibility check is not a claim that every eligible language has passed a live provider test.

The endpoint is unofficial and can be throttled or withdrawn. Parent live probes returned external 429 responses; no successful live translation is claimed by this server task. Transport tests use mocked upstream responses under real urllib redirect/status handling.

## Resource limits and honest failures

Translation has a separate locked, bounded process-local limiter: 60 requests/minute per IP and 60 globally, with at most 4096 identity entries. It never trusts forwarded IP headers. A provider 429 triggers a global 60-second cooldown; subsequent requests return 429 with Retry-After without contacting the provider. Other provider/network/format failures return 502. There is no fallback English text, rotated destination or automatic external retry.

Successful translations use a 256-entry LRU cache with a one-hour TTL. Inputs and cached output strings are bounded. Upstream connection/read socket timeout is eight seconds; reads use bounded 8 KiB chunks with an eight-second aggregate read deadline check and at most 65537 bytes. A single in-progress socket read can extend the aggregate check by at most the socket timeout. Output concatenation is capped at 16000 characters. The existing 64-worker server bound still applies.

The only CSP change adds exactly `https://www.youtube.com` to script-src for the IFrame API. Existing frame/connect hosts, script exceptions and approved blob media policy remain otherwise unchanged.

## Test evidence and differential review

Initial new endpoint tests failed with expected 404 responses before implementation. Ten focused tests now pass: translation/cache, exact destination, target/source/schema/control/length validation, duplicate JSON keys and malformed UTF-8, safely encoded LF/TAB text, same-origin rejection, external 429 and cooldown, redirects, malformed/oversized provider responses, timeouts, global throttling and cache capacity. The suite uses the current real handler with in-memory HTTP streams; no test sends a real external request.

Full suite after the precise CSP assertion update: **50 tests, OK, two Windows symlink skips**. The skips are existing host limitations, not claimed integration passes. The new ten translation tests pass independently.

Differential review: changes are limited to one new translation state helper, canonical target loading, the new POST handler branch and handler, OPTIONS admission for the same route, server initialization and the single script-src host. Existing static allowlists, PDF Range behavior, Dify schema/destination/credential handling and public health behavior retain their prior contracts. The tests demonstrate no arbitrary-host/extra-field route to urllib, no redirects, no provider diagnostic leakage and no fake-success behavior. Process-local limits multiply across multiple deployed workers/instances; this thin proxy is intended for the current single-process service model.

## CodeQL: blocked, no scan result

Read the requested CodeQL skill and used the installed official CLI. New source snapshot contains only this server and focused test file at `work/round3/translation-codeql/source/`; no UI source or secret file was read into the scan.

Fresh valid native-temp attempt failed because Java could not access the sandbox temp parent (`AccessDeniedException`) despite the shell creating the directory. A fresh workspace attempt initialized and finalized but reported the log and diagnostic directories not writable and `CodeQL detected code written in Python but could not process any of it.` Installed language resolution confirms the Python extractor is present; its supported Python executable configuration does not resolve the preceding Java filesystem boundary. Existing earlier review attempts had already tried explicit interpreter configuration and native-temp extractor copies. No ACL, executable check, permission setting or sandbox boundary was bypassed.

The skill's `check_db_quality.py` exited 1: `src.zip is missing — the database has no source archive.` Analysis was therefore not run. There is no SARIF, successful query result, clean-scan or completed CodeQL claim. Build logs, language resolution and quality failure are retained in `work/round3/translation-codeql/`. CodeQL must be completed in a working authorized environment before treating that verification item as done.
