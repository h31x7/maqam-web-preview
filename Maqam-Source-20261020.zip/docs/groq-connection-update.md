# Groq connection update — 2026-10-25

## Applied translation change

The team supplied `qwen/qwen3.8-27b`; it was found in the authenticated models list. `whisper-large-v3` was also listed, but no new STT feature or endpoint was requested or added.

The ignored local environment now sets `GROQ_TRANSLATE_MODEL=qwen/qwen3.8-27b`. The tracked template contains this nonsecret model name and an empty key. Translation requests explicitly use `max_tokens:150`, preserving temperature0, the structured ordered-array contract, protected religious-content instructions, schema checks and existing working fallback. No credential was changed, printed, tracked or served.

Real checks: a direct short request returned HTTP200; a fresh local app server POST /api/translate returned HTTP200, engine groq, the configured model and two translated sentences. Targeted contract tests were observed failing for missing max_tokens, then all16 passed after the change. A 150-token ceiling is a maximum, not a promise that arbitrarily long batches fit; malformed/truncated JSON still fails validation and uses the explicit existing fallback. Full synchronized lecture playback still requires verified captions tied to the recording.

## Proposed Edge speech change — NOT applied

The team described edge-tts speech after translation. A disposable ignored dependency installation of edge-tts7.3.1 was tested against the actual service:322 voice entries,75 base language codes; short Arabic ar-SA-HamedNeural synthesis returned16848 bytes and English en-US-AriaNeural returned12384 bytes. This proves the standalone provider check, not integration with the application. Do not claim80+ base languages from these results.

Concrete proposed change: add pinned edge-tts7.3.1 runtime dependency; select Edge through server-only TTS_PROVIDER=edge; expose provider-discovered allowlisted voices through the existing safe metadata endpoint; return bounded MP3 from the existing speech endpoint; let the existing WebAudio player decode it and retain cancellation, volume restoration and verified timeline safeguards. Preserve optional Groq speech support. Send translated text only to Microsoft Edge's online speech service, with generic honest errors, timeouts and per-IP limits. Update local launcher/deployment dependency setup and verify real application playback before claiming completion.

Automatic approval review rejected applying that persistent provider replacement/external dependency because exact production-change authorization was unclear. No Edge provider/config/runtime/application changes were applied; a disposable ignored probe is the only installation. Explicit approval is required before that proposal is executed. Groq speech remains the existing provider and has not been claimed fixed by the translation update. No deployment was performed.

Final verification: full Python suite80 tests run,2 skipped,no failures. Focused differential review: only explicit output-token cap, supplied model in nonsecret template, regression assertion and this report changed; existing endpoint schemas and audio provider remain unchanged. Local server restarted on port5005 with the supplied model configured.
