# Round 4 library sources

Research date: 2026-10-24. No PDFs were downloaded or added during this research task. Candidate files require local identity, byte-size and text-quality verification before ingestion. An entry without an installed verified asset remains **قيد الإضافة**. Author/editor credits are factual bibliography, not fictional instructors. Free downloads alone do not grant redistribution permission.

## مدارك التنزيل

- Title: مدارك التنزيل وحقائق التأويل، المعروف بتفسير النسفي.
- Author: أبو البركات عبد الله بن أحمد النسفي.
- Bibliographic edition: تحقيق يوسف علي بديوي؛ دار الكلم الطيب، بيروت؛ الأولى، 1419هـ.
- Exact bibliographic source: https://dorar.net/refs/arabia (reference 76; institutional reference list).
- Permission basis: No affirmative redistribution permission established for that edited edition. The classical author's age does not clear modern editorial rights.
- Institutional research lead only: NYU ACO lists تفسير القرآن الجليل v.1–2 and v.3–4, مطبعة السعادة، مصر، 1333هـ [1914?], AUB copies. Catalog: https://aco.dlib.nyu.edu/search?author=Nasafi%CC%84%2C+%CA%BBAbd+Alla%CC%84h+ibn+Ah%CC%A3mad%2C+-1310%2C+author.&scope=matches . Catalog low-resolution sizes: 77.2 MB and 87.1 MB. Actual files and completeness/identity as مدارك التنزيل not verified; not an approved candidate.
- Result: **قيد الإضافة — metadata only.** verifiedCandidateURL: null. Approved PDF page count, size, text layer/OCR need: unverified; no research index content.

## مقدمة التفسير / مقدمة في أصول التفسير

- Interpretation: ابن تيمية's مقدمة في أصول التفسير; distinguish عبد الرحمن بن قاسم's separate similarly named work.
- Author: أحمد بن عبد الحليم ابن تيمية.
- Edition: تعليق ومقدمة جميل الشطي؛ مطبعة الترقي، دمشق، 1355هـ / 1936م؛ AUB copy, NYU Arabic Collections Online.
- Exact item: https://aco.dlib.nyu.edu/book/aub_aco002382/1
- Exact catalog evidence: https://aco.dlib.nyu.edu/search?author=AgapiusBishop+of+Hierapolis%2C+active+10th+century&page=47 (first result; unrelated search label notwithstanding).
- verifiedCandidateURL: https://mc.dlib.nyu.edu/files/books/aub_aco002382/aub_aco002382_lo.pdf
- Permission basis: https://aco.dlib.nyu.edu/about . NYU states it researched copyright requirements in countries of publication and believes all displayed ACO materials are public domain. This is institutional public-domain evidence, not an invented Creative Commons license. Retain author/editor/AUB/NYU source credit.
- Remote verification: **44 PDF pages**, **no extracted text**; source catalog **4.3 MB** low-resolution, 16.9 MB high-resolution. Treat as scanned and needing Arabic OCR until local inspection proves otherwise. Sizes are source-rounded values, not measured bytes.
- Result: **Legitimate candidate identified; local ingestion/visual identity check pending.** Application remains **قيد الإضافة** until local verification, allowlisting and reader integration. No searchable page text created.

## العقيدة التدمرية

- Title: الرسالة التدمرية / العقيدة التدمرية.
- Author: أحمد بن عبد الحليم ابن تيمية.
- Exact institutional source confirming underlying work/author: https://islamhouse.com/ar/books/2830127/ . This is a commentary page, not the requested standalone book.
- Edition: No complete standalone edition with affirmative permission verified. https://dorar.net/refs/aqadia identifies a التدمرية edition (reference 329), but identification is not permission.
- Excluded substitutions: الشرح الكامل على الرسالة التدمرية by يوسف بن محمد الغفيص and شرح العقيدة التدمرية by عبد الرحمن بن ناصر البراك are commentaries; neither silently replaces the requested base text.
- Permission basis: None established for a standalone candidate.
- Result: **قيد الإضافة — metadata only.** verifiedCandidateURL: null. Page count, size, text layer/OCR need: unverified; no index content.

## بلوغ المرام

- Full title: بلوغ المرام من أدلة الأحكام.
- Author: أحمد بن علي ابن حجر العسقلاني.
- Candidate edition: راجعه ودققه هيثم سرحان؛ سلسلة متون معهد السنة رقم 33؛ النسخة الأولى 1443هـ (remote PDF title text). Distinguish the separate عبد المحسن القاسم attachments.
- Exact source item: https://islamhouse.com/ar/books/2827180/ (attachment 2).
- verifiedCandidateURL: https://d1.islamhouse.com/data/ar/ih_books/single-03/ar-bulugh-almaram.pdf
- Permission basis: https://d1.islamhouse.com/html/faq.htm permits redistribution through different media with unchanged scientific content and source credit. Its commercial-use answer separately requires discussion with the source of third-party materials; do not infer unrestricted commercial rights. Preserve the file; credit IslamHouse/author/reviewer; keep user annotations as a separate layer.
- Remote verification: **215 PDF pages**; catalog **2.79 MB**, rounded, not independently measured. Text is extractable but Arabic letters/diacritics are fragmented in tool output. Test actual PDF.js extraction before admitting text to the research index; usable Arabic search text not established.
- Result: **Legitimate candidate for unchanged, credited noncommercial distribution; local ingestion/content check pending.** Application remains **قيد الإضافة** until local verification, allowlisting and reader integration. No index text created.

## التقريرات السنية شرح البيقونية

- Bibliographic title: التقريرات السنية شرح المنظومة البيقونية في مصطلح الحديث (slight title variants exist).
- Author: حسن بن محمد المشاط المالكي (ت 1399هـ).
- Bibliographic edition: تحقيق فواز أحمد زمرلي؛ دار الكتاب العربي، بيروت؛ الرابعة، 1417هـ / 1996م؛ جزء واحد.
- Exact institutional bibliographic evidence: Al-Baha University-hosted scholarly article references identify author/work/edition: https://bu.edu.sa/documents/1797803/0/03%2B%2827%29.pdf/f42e644b-f2e7-98d6-08bf-a848db8df0eb?download=true&t=1638306292991&version=1.0 . This is a journal article, **not the requested book** or candidate book asset.
- Permission basis: No affirmative redistribution permission for the work or an edition established. Author death date and third-party free-download pages do not establish permission.
- Result: **قيد الإضافة — metadata only.** verifiedCandidateURL: null. Page count, size, text layer/OCR need: unverified; no index content.

## Handoff limits

Two candidates have positive institutional rights evidence; three use the user's permitted metadata fallback. This task did not acquire PDFs, modify code/server, add index pages or verify Range behavior. Ingestion must inspect the full title/edition, measure bytes/page count, assess readability/Arabic extraction, record an integrity hash, preserve attribution and explicitly allowlist the reader asset. Resolve any file-level rights reservation conflicting with general source permission before hosting.

## Verified local ingestion — 25 October 2026

- مقدمة في أصول التفسير (book-8): 44 pages; 4343174 bytes; SHA-256 `6535899e0cb7fd4edd4b7fb29cde2af513cc2b342a3f8a7a22a0d8ec79da1bf7`. Original bytes unchanged. Edition: مطبعة الترقي، دمشق، 1355هـ / 1936م؛ تعليق جميل الشطي. Source: https://mc.dlib.nyu.edu/files/books/aub_aco002382/aub_aco002382_lo.pdf. Rights basis: https://aco.dlib.nyu.edu/about. Whole document rendered for Arabic OCR; 7/44 pages pass conservative 65% mean-word confidence. Other pages stay in the index labelled low confidence and are excluded from research answers/search. No human-corrected text is claimed.
- بلوغ المرام من أدلة الأحكام (book-9): 215 pages; 2925834 bytes; SHA-256 `3703b453d6a8000f8df976f838859bdd7403d02e98e31f416a9d5e89ba4dc71a`. Original bytes unchanged. Edition: سلسلة متون معهد السنة 33، النسخة الأولى 1443هـ. Source: https://d1.islamhouse.com/data/ar/ih_books/single-03/ar-bulugh-almaram.pdf. Rights basis: https://d1.islamhouse.com/html/faq.htm. Whole document rendered for Arabic OCR; 0/215 pages pass conservative 65% mean-word confidence. Other pages stay in the index labelled low confidence and are excluded from research answers/search. No human-corrected text is claimed.

ACO title page (PDF page 5) visually checked: introduction, Ibn Taymiyyah, Jamil al-Shatti, first printing, Damascus 1355/1936. IslamHouse PDF first/last pages checked; no conflicting file-level distribution reservation found. IslamHouse general redistribution terms do not authorize inferred commercial reuse; retain attribution and consult the source before commercial deployment. Three works remain metadata-only pending an authorized edition.
