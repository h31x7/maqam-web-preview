# Round 3 final scoped differential review

Date: 2026-10-24. Baseline: `d3df91c`; scope is the current working tree, not an assertion about the entire historical application.

## Executive assessment

Conditional approval for this scope after one medium-severity functional defect was fixed. No unresolved P1/P2 issue was confirmed in the reviewed paths. Browser acceptance and deployment verification remain the implementer's separate responsibilities.

| Severity | Confirmed | Remaining |
|---|---:|---:|
| Critical / high | 0 | 0 |
| Medium (P2) | 1 | 0 |

Reviewed the new React-owned UI translation store, element wrappers, prepared-lecture live-translation modal, the fixed-provider translation request client, and `/api/translate` routing/validation/cache/throttle/upstream response handling. Historical context: the existing request framing/origin checks are inherited from commit `434d85c7`; the new translation path reuses those checks. This review made no change to the server, secrets, original data, or source Arabic copy.

## Fixed finding: stale translation batches corrupt the current generation

Location: `maqamooo.html`, `round3I18n` drain completion (approximately line 8622).

A language selection resets `tasks` and `pending`, but previous network batches remain in flight. Their unconditional `finally` cleanup subsequently removed keys and decremented counts belonging to the new selection. A rapid English / Urdu switch could announce translation complete while the Urdu request remained pending. Selecting English twice could additionally erase the new same-key request's deduplication entry.

The cleanup now updates `tasks`, `pending`, and completion status only when the batch's generation is still current. The shared physical concurrency counter is always released so old requests cannot deadlock later requests. Existing generation checks already prevent stale result text from being applied. The fix preserves that contract.

Blast radius: one store used by `useRound3Text`, which is used by the text and attribute/option wrappers installed once at root initialization. The wrapper affects translatable UI across the application, making accurate status and stable deduplication important. Two tests exercise real extracted canonical store code with separately controlled pending requests; they verify both cross-language status isolation and same-target deduplication retention.

## Translation modal and server review

The live-translation modal selects actual visible catalog lectures and delegates to the same lecture translation component. A URL opens the canonical lecture view rather than fabricating prepared captions. The URL handler requires HTTPS, no embedded credentials, an exact YouTube host allowlist, and an 11-character video ID. Catalog metadata is preserved by reference when the source exists. Existing voice-command microphone cleanup tests remain in place; the obsolete microphone-capture test for this now source-bound modal was replaced with two behavioral tests covering these current contracts.

The translation endpoint accepts only the exact text/target/source key set, source `ar`, bounded plain text and a repository-defined language target. Request framing, body deadlines and same-origin/Host checks remain shared with the existing proxy. The upstream host is fixed, parameters are URL-encoded, redirects are rejected, no request-specified upstream URL or credential is accepted, and responses are shape/size checked. Process cache, per-IP/global throttles and upstream cooldown are bounded. Errors return failure rather than fabricated translations. The browser client only falls back to this endpoint for network failure when explicitly enabled. No newly confirmed SSRF, injection, origin bypass or secret disclosure was found in this scoped inspection.

The global translation wrapper uses React elements, not DOM innerHTML replacement. Protected source context and scholarly-text checks prevent the specified source categories from being translated; static UI allowlisting prevents arbitrary chat drafts from being automatically sent through the UI translation queue. This is an inspection of the mechanism, not proof that every source-bearing renderer is marked correctly; screen-level source checks remain part of browser acceptance.

## Verification

- `node --test tests/*.test.js`: 121 passed, zero failures.
- `python -m unittest discover -s tests -p "test*.py" -q`: 50 tests, OK; two pre-existing platform-dependent symlink skips.
- The server tests cover malformed/duplicate-key payloads, encoding and size, invalid targets, cross-origin denial, redirect rejection, malformed/oversized upstream replies, timeout, cache bounds and provider cooldown.
- New regression coverage: current-generation pending status; same-target request identity; real lecture metadata retained; prepared source component used; unsafe/invalid links rejected without navigation or closing the modal.

## Limits

No browser was operated by this reviewer; the parent task performs browser QA. No CodeQL success is asserted: the separate server review records the host's Java/TEMP analysis failure and rejects an empty database as evidence. Actual external translation availability, speech voices, YouTube playback/captions and deployment reachability require runtime checks and may fail independently of these unit contracts. This report is deliberately scoped and does not certify every unrelated working-tree change.

## Follow-up: lecture language selector

Browser QA exposed an obsolete dependency on the Google widget's empty options list. Removed the lecture component's widget option state and body-wide MutationObserver, and use the owned API candidate registry directly (`registry(source, null)`). This prevents an empty external widget from disabling all lecture languages and removes repeated fresh-array state updates caused by observing the component's own DOM rendering. Known uncertain and duplicate codes remain disabled; actual API failures still show the existing retryable honest error. Added regression coverage for Arabic/Urdu/normalized Hebrew candidates, disabled uncertain/duplicate codes, and absence of the obsolete observer path. Targeted translation suite: 11 passed.

## Follow-up: source explanations on existing quiz snapshots

Browser QA found missing explanations in an older saved quiz draft despite current source data containing matching summary points. `reviewQuestions` now enriches only a blank historical explanation when the authoritative question has the identical normalized ID, question text, ordered options and correct-answer index. It returns a derived view; saved answers, score, question snapshot and existing explanation are not rewritten. Changed questions retain their historical explanation state. Lecture-derived quiz payloads now resolve current questions from their exact `lecture-<id>` catalog source while retaining cancellation and future-publication guards. Tests cover drafts and results, immutable storage, all identity mismatch fields, nonempty historical explanations, current catalog resolution and publication denial. Targeted domain suite: 23 passed.
