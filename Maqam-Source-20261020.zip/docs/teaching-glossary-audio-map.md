# القاموس والتجربة الصوتية

## Boundaries and integration

- `work/teaching/glossary-audio.jsx` is inserted into the existing React script after `learning.jsx`; no new dependencies or storage keys.
- `TeachingAudioQuiz({quiz,onClose})` accepts canonical `quiz.questions` or a question array (`q`, `options`, zero-based `correct`). Add a `تجربة اختبار الكفيف` button to the quiz detail with this quiz as payload. An empty or invalid set has a clear return action.
- Mount `<TeachingGlossaryStyles/>` once in the shell. Use `<MaqamGlossaryText text={value}/>` for literal titles/questions/answers/transcripts/homework/flashcards. Use `<MaqamGlossary>{renderedMarkdown}</MaqamGlossary>` around already-rendered safe Markdown trees. The walker preserves props and handlers and skips links, code, interactive nodes, HTML injection and custom components. Custom renderers must wrap their own text leaves. It never reads or mutates the DOM.
- Glossary matches longest terms first, retains original diacritics, and rejects matches inside Arabic/Latin words. It intentionally does not guess attached conjunction boundaries. All 20 definitions disclose scholarly review; these are concise explanations rather than rulings.
- The speech component owns recognition, synthesis and one timer. Every transition invalidates the prior generation, cancels synthesis, detaches recognition callbacks and aborts capture. Unmount, pause, repeat, skip, retry and exit use the same cancellation path. Recognition starts only from the question utterance's completion event; microphone denial, unsupported recognition, empty capture and synthesis failure expose editable manual answers and retry. Capture has a 12-second watchdog. Score is local practice only and never alters ordinary quiz results or points.

## Definition source review

Definitions were conservatively paraphrased, with doctrinal qualifications preserved. The glossary remains explicitly marked for scholar review, particularly contextual terminology, judicial death and disputed details of inheritance.

- Official Saudi scholar site, application of absolute/qualified texts and inheritance impediments: https://binbaz.org.sa/fatwas/2754/الاطلاق-والتقييد-في-نصوص-الشرع
- King Saud University Quran portal, Saadi commentary on 4:12, proportional reduction and differences concerning return: https://quran.ksu.edu.sa/tafseer/saadi/sura4-aya12.html
- Kuwait Ministry of Awqaf, Fiqh Encyclopedia vol. 4, expelling nasal water: https://content.awqaf.gov.kw/BasicPages/2020/10/7439f2c8eb21486492a9cbcf602da945.pdf
- Saudi official Hadith library, Umdat al-Qari, same definition: https://sunna.alifta.gov.sa/BookToc/ViewServicePage?bookId=43&mainId=392127

These sources verify selected technical definitions and qualifications, not formal scholar approval of all 20 entries.

## Verification

`node --test teaching-glossary.test.js`: 6 tests, 6 passing. Test first run failed because the domain marker did not exist, then passed after implementation. Covers 20 unique entries, text preservation, longest matching, diacritics, Arabic boundaries, bounded spoken option numbers and rejection of negated answer text; mocked speech/recognition lifecycle confirms delayed microphone start, stale-event cancellation, correction/advance sequencing, denial fallback and watchdog cancellation. Tests extract the pure domain from the fragment or integrated HTML fallback.

Manual integration checklist (browser verification remains with integrator):

- 1440×900, 390×844, 360×800: focus/hover/tap glossary, Escape closes, popup stays inside viewport, text selection survives. Check dark and light themes.
- Quiz: start through a user gesture; hear Arabic question and all numbered options, then «جاوب»; microphone starts afterward. Speak correct and incorrect choices and confirm transcript, correction, next question and final score.
- During reading/listening/correction: pause, repeat, reanswer, skip and exit; no stale microphone, spoken feedback or delayed next question survives.
- Deny microphone; simulate unsupported recognition, no speech and failed synthesis. Confirm written status, spoken fallback where available, editable answer, evaluate and retry.
- Keyboard only: Tab reaches all controls/terms, Enter/Space activates terms, Escape closes popup, editable manual answer submits with Enter.
- Ordinary quiz scores, activity and points stay unchanged.

