# Round 4 reader and normal Notes integration

Scope: Group A items 1–2. This document covers isolated snippets; root owns canonical `maqamooo.html`, PDF loader/SRI/CSP/asset serving, route integration and browser QA. No server, environment, Git, browser, Render or GitHub actions were performed by this implementer.

## Insert order and public interfaces

Append `work/round4/reader.css` to the maintained feedback stylesheet, after existing shared CSS. Insert `study-domain.js`, then `notes.jsx`, then `reader.jsx` into the existing Babel/React application script after shared hooks/owners are declared and before rendering App. Function declarations are hoisted, but the study store must initialize before components mount. These snippets contain no script/style wrapper.

- `Round4Study`: pure coordinate/page/context/history/vector helpers and store factory.
- `Round4StudyStore`: sole local study persistence service.
- `Round4BookReader({book,page})`: `book` accepts a catalog ID string or metadata object with `id`; it always resolves the canonical `/data/books.json` entry before loading a PDF. If props are absent it uses `useFeedback().payload.book` / `.id` and `.page`. Omitting page restores the book's last page, otherwise starts on the supplied physical 1-based PDF page. Page changes from navigation props are supported.
- `Round4NotesPage()`: the normal Notes list with source filter, search, clear-search, edit, delete confirmation and source jumps. This does not replace `smart_notes` or Maajem.
- `Round4QuickNotes()`: floating physical-right 44px button, contextual note dialog, removable reference chip, durable draft recovery, Save/Cancel. One visible instance at a time.
- `Round4NoteEditor` / `Round4ContextLabel`: shared normal-note UI, used by reader pins and Notes page.

Add `reader` and `notes` to FeedbackPages allowlist, titles and rendering branches, inside the existing FeedbackPageFrame. Add normal `الملاحظات` to More and retain `الملاحظات الذكية`. Replace every library/research/saved-reference PDF opening anchor with:

```jsx
f.open('reader',{id:b.id,book:b.id}) // library, restores last page
f.open('reader',{id:b.id,book:b.id,page:result.page}) // source reference
```

Use `id` as well as `book`: existing provider navigation identifies/cache-keys routes from payload.id. Persist book/page scalars in the canonical route-cache hydration whitelist. The reader emits `maqam:study-context` with `{source:'book',bookId,bookTitle,page}` once storage loads and on page changes, and emits `null` on unmount. Root should update the current reader route's cached page in both routePayloads and persisted pageCache on this event, without pushing history. Otherwise refreshing after entering through a research page can restore that original page instead of the page later reached.

**Focus/inert integration:** FeedbackPageFrame inerts its siblings. Therefore mount QuickNotes inside the frame for supported subpages, and in the main shell when no frame is open. A global sibling button becomes inert during reader/lecture. Do not render two buttons. Shared frame Escape handling must respect nested dialogs (`defaultPrevented` and/or stopped propagation); the notes overlays use MaqamDialogFrame and data-ui-close.

## PDF dependency contract

Root resolves exact verified cdnjs PDF.js module SRI and worker asset. Before reader use:

```js
window.MAQAM_PDF_READY // Promise resolving when module is ready; reject on loader failure
window.pdfjsLib // exports from exact pinned module
window.MAQAM_PDF_WORKER // matching pinned worker URL
window.MAQAM_PDF_ASSETS = {
  cMapUrl:'/assets/pdfjs/cmaps/',
  standardFontDataUrl:'/assets/pdfjs/standard_fonts/',
  wasmUrl:'/assets/pdfjs/wasm/'
}
```

Root selected PDF.js 6.4.299. The reader awaits READY if needed and supplies both `canvas` and `canvasContext` to render, compatible with the current API. getDocument uses `disableAutoFetch:true`, `disableStream:true`, `rangeChunkSize:65536`, `isEvalSupported:false`, `cMapPacked:true` and the three ancillary URL paths. No iframe, external tab, built-in PDF viewer or annotated-PDF dependency is used. CSP, main-module SRI, exact worker bytes and ancillary allowlist remain root/server responsibilities. No new API endpoint is needed for these snippets.

One page canvas is mounted. Only immediate page neighbors have their page proxies requested; neighbor pages do not get canvases. Old page resources are cleaned. Width/zoom re-render cancels the prior task. HiDPI is capped at DPR 2 and 16M backing pixels. Search reads text lazily in explicit 20-page batches from the current page to the end, with cancellation and at most 100 retained matches; scanned pages without text remain readable as images. Search does not OCR the full book or render all 1,467 pages.

## IndexedDB schema and ownership

Dedicated database **`maqam_study_v1`, version 1**. Existing **`maqam_feedback_files`, version 1, `files`** remains untouched. Rationale: existing fbOpenDB always opens that original DB at version 1; bumping it only in a new reader would make existing blob operations throw VersionError. A dedicated study DB is the explicitly chosen supported exception, isolates independent retention/size, and avoids changing original recording/blob behavior.

All new stores have keyPath `id`:

| Store | Shape / owner |
|---|---|
| `books` | `{id:bookId,revision,lastPage,strokes,updatedAt?}`. Strokes: `{id,page,tool:'pen'|'highlight',color:'#rrggbb',width,points:[{x,y}]}`. No note text or duplicate pin collection. |
| `normalNotes` | `{id,text,context,revision,createdAt,updatedAt}`. Book pin context `{source:'book',bookId,bookTitle,page,x,y}`; book quick-note references omit x/y; lecture context `{source:'lecture',lectureId,title}`; plain `{source:'quick'}`. |
| `drafts` | `{id:'book:'+bookId,value:{revision,lastPage,strokes,notes},updatedAt}` or `{id:'quick-note',value:{id,text,context},updatedAt}`. Drafts are distinct from saved records. |

Normalized x/y are clamped to [0,1], measured from the physical page content box after browser scroll/zoom and rendered at the same page origin. PDF page is physical 1-based, distinct from printed pagination. SVG vector data remains aligned with the canvas; pins use the same normalized coordinates. Notes are shared by stable note ID: Notes-page edit/delete affects that record and reader loading sees it. Book save commits strokes + book notes + draft deletion in one transaction. Notes edits/deletes advance their book revision to reject stale readers; moving a note's source invalidates both affected books. Save confirmation is emitted after transaction completion. Quick save atomically writes a stable-ID note and deletes its draft; quota failure leaves the prior draft intact.

Store API: `loadBook(id)`, `saveBook(id,{revision,lastPage,strokes,notes})`, `listNotes()`, `putNote(note,expectedRevision=0,draftId=null)`, `deleteNote(id,expectedRevision)`, `rememberPage(id,page)`, `putDraft(id,value)`, `getDraft(id)`, `deleteDraft(id)`, `subscribe(fn)`.

Writes serialize inside a store instance; cross-window read/modify/write transactions use IDB atomicity and revision checks. Multi-tab conflicts are reported, never silently force-overwritten. A draft based on an older saved revision cannot replace newer notes through Restore; its note text remains selectable for manual re-entry, and the underlying draft vectors remain stored until explicit discard. This intentionally favors preserving newer records over automatic conflict merging. There is no network/account sync.

Limits: note text 8,000 characters; book 2,000 strokes, 200,000 points, 2,000 associated notes; individual live stroke 12,000 points; draft serialized size 12M characters; 40 undo snapshots. The history shares immutable vector arrays rather than cloning every earlier stroke on every edit. Stroke colors and widths are validated on save. Quota/unavailable/blocked/conflict paths preserve editable input and show retry feedback. Autosave is 500ms after a change, with a best-effort unmount flush; only the actual completed-write status claims persistence. The browser can still abort a pending write if the process is closed before completion.

## Interaction and browser QA handoff

- Six named colors and three widths; translucent highlighter, eraser, pan/draw modes; pointer capture supports mouse/touch/stylus.
- Pin: choose text note and tap any exact position; edit by clicking the pin or panel item; drag to move or choose Move then tap a destination; delete in shared editor. Every change participates in undo/redo until explicit save. Keyboard users can add a centered note and edit its left/top percentages in the editor's Position disclosure.
- Mobile physical-right quick button measures fixed bottom navigation and mini player, and adjusts around visible video controls. Hidden during standard, WebKit and native iOS video fullscreen events. Confirm measurements with real layout at both requested sizes.
- Panels and dialogs reuse fb-button/fb-panel/MaqamDialogFrame, native labelled controls and existing D.2 tokens. Long note text wraps; dialog/textarea height is bounded; focus and reduced motion styles are provided.

Stable browser selectors: `reader-pdf-canvas`, `reader-annotation-canvas` (SVG despite test-hook name), `reader-tool-pan|pen|highlight|erase|note`, `reader-save`, `reader-undo`, `reader-redo`, `reader-note-pin` with `data-note-id`, `reader-color-أسود|أحمر|أزرق|أخضر|ذهبي|بنفسجي`, `quick-note`.

For 390px and 1440px, RTL, dark/light: open book-7; wait for rendered canvas; draw pen/highlighter in several colors/widths; undo/redo; tap note at known normalized position; drag and edit percentages; save and wait for explicit saved text; refresh; compare pin coordinates and vector width after resize/zoom/fit; confirm last page and source-reference page jumps. Open Notes, edit/delete same note and reopen reader. In a second tab change a book note then attempt stale reader save: require conflict, preserved draft and no overwrite. Quick note from lecture/book/plain page: remove chip, Save/Cancel, reload and restore draft, search/filter, ensure no collision with bottom nav/mini-player and fullscreen. Exercise storage denied/quota via browser tooling without production globals. Check no console errors and only one page canvas exists.

## Verification and differential review

Observed TDD RED: initial seven tests failed on missing domain; later quick atomic-draft deletion failed until implemented; broad-highlighter persistence failed (42 became 20) until the bound was corrected. Fresh study unit run: **12/12 pass**. Both JSX files parse with cached Babel parser. Fresh full Node suite: **150/150 pass**, including all 12 study checks. Tests use asynchronous atomic transaction/abort IDB double and real service logic, with injectable DB opening; no production automation globals or new npm dependencies.

Focused differential review: new isolated code against the existing baseline map, medium risk for local durable state and externally loaded PDF parser, low risk for scoped styles. Four public consumers (reader, quick notes, Notes page, root route/loader); no deleted baseline security code in this subtask. Reviewed path validation (catalog + same-origin /assets/books pattern), inert/focus integration, PDF render cancellation/unmount, normalized alignment, limited text search, stable note IDs, revision conflicts, quota atomic abort, pending autosave/explicit save order, and shared record deletion. Fixed quick-save draft resurrection/duplicate risk through stable IDs + same-transaction deletion + pending-save ref; fixed highlighter width normalization drift; fixed rapid resize render duplication; protected new edits while note saves are pending. React renders note text as text; no HTML injection or external note write exists. Canonical blob database and smart notes remain untouched.

Limits of review: snippets are new code, so no removed baseline code/history blame applies; root owns final integrated diff/history review. This implementer did not execute browser QA, actual large-PDF network/rendering, touch/stylus hardware, or root loader/CSP verification. Parse/unit checks do not establish those runtime results. Optional annotated PDF download was deliberately omitted as permitted by the brief.
