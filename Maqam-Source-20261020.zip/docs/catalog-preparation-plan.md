# Catalog transcript preparation — 2026-10-26

User explicitly authorized the remaining six public catalog recordings to be sent through Groq with account-credit consumption and publication of their machine transcripts.

1. Prepare recordings sequentially using the existing URL/audio/Whisper path. Reuse private audio-hash ASR cache to avoid duplicate charges.
2. Validate full audio coverage, source identity and absolute segment order using the existing strict server schema. Inspect and reject provider text in provably digital-silent samples. Preserve silence as timeline gaps; never fabricate text or clamp incorrect timestamps.
3. Save six actual machine sources under prepared-recordings. Keep unreviewed-machine-transcript disclosure. No UI, backend behavior, key, endpoint, font or dependency changes.
4. Run focused source tests, validate all seven bundled sources and review the data-only diff. Commit the group and build the existing release allowlist with checksums and secret exclusion.
5. Publish through the existing GitHub release branch and free Render service. Verify all seven completed source responses, HTML checksum, actual English subtitle and stop dubbing control. Report exact limitations.
