# Video pipeline map

Audit snapshot: 2026-10-26, `feat/notes-chat-groq`. Source inspection only; no credentials or environment files read. This records observed behavior and a proposed implementation contract, not a live provider verification.

## Existing paths and assumptions

- `maqamooo.html:2858` `round3Domain.mergeCatalog` turns `data/lectures.json` videoId into youtubeId and merges separate summaries/quizzes. The primary catalog records say transcriptStatus `not-obtained` (`data/lectures.json:15` onward); the catalog does not provide timed transcripts.
- `FeedbackLecture` (`maqamooo.html:3228` onward) is the watch page. It renders YouTube, native video/audio, or a locally stored blob. Its stable mediaAdapter exposes `{available,time,paused,rate,volume,muted}` and `setVolume`; YouTube time is polled every 250ms, native time comes from timeupdate. Watch progress is saved every 10 seconds and on departure. The translation component receives this adapter and current player time.
- `Round3Live` (`maqamooo.html:2865`) is a separate bare iframe. It has neither the watch adapter nor Round3LectureTranslation. `LiveTranslationModal` (`1311`) opens a selected lecture or validated YouTube link in the watch page; it does not capture live audio.
- `Round3LectureTranslation` (`3188`) accepts prepared subtitles only when videoId matches and alignmentVerified is true. Otherwise `Round5Media.lectureText` (`531`) chooses transcript, summary, details, then instructions. It chunks that text into untimed rows. No caller extracts audio from the video or sends it to speech recognition.
- The embedded MAQAM_SUBTITLE_SOURCE (`470`) and `data/subtitles-unverified.json:2-6` have null videoId and alignmentVerified false. Their duration-based sample text is deliberately ineligible for an actual lecture. Assigning a videoId to these samples would not establish source identity.
- Translation (`Round5Media.translate`, `539-546`) preserves row indices, caches by source/video/target/model/engine for seven days, sends small batches to same-origin `/api/translate`, and can fall back to the previous translation transport. Speech (`547`) accepts at most 200 characters per request. `createDubbing` (`549-562`) obtains audio only for translated text; it is text-to-speech, not video-to-text. It prefetches up to three segments and bounds decoded audio cache to six entries / 12 MiB.
- Dubbing is disabled when selectedText is absent or a matching voice is unavailable (`3208-3212`). In prepared mode selectedText also disappears between segments. This makes absent source text look like a broken dubbing control even when speech transport itself is functional.

## Missing bridge

Observed pipeline is `catalog/local text -> translation -> TTS`; the required `video URL -> acquired audio -> whisper-large-v3 -> timed Arabic rows` bridge is absent. `server.py:817` permits only chat, translate, upload, speech POST paths. Nothing found that obtains video audio or calls Whisper. A working translation or Edge TTS endpoint alone cannot translate the complete video.

## Existing server boundary to retain

`server.py:645` validates Host and any supplied Origin. Existing speech and batch translation require explicit matching Origin (`822`, `899`). POST framing (`833-879`) rejects transfer encoding, duplicate/missing/invalid content length, unsupported type, oversized/incomplete body; it reads within a deadline and parses strict JSON. Existing body limit is 16,384 bytes except image upload. Rate admission occurs before body reads. Provider redirects and upstream reads are bounded elsewhere in server.py. New preparation requests should reuse this boundary and error conventions, not introduce a second HTTP service or browser-visible provider key.

`handle_groq_translation` (`946`) uses the configured model, temperature zero, JSON-only ordered translations and max_tokens **150**. Preserve the approved exact model `qwen/qwen3.8-27b`, exact STT model `whisper-large-v3`, and pinned Edge TTS requirements. Existing translation batching is small because the output token cap is small; do not send an entire transcript in a single completion.

## Proposed narrow source preparation contract

Add a server-owned source-preparation module behind asynchronous same-origin endpoints. The names below are proposed, not existing API:

- `POST /api/source/prepare` with exactly `{videoId}` for the first supported YouTube path. Canonicalize an accepted URL in the browser to an 11-character ID; validate again on server. Return `202 {jobId,videoId,state,stage,progress}` quickly. Do not accept executable options, filesystem paths, model names, provider URLs, or extractor arguments.
- `GET /api/source/jobs/<opaque-id>` returns queued/processing/ready/failed state, bounded stage/progress, safe error code and, only when ready, the prepared data. Require request authority/origin policy consistently; an unguessable job ID is not permission to expose other users' private sources.
- Internal seam: `prepare(video_id) -> job`, `status(job_id) -> snapshot`, and injectable `acquire_audio(video_id, workspace, limits)`, `transcribe(audio_path, offset) -> rows`. Keep extractor/STT details out of React and existing speech/translation functions. Job admission deduplicates canonical video identity, bounds queue/workers, and never blocks a request worker for an entire lecture.
- Ready data remains compatible with current translation rows: `{videoId,sourceSha256,alignmentVerified:true,timing:'absolute',duration,segments:[{ar,start,end,duration}]}`. Here duration on each row is end-start; sourceSha256 identifies the actual acquired source/transcript, not the title or sample file. Machine timing is not a human claim of verbatim accuracy; include provenance such as `{engine:'whisper-large-v3',kind:'machine-transcript'}` and label it in UI.
- Only publish a ready result after all chunks are validated and complete. Whisper chunk starts/ends need each chunk's absolute audio offset added. Validate finite monotone nonoverlapping ranges, positive row duration, nonempty bounded Arabic text, total text and row count compatible with existing 2,000-row / 200,000-character client limits. Oversize input must produce an explicit limitation or use a deliberately revised bounded contract, not silent truncation.

## Timing constraint: preserve silence

Both `MaqamTranslation.segmentAt` (`476`) and `createDubbing.position` (`557`) currently calculate start by summing duration from zero. Whisper gives absolute start/end and includes initial silence and pauses. Summing end-start deletes those pauses and progressively desynchronizes subtitles/audio. Add one shared timing resolver that accepts explicit validated start/end when supplied and falls back to cumulative duration only for existing rows. The display and dubbing must use the same result.

The scheduler currently calls stop when position is null (`560`). For an absolute gap, it must silence/restore ducking but remain armed until the next segment. Distinguish a gap from the end of the recording. Starting dubbing at time zero or within a gap must remain possible once translated rows exist; gating the button on selectedText would otherwise prevent this. Tests need initial silence, a mid-video pause, seek into a pause, resume, changed playback rate, ending and source changes. Do not fabricate empty translatable rows to represent silence.

## Limits and source acquisition requirements

Use an argument array with shell disabled; a strict video ID still must not become command text. Enforce source duration, total downloaded bytes, actual file bytes, temporary disk budget, wall-clock deadline, provider upload size, chunk duration, queue count and maximum concurrency. Terminate failed/cancelled subprocess trees and clean temporary files on all exits. A format selector or declared metadata alone is not a byte limit.

Only access supported public media; restricted/login-required/unavailable/extractor-blocked sources must return a clear source error. Do not return extractor stderr, provider bodies, signed audio URLs or credentials. If broader URL support is added later, define explicit HTTPS host/port/redirect/IP rules before network fetches; nothing in the existing generic player URL validator establishes safe server acquisition. A source probe must establish that the actual target video can yield audio in this deployment before claiming end-to-end operation.

## Persistence and UI state

Keep prepared jobs/results in a private server-managed cache outside public static paths, keyed by source identity + STT model + schema version, with bounded age/count/size and atomic writes. Recover completed valid results after restart; expired/interrupted job references must resolve clearly and permit retry. Do not persist raw audio indefinitely. Keep existing selected language, speed, translated row cache and watch progress behavior. A client may persist only the job handle/source identity; revalidate its result before reuse.

A hook/client helper should own preparation polling, AbortController and stale-generation checks. Selecting another lecture, changing URL, closing a dialog or unmounting must stop local polling and prevent stale result replacement; shared jobs need not be cancelled merely because one viewer left. Display preparation stages, retryable error and actual progress; do not translate summaries while presenting them as the full video's transcript. Feed only ready matching-source rows into the existing Round5Media translation/TTS flow. Full live-stream capture is a separate unimplemented capability; recorded-video preparation must not imply live streaming support.

## Verification plan

- Unit tests for exact request schema, canonical IDs, origin/framing preservation, job bounds/deduplication, expiration/restart, atomic result persistence and sanitized failures.
- Inject acquisition/STT fakes: successful full source, offset-preserving multi-chunk rows, initial/middle silence, invalid timestamps, transcript limits, extractor timeout, byte limit, provider rejection and interrupted cleanup.
- Extend `tests/round3-translation.test.js` and `tests/round5-media.test.js` for absolute timing plus backward-compatible duration-only rows, gaps remaining armed, seek/pause/rate/source change and duck volume restoration.
- Extend component/watch checks (`tests/round3-watch.test.js`) for prepare state, ready result identity, no source text, retry, stale polling result, button enabled during silence, selected language restoration and transcript display provenance.
- Retain `tests/test_round5_groq.py`, `tests/test_round5_edge.py`, `tests/test_server.py` transport and existing speech/translation behavior. Assert approved exact model names and max_tokens 150.
- One explicit live source acquisition -> Whisper -> translated row -> Edge audio verification is needed beyond fakes. Record redacted status/model/source evidence and any host restrictions; do not call mocked provider tests live verification.
