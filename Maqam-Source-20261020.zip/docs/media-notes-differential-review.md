# Media and smart-note differential review — 2026-10-28

## Executive summary

Scoped independent review of uncommitted/staged changes on `fix/media-notes-round` against `de79806` (`HEAD` at review start). Recommendation: **changes requested** for two functional regressions below. No secret files were read. No server/config/dependency changes were observed.

| Severity | Count |
|---|---:|
| Critical | 0 |
| High | 1 |
| Medium | 1 |

## Findings

### High — Versioned quiz ID escapes canonical resolution

`FeedbackLecture` and `Round3Activities` append `servicesVersion` to generated quiz IDs. `feedbackDomain.resolveContent` still obtains the lecture ID by removing only `lecture-` and exact matching against `data.lectures`. Thus `lecture-test-sample-9aead957` searches for `test-sample-9aead957`, finds nothing and returns the supplied payload unchanged. Initial click has supplied questions and appears to work, but refresh/deep link supplies only id and loses the questions. A stale payload also bypasses the source cancellation/current-questions boundary. Resolve generated IDs against the current canonical per-lecture quiz ID and reject obsolete versions; cover refresh, stale questions and cancelled source.

### Medium — Constant-rate change drops overflowing speech at subtitle boundaries

Removing per-segment `fit` fixes speed/pitch changes, but `tick` still calls `invalidate/silence` on segment-index changes. A6s translated utterance assigned to a5s subtitle previously finished at1.2×; it now plays at1× and is forcibly stopped at5s, discarding final words. Keep constant tempo while providing a bounded, user-cancellable strategy to finish overflowing speech (e.g. an owned video pause or larger sentence units). Add a test that asserts completion, not only equal playback rates.

## Other source-replacement observations

Existing users retain old watchProgress keyed only by `lecture.id` and can start the new65s clip at44s. Existing imported assignment metadata is append-only, retaining the old sheikh on previous installations; instructions still apply. Consider source-aware progress and metadata refresh without altering saved answers.

## Scope and blast radius

- Native engine and dubbing scheduler: shared by all lecture translations. WAV buffer encoding/resource cleanup and selected browser-voice pinning reviewed. New native pitch-preserving path still needs actual browser autoplay/pause/seek/stop checks; mocks cannot establish that.
- OCR compression/preprocessing/worker configuration and capabilities fallback: shared image-review entry points. Input/upload limits and cancellation remain; contrast/upscale is bounded, bitmap closed. Real handwritten/OCR quality cannot be inferred from unit tests.
- Smart-note handoff: opening state, queued save and clearing stale extracted text on image replacement reviewed. Existing actual note-discussion backend is unchanged; no proof of a general broken button root cause from source alone.
- Media/catalog summary/quiz changes confined to sample source. Original source data hash regressions remain covered. New public media use is explicitly approved by user.

## Verification

Ran `node --test tests/media-notes-repair.test.js tests/round5-media.test.js`: **37 passed,0 failed**. This proves current tests pass but the two regressions above are not covered. No browser or live-service actions were performed by this reviewer. Report is based on source snapshot; parent implementer may subsequently fix findings and record final re-verification.

## Re-review after fixes

Re-reviewed current uncommitted HTML after parent addressed findings. Recommendation now **approve subject to the planned actual-browser playback verification**; no remaining concrete blocker found in this source pass.

- Versioned quiz: resolver now matches the canonical current quiz ID, restores current questions for id-only refresh, and rejects obsolete version/cancelled sources. New regression test covers all three; finding resolved.
- Overflowing speech: scheduler now records running speech, holds the video under an ownership token near the boundary, completes at constant tempo, and resumes only if time/rate/user-intent version still match. A120s cap limits failed completion. The new test proves owned completion and cancellation after seek/version change. Finding resolved within available timer precision; native/browser late-play and mobile timing still require the planned UI test.
- Watch progress now uses `servicesVersion` only where supplied; existing users do not resume replacement at the old source time. Other lecture keys remain unchanged.
- Catalog-origin assignment metadata is refreshed from current catalog while the existing submissions/drafts maps remain untouched. Other origins remain untouched.
- Native audio WAV path: reviewed RIFF/PCM encoding, per-play rate and pitch preservation, warm-up URL comparison guarding late unlock completion, `onended` detachment before pause/load, Blob URL revocation and generation-aware rejection handling. No additional lifetime defect found. Mocks establish data flow/intent, not browser autoplay policy or audible quality.

Fresh verification: `node --test tests/media-notes-repair.test.js tests/round5-media.test.js tests/feedback-domain.test.js` — **62 passed,0 failed**. The parent retains responsibility for screenshots, actual OCR quality limits, production backend availability and publication proof.
