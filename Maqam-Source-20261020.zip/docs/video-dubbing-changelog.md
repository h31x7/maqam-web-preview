# Recording dubbing repair — 2026-10-26

## Confirmed root cause

The published first real lecture had no transcript or captions. Its translation component only accepted stored text, leaving translation empty and play disabled. Earlier generated-text endpoint checks did not prove whole-video dubbing; the user correctly reported this gap.

## Implemented and verified locally

- Real registered YouTube audio extraction with pinned yt-dlp2026.10.21 and EJS0.8.0. No cookies or sign-in bypass. Node used when available.
- Private bounded TLS/range transport feeds ffmpeg, without writing a full video or full source-audio file. Public Googlevideo host/DNS/IP validation, redirect validation,1MiB upstream ranges,128MiB aggregate limit,4 concurrent ranges and deadlines remain. A real open-ended-range/seek stall was reproduced and fixed with independent ranges and no lock across network I/O.
- imageio-ffmpeg0.6.0 produces mono16kHz32kbMP3 chunks; Whisper-large-v3 returns actual segment timestamps. Empty-text silence intervals are kept as gaps, not invented words. Full decoded chunk manifest coverage must match the recording duration; invalid/oversized sources fail rather than truncate.
- Same-origin /api/lecture-source preparation jobs are bounded, single-worker, registered-recording-only and cache validated transcripts. GET accepts absentOrigin for UUID-bound public-source reads; bad suppliedOrigin and cross-site fetch are rejected. POSTrequiresOrigin.
- Full actual uJENBxFnDbU recording:4395seconds,1423nonempty speech rows, last speech end4392.34516, with complete decoded audio coverage and final silence retained; real extraction/transcoding/transcription completed in80.3seconds locally. This exact machine transcript is bundled privately under prepared-recordings to avoid billing ASR again for every deployment. It remains explicitly unreviewed, not a human-approved religious text. Other registered recordings prepare on demand and require successful host/provider access.
- Client source preparation/progress/retry/cache, absolute timing with initial/mid/tail silence, and lazy translation of at most6segments/about30seconds near the current position. Sparse updates do not fabricate text or reset the unlocked audio controller. Missing translation buffers playback with guarded resume; user pause/seek intentions invalidate that resume.
- Browser on the actual lecture displayed English text matching the real source and advanced the subtitle with the YouTube video. The play action armed synchronized reading. Browser console showed no errors on this path. Continuous reading later hit the pre-existing speech20/minute budget; it is a real outstanding limit, not a claimed pass.

## Evidence / tests

Client214JS tests and JSX parse passed. Server18focusedsource/cache/concurrency/silence tests passed. New regressions were seen failing for the locked bridge, missing range bounds, silence rows and per-row limits before fixes. The full Python aggregate stalled in this host's existing asynchronous-loop setup and was stopped; no aggregate success is claimed. Independent review is in video-pipeline-review.md. CodeQL remains blocked as previously recorded.

## Release status — 2026-10-26

The user explicitly approved Edge-only 120/min/IP; applied and verified by the 19 focused source tests. Groq remains 20/min and all body/audio/security limits remain unchanged. An earlier pending-approval note is superseded.

Added a separate إيقاف الدبلجة الصوتية button. It invokes the existing scheduler stop, cancels pending playback/prefetch, clears speaking/mute state and announces the stopped state. Existing translation continues. Browser verification on both localhost and the deployed real lecture showed start enabling Stop and Stop restoring Play with the correct status; no console errors observed. The focused diff adds only this handler and button to the existing translation controls.

Source implementation commit: 472685a873f05135fb651a1565ce09ec1a6b4609. GitHub release commit: 510eebe8a72f3a49e1513f3efccc7e7a064de2ad. Render deploy dep-dbff9l7avr4c73duegsg is live, finished 2026-10-26T06:37:11Z. Remote HTML SHA-256 matches the local source; /api/health returned ok. The release archive is 18,587,615 bytes with SHA-256 73df7cea64d53f057a13693aee37882e67e8ab61c18cda2b11640b982df9f08a. Existing free plan unchanged.

Current rerun: all 214 JS tests pass and 19 source Python tests pass. Initial Python rerun lacked network permission and failed loopback tests; after network permission, the same suite passed. No aggregate Python or CodeQL clean claim. Current small control change was browser-tested at the available desktop viewport; the full dark/light 390/1440 matrix has not been rerun for this control.

Public actual uJENBxFnDbU source returns completed with 1423 rows; its English translation appeared and Stop worked. A fresh nonbundled C5b3LdzYkEc preparation on Render failed honestly at progress 3 with source_unavailable. This does not establish the exact upstream cause. Other recordings' on-demand cloud acquisition is therefore NOT claimed working. Unbounded live-stream transcription also remains unimplemented by this recorded-source pipeline.

Preparing the other six recordings locally through Groq was blocked before execution by automatic review because batch ASR may consume account credits; explicit user approval has been requested. No batch execution or additional transcript files are claimed.

Screenshots: docs/screenshots/video-dubbing/actual-recording-local.png (prior actual-source evidence), stop-control-local.png, stop-control-live.png. The final screenshot shows the stop acknowledgement and English subtitle on the public lecture.
