# Recording dubbing repair — 2026-10-26

## Confirmed root cause

The published first real lecture had no transcript or captions. Its translation component only accepted stored text, leaving translation empty and play disabled. Earlier generated-text endpoint checks did not prove whole-video dubbing; the user correctly reported this gap.

## Implemented and verified locally

- Real registered YouTube audio extraction with pinned yt-dlp2026.10.21 and EJS0.8.0. No cookies or sign-in bypass. Node used when available.
- Private bounded TLS/range transport feeds ffmpeg, without writing a full video or full source-audio file. Public Googlevideo host/DNS/IP validation, redirect validation,1MiB upstream ranges,128MiB aggregate limit,4 concurrent ranges and deadlines remain. A real open-ended-range/seek stall was reproduced and fixed with independent ranges and no lock across network I/O.
- imageio-ffmpeg0.6.0 produces mono16kHz32kbMP3 chunks; Whisper-large-v3 returns actual segment timestamps. Empty-text silence intervals are kept as gaps, not invented words. Full decoded chunk manifest coverage must match the recording duration; invalid/oversized sources fail rather than truncate.
- Same-origin /api/lecture-source preparation jobs are bounded, single-worker, registered-recording-only and cache validated transcripts. GET accepts absentOrigin for UUID-bound public-source reads; bad suppliedOrigin and cross-site fetch are rejected. POSTrequiresOrigin.
- Full actual uJENBxFnDbU recording:4395seconds,1423nonempty speech rows, last speech end4392.34516, with complete decoded audio coverage and final silence retained; real extraction/transcoding/transcription completed in80.3seconds locally. This exact machine transcript is bundled privately under prepared-recordings to avoid billing ASR again for every deployment. It remains explicitly unreviewed, not a human-approved religious text. Other registered recordings prepare on demand and require successful host/provider access.
- Client source preparation/progress/retry/cache, absolute timing with initial/mid/tail silence, and lazy translation of at most6segments/about30seconds near the current position. Sparse updates do not fabricate text or reset the unlocked audio controller. Missing translation buffers playback with guarded resume; user pause/seek intentions invalidate that resume.
- Browser on the actual lecture displayed English text matching the real source and advanced the subtitle with the YouTube video. The play action armed synchronized reading. Browser console showed no errors on this path. Continuous reading later hit the pre-existing speech20/minute budget; it is a real outstanding limit, not a claimed pass.

## Evidence / tests

Client214JS tests and JSX parse passed. Server18focusedsource/cache/concurrency/silence tests passed. New regressions were seen failing for the locked bridge, missing range bounds, silence rows and per-row limits before fixes. The full Python aggregate stalled in this host's existing asynchronous-loop setup and was stopped; no aggregate success is claimed. Independent review is in video-pipeline-review.md. CodeQL remains blocked as previously recorded.

## Pending release gate

Automatic approval review rejected raising only the Edge speech budget from20to120requests/min/IP because it requires explicit permission. The regression demonstrates rejection atrequest21under the current limit. The user has been asked; no rate-limit change has been applied. Existing Groq limits,200-character text limit,2MiB audio limit and other security settings remain.

The repaired code is saved on fix/video-source-dubbing. Publication must wait for the speech gate/verification; real extraction on Render remains unverified. The recordings are not live streams; continuous unbounded live input is not claimed by this whole-recording preparation path. No new STT endpoint for arbitrary private URLs/files is exposed.

User explicitly approved Edge-only120/min/IP. That exact bounded setting was applied after the observed request21 regression; Groq20/min and all text/audio/security limits remain unchanged. Actual continuous playback and hosted source preparation still require final verification.
