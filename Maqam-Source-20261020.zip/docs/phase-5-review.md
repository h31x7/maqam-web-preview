# Phase 5 differential and runtime review
Source preservation PASS: 50 original declarations, callback values/counts, original non-style attributes, ordered Arabic text and child-render conditions. server.py/.env byte-identical. Source hash is recorded in preservation-result.json. No business logic/data/state/API/storage changes accepted.

Final fixes: mobile nav top reset; mini player above bottom navigation; stable shell class prefix; correct play/pause SVGs; opener focus restored after Escape; solid themed modal surfaces; dark live-translation/media surfaces; 44px control sizing; compact mobile calendar; JSX indentation/class deduplication below Babel 500KB warning threshold.

Original accessibility filter creates a containing block for fixed descendants. A presentation-only viewport anchor manager compensates fixed top/bottom coordinates while retaining original filter and page scrolling. It batches measurements and scans known fixed candidates. Runtime filtered dialog top=0/height=1000; student long-page scrollY=1644.8 with rail top=0/bottom=1000. No actual student record was modified.

Independent focused review found three issues (mini overlap, selected class concatenation, incorrect play glyph); fixed. Review raised fixed-element scanning cost; narrowed candidates and batched reads before writes. No further confirmed correctness regression in that review.

Runtime: 120 recorded width/RTL/document-overflow checks passed. All 19 dashboard tabs captured in two modes at three widths. Guest flow, tab switching, Maajem reply, language selection, accessibility toggles, dialog focus/Escape, media UI/minimize, lecture quiz and calendar/map were exercised across phases. External playback and permission-dependent speech are not claimed. Final input is below 500KB, but Babel still emits an oversized-generated-code styling notice after reload (tool reports it at error level). This is an unresolved informational console finding, not a React runtime exception.

Verification limits: see ui-changelog.md. Exhaustive final modal/state comparison is still incomplete; phase screenshots alone are not sufficient to claim all state/device combinations. The preserved original empty recovery link remains a baseline static-audit exception.

Final dialog accessible name derives from its existing heading; Escape restored focus to btn-language-selector. Fresh original viewport set has 60 captures.

Supplement: sign-language PIP visibility checked at 3 widths; mobile drawer Escape returned focus to its trigger with aria-expanded=false. Four teaching forms captured in both themes; light quiz tablet/desktop capture timing was rechecked in separate calls (768/1440 confirmed). No teaching content was published.
