# Smart notes repair context — 2026-10-28

Scope: read-only map of image-to-text and note-to-Maajem paths at current source (no implementation changes, no secrets inspected). Line numbers refer to `maqamooo.html` unless marked server.

## Image-to-text

| Stage | Location | Contract / state |
|---|---|---|
| Lazy OCR assets | 537–538 | `MAQAM_OCR` pins Tesseract5.1.1 worker/core CDN; language data same-origin `/assets/ocr/`. `loadRound4OCR()` reuses one loading promise and resets on script failure. |
| Input and preview | `Round4ImageReview`, 3068–3131 | `choose` clears prior preview/text/review, increments generation, aborts preceding request; accepts PNG/JPEG/WebP through `compress`; outer timeout120s. Source image is not persisted by this component. |
| Decode/compress | `Round4Vision.headerDimensions/compress`, 795–821 | Rejects >10MB, dimension>12000 or >40MP before decode; white background; downsizes longest edge to2400; JPEG qualities .88/.73/.55 until<=2MB. No explicit deskew, contrast normalization, crop or text-preserving PNG branch found. |
| Provider decision | `choose`, 3085–3103 | GET `/api/capabilities`; if configured+vision, POST `/api/upload`, then `/api/chat` with `files:[upload_id]`. Prompt demands literal extracted_text and uncertain_words JSON, rejects image instructions. Structured provider response accepted; otherwise local OCR fallback. Capability request failure currently enters outer catch before local OCR path. |
| Provider boundary | `server.py:728–734,1099–1124` | Capability queries existing Dify image-upload configuration. Upload accepts validated image, forwards to Dify, maps provider reference to anonymous owner for15min. No new OCR-specific backend endpoint. |
| Local recognition | `Round4Vision.recognize`, 856–872 | Worker `createWorker('ara',1,...)`; Arabic only. 45s startup timeout; generation abort terminates worker; worker.recognize(blob); finally terminate. No explicit page segmentation, whitespace preservation, language mixture or multiple-pass recognition settings found. |
| Result schema | `ocrResult/transcription`, 745–762 | Text must be nonempty <=12000; low-confidence words<60 get literal `[غير واضح]`; result silently bounds to1800 and returns truncated flag/confidence. Provider plain answer is never treated as extracted text. |
| Edited text | `acceptText`3076; textarea3121 | setText plus onExtracted callback; manual edits callback also. UI textarea1800chars; extracted result persists through adapter. |
| Source-backed review | `trustedExcerpts/reviewPrompt/parseReview`, 764–793,836–855; submit3108–3118 | Searches seven book indexes; max3 bounded excerpts; POST same `/api/chat`; parser only accepts source-grounded exact literal statements and evidence; request timeout90s. This is review, not OCR. |

## Save and discussion bridge

- `Round5SmartNotes`2734–2740 imports existing `feedback.data.smartImageText` and durable `smart-current` record. Tracks `ready/saving/epoch/initial/noteId/error`, refs `latest/revision/dirty/writes/sequence`.
- `extracted`2739 updates latest ref, feedback JSON `smartImageText`, schedules500ms autosave. `save`2737 serializes writes, invokes `Round4StudyStore.saveSmart('smart-current',text,revision)`, catches persistence error to UI; revision advances only after success.
- Button2739–2740 `ناقش مع معاجم`: disabled if not ready/saving/blank latest; clears debounce, awaits save; only on successful note dispatches `Round5NoteChat.open(n.id)`. No direct navigation to main Maajem tab; intended UI is a note-specific discussion dialog.
- `saveSmart`726: reads existing note, rejects identity/revision conflict, unchanged text returns original record, otherwise normal note mutation. `normalNotes` has up to8000chars; smart extraction UI bound1800. Metadata/versions/threads retained.
- `Round5NoteChat.open`2700 dispatches `maqam:note-chat` with noteId. Host2702–2707 subscribes in effect; persists active id under `maqam:active-note-chat`; reads it on mount. No replay/acknowledgement outside localStorage found.
- Host placement2913 when no Feedback view; alternatively3136 inside FeedbackPageFrame. Smart notes is student tab6221. Reachability assumption: a listening host must be mounted when bridge dispatches; source shows those host placements, browser proof still required.
- `Round5NoteDiscussion`2709–2732 loads note from same store, per-user thread via `getAnonymousUserId('student')`, uses shared Maajem message/composer. Actual question POST `/api/chat`; prompt includes bounded current note/context plus user question, response persists only if thread revision unchanged. Opening dialog itself does not send query.
- Discussion state is IndexedDB `maqam_study_v1` version1, stores `books/normalNotes/drafts`(713). `normalNotes[id]` contains context, text, revision, versions and threads indexed anonymous user. Transactions serialize via store queue715, notify subscribers only on successful readwrite completion. No cross-tab BroadcastChannel found in this store.
- Dialog wrapper1024–1052 sets accessible name/focus trap; note dialog z-index100001. Feedback full page3136 sets sibling inert state. Need inspect actual DOM stacking/inert status when reproducing reported button failure; source alone does not prove failure.

## Existing verification and open questions

- `tests/round4-vision.test.js`: result uncertainty, structured transcription, exact review evidence, bounds/predecode dimensions, startup cancellation/late-worker termination. No real OCR accuracy fixture or local/provider quality comparison found.
- `tests/test_round4_images.py`: backend image validation and provider image-upload ownership/capability boundary.
- `tests/round5-notes.test.js`: persistent smart identity/versions/thread metadata, conflict safety, deleted-note protection, unchanged smart reopening, shared composer static checks. No click-through bridge browser test found.
- `tests/round4-study.test.js`, `round4-interactions.test.js`: storage/reader and interaction coverage adjacent to paths.
- Repro work to obtain: (1) failing image + actual extracted text/provider selection; (2) click after typing, after autosave, after extraction and after refresh; capture whether button disabled, save fails, event received, host dialog exists/inert, console error. These observations were not executed by this context-only task; no root cause asserted.
