# Round3 changelog
Work in progress, not a finished round. Current implementation/status, evidence and next tasks: [checkpoint](round3-progress.md). Detailed initial mapping: [map](round3-map.md).

RetainedD.2 tokens, body/heading fonts and single-fileReact stack. Original brand wordmark retained with light-theme CSS mask; assets contain original bytes and contained icon derivatives. Current catalog uses seven supplied primary videos and nine secondary text lessons. Unavailable primary summaries/quizzes are not generated from guesses.

Added local reminder subscriptions, playlists and safe savedTeams configuration; official weekly timetable replaces monthly calendar; seven supplied PDFs and first-page covers feed library and exact-page source search. New research saved records use existing feedback storage; no server-side academic publication/multi-student ranking claimed.

Assumptions: source language list actually172names, duplicatecodes remain pending normalization; provided subtitle identity unknown; poster monthlyTuesday ordinal unknown; poster applies onlyRabiII1448; PDF page means physical page order, not printed pagination. Hadith-grade filter matches a literal source word and does not authenticate a hadith. OCR requires visual PDF review and low-confidence pages are excluded.

Screenshot inventory: files under docs/screenshots/round3-before and docs/screenshots/round3-global. Current screenshots cover entry/visitor baseline, timetable and library examples, not every acceptance path. Full matrix pending. Differential reviews linked in checkpoint. No successful CodeQL analysis (host extraction failure).

Latest implementation and acceptance status: [2026-10-24 checkpoint](round3-checkpoint-2026-10-24.md). Supersedes older implementation-pending list; release acceptance remains incomplete.
