# Notes discussions and Groq translation/dubbing implementation plan

> For agentic workers: REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans, task by task.

Goal: implement note-scoped Maajem conversations with explicit versioned edits, and bounded Groq translation/speech behind the existing same-origin server.
Architecture: single HTML React/Babel application and standard-library Python server remain. Existing IndexedDB note records own threads/version snapshots; server alone reads Groq configuration. Shared chat presentation, safe Markdown and current appearance tokens remain canonical.
Spec: C:/Users/fares/.codex/attachments/7767654b-0f6a-4a93-b221-ddba33f7a857/Pasted text.txt

## Global constraints
- No questions; resolve routine choices in the changelog. No Render/GitHub or other plugins this round; document production environment setup only.
- No Groq secret in HTML, responses, logs, docs or git. Only server GROQ_API_KEY environment configuration, .env ignored and never served. Do not read or print secret values during audits.
- GROQ_TRANSLATE_MODEL has no guessed default. If unset, report not configured and explicitly fall back to the prior engine; all other work continues.
- AR/EN Orpheus model defaults from spec; official docs currently list 200 characters for either model, WAV only, Arabic voices abdullah/fahad/sultan/lulwa/noura/aisha and English autumn/diana/hannah/austin/daniel/troy. Use configured models/voices; defaults fahad/troy if omitted. Verify /models on setup/startup without blocking HTTP startup.
- Keep Arabic copy and unrelated UI/state/endpoint behavior. Preserve the existing scalar /api/translate contract for platform translation while adding strict batch input for Groq and /api/speech.
- No fake religious verdicts or sources. Chat reply is real /api/chat output; revisions require explicit apply and durable history.

## Review focus
- Reader saveBook must not erase concurrently updated note threads/history; deleting a pin or note cascades its thread.
- Provider conversation IDs never cross note or browser-user boundaries; late responses cannot overwrite another note or manual edits.
- No silent proposed edits, raw model HTML, invented citations or unsupported religious certainty; malicious delimiter and overlong context cases.
- Seek/pause/rate/language/voice changes abort stale speech and restore original volume; audio is user-gesture initiated and prefetch is bounded.
- Groq malformed output, 429/5xx/timeout/unavailable model and missing settings remain bounded, honest and key-free.

### Task 1: audit / baseline
- [x] Map notes/chat/translation/player/proxy before edits in docs/round5-map.md.
- [ ] Capture representative baseline notes/chat/translation at 390/1440 dark/light.

### Task 2: Group A note discussions (single owner agent)
Files: maqamooo.html, tests/round5-notes.test.js, relevant Round4 study tests; DESIGN/UX contract note extension.
Interfaces: Round5NoteChat.open(noteId), host inside the active FeedbackPageFrame (and main provider when no view); shared Maajem message/composer presentation used by existing student chat and note chat. Round4StudyStore gains atomic get/update-thread/apply/restore operations on existing note records, bounded thread map by browser identity, version history and conflict protection. Smart text gets a stable durable normal-note adapter (source smart) without replacing image OCR/review.
- [ ] Red tests: note/user isolation; thread persistence; saved versions/apply/restore; deleting note/pin removes thread; reader saves preserve newer metadata; malformed revision fallback; stale/oversized contexts.
- [ ] Implement all normal/quick/lecture/book/smart entry points. Quick save stays reviewable with discuss action. Current text/manual edit always available; before/after proposed card explicit apply/ignore and fallback replace action.
- [ ] Privacy notice once, active-panel/draft restore; real API, stop/retry/regenerate/copy; sanitized Markdown and only backend citations.
- [ ] Unit/parse/shared-suite checks; differential review and Group A commit.

### Task 3: Group B Groq server (separate owner agent)
Files: server.py, tests/test_round5_groq.py, .env.example; no actual secret edits by agent.
Interfaces: POST /api/translate legacy scalar retained; strict batch {sentences:[...],target:code} => {translations:[...],engine:'groq'}; POST /api/speech {text,language:'ar'|'en',voice?:id} => WAV; GET /api/speech => safe voice/capability metadata. New client uses these exact fields. Generic errors include stable code and Retry-After when applicable. Existing /api/chat untouched.
- [ ] Red HTTP tests for strict schemas/bounds/origin/rate, array order/length/retry, 429/5xx/backoff, WAV/header/voice/char validation, missing configuration and secret sanitization.
- [ ] Standard-library bounded fixed-host upstream calls, no redirects. Key loaded only from environment; optional local .env loader only for listed Groq settings, process env wins. Validate models in background/setup, expose only safe voice metadata. Never log provider bodies or exceptions containing headers.
- [ ] Confirm official docs/model list and code tests, commit Group B server.

### Task 4: Group B translation and dubbing client (root)
Files: work/round5 client snippets then maqamooo.html after Group A owner returns, tests/round5-translation.test.js / dubbing tests.
- [ ] Batch Groq-first lecture transport, identity-bound cache v5 including source/model/engine, loading/progress/abort; explicit functioning legacy engine fallback, no unchanged text presented as translation.
- [ ] Narrow media adapter from FeedbackLecture for YouTube/native state/time/rate/volume, with ownership cleanup; standalone modal honestly unsynced.
- [ ] AR/EN Groq WAV with safe voice choices and <=200 character sentence chunks; prefetch 2–3, generation cancellation, cache bounds and user gesture unlock. Other languages exact browser voice or explicit unavailable message. Handle seek/pause/resume/speed and restore ducked volume.
- [ ] Tests and parse/integration; commit Group B client after review.

### Task 5: QA, CodeQL and delivery
- [ ] Inspect only nonsecret configured model/voice names; missing tested translation model remains unset, not inferred. Actual key installed locally without echo only after implementation boundary exists.
- [ ] Execute browser 390/1440, RTL, both themes; note create/discuss/proposal/apply/undo/refresh/delete coverage, multiple languages and unsupported/rate error simulation; distinguish actual-provider checks from fixtures.
- [ ] CodeQL fresh Python extraction and explicit suite/quality guards for new endpoints; if host extraction remains blocked, report evidence, never claim clean.
- [ ] Group differential reports, final docs/round5-changelog.md and .env.example; secret/static checks, complete meaningful test suites and local commits. No deployment.
