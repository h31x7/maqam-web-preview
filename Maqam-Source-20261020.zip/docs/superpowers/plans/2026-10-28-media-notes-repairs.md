# Media and smart-note repairs — implementation plan

User scope: replace only the existing final sample recording; stable selected dubbing voice and tempo; better Arabic OCR; working smart-note discussion. No visual redesign, dependencies, server.py or .env changes. User explicitly approved new clip audio to Groq and public replacement. Existing discussion Dify integration stays; missing provider config must be reported honestly.

- [x] Map current paths and reproduce failures. Baseline: 217 tests, first native clip44.15s. Dubbing uses per-segment AudioBufferSource rate-fit up to1.35 (pitch varies); browser fallback picks first language voice rather than selected name. OCR shrinks to2400/JPEG, lacks deskew/segmentation parameters; capabilities failure bypasses local fallback. Local discussion opens but chat503 because local Dify configuration is absent; inspect production and save/open race.
- [x] Write failing regression tests for constant tempo, selected voice, pitch-preserving engine, OCR parameters/fallback, and reliable save-to-discussion.
- [x] Implement stable pitch-preserving playback using existing browser APIs; keep selected voice fixed through session, keep seek/pause/stop/ducking/cancellation. No per-segment rate fitting.
- [x] Prepare new65s source via approved Whisper, actual poster/remux and same lesson identity, new source identity/hash/cache. Replace summary/questions/assignment from actual new text, retain history of prior clip in Git.
- [x] Improve local OCR source resolution/lossless path and bounded adaptive contrast/upscale, worker rotation/segmentation, word confidence; preserve original preview; keep privacy, file limits, cancellation. Capabilities error must still permit local OCR.
- [x] Make discussion handoff save/await latest text deterministically, with visible opening state and actionable errors; test real backend response where configured. No alert stubs or fake response.
- [x] Run Node/Python relevant checks, parse JSX, browser390/1440 both themes actual image OCR/discussion/playback/dubbing, refresh persistence, diff review and fresh independent final review. Commit per group. Publish existing service after verified build, verify native asset hash/live UI.

Ruling: fix the common playback/OCR pipeline rather than language-specific translation redesign; user did not ask for changing translation models or prior sentence-segmentation suggestions.

Final: source33d46a6;224 Node and14 Python tests pass; live publication verified in docs/media-notes-changelog.md. Local Dify unavailable; actual production response verified. No claim of perfect handwritten OCR.
