# Round 3 book indexing and OCR

The index uses supplied book order, IDs book-1 through book-7 and physical PDF page numbers starting at 1. Text is never inferred from a title or summary. Each record retains text, normalized searchText, method and quality; OCR adds mean word confidence. Search normalization applies Unicode NFKC, removes Arabic vocalization/tatweel, and collapses whitespace. The original PDF remains the citation authority.

Book 3 (23 pages) and book 5 (308 pages) have extracted text indexes. Their text is explicitly unreviewed: even usable layers contain occasional corrupt Quranic text, duplicated letters and layout artifacts. Automatic search is discovery only; quotations, hadith grades, names and religious conclusions require checking the linked original physical page. No OCR-derived grade is promoted to verified metadata.

The other 3,308 pages require Arabic OCR. Portable vendor micromamba downloaded from https://micro.mamba.pm/api/micromamba/win-64/latest. Package resolution uses conda-forge. Its environment registration tried a user-home file and failed under the sandbox; no home configuration was changed. Instead acquire.py downloads the solver-selected conda-forge packages, verifies each SHA-256 against registry metadata and extracts payloads into work/round3/ocr/runtime. Package metadata and solver output remain private build evidence. No global installer, OS setting, paid service, secret or GitHub access is used.

Builder: scripts/round3_index_books.py. Arabic Tesseract, 200dpi grayscale, page segmentation mode 3; one OpenMP thread per worker, default 8 workers. Individual page results are checkpointed privately and aggregate public JSON indexes are refreshed after every 20 completions. Manifest records actual indexed counts and completion, never a fabricated full-corpus status. The builder can resume and republish with --publish-only. Hardware reports 16 logical CPUs; OS memory query was denied by sandbox. Actual image/worker memory and throughput are measured below after acquisition completes.

## Measured sample and running build

Portable Tesseract 5.5.3 runs successfully with the bundled conda-forge Arabic traineddata (1,432,056 bytes). The package separates model data under runtime/share/tessdata and output configs under runtime/Library/share/tessdata; the builder explicitly enables TSV output, avoiding an incorrect silent text-output interpretation. TSV rows are split by tabs with bounded fields; CSV quote handling must not be used because Arabic source punctuation can contain unmatched quotes.

Five representative content pages were actually OCRed, including books 1/2/4/6/7. The single-worker sample took 10.11 seconds in total; typical page times were 1.48–2.47 seconds. Visual comparison of book-1 physical page 20 confirmed broad wording and matching subject; the printed page is 19 and the physical link correctly remains 20. Footnote verse numbers, page references, punctuation and occasional Arabic words are wrong in OCR. No claim of verbatim quotation accuracy is made.

The eight-worker run reached 712 OCR pages in approximately 226 seconds (including samples), about 3.1 pages/second. Mean worker time 2.22 seconds/page, median 2.16. At that checkpoint 123 pages were below mean confidence 65; these must be excluded from scholarly search results. Covers, blank and damaged pages still receive physical-page records with honest quality flags. Machine has 16 logical CPUs and 15.21GiB physical RAM; available memory 4.27GiB before run and 3.91GiB during it. No memory saturation observed at this check.

Poster OCR was attempted at original size (PSM3), double size (PSM11), and as twelve enlarged/autocontrasted individual cards (PSM6). It recognizes some names and locations but fails too much on stylized small Arabic to serve as a dependable transcription. Original visual review remains authoritative; private poster-ocr-cards.txt is evidence only, and uncertain schedule fields must remain flagged rather than guessed.

Acquisition hashes: Tesseract conda-forge package `tesseract-5.5.3-he87eeb8_0.conda` SHA-256 `edbe2455a8ee83c47c04bc93d6b75957b9f76b194f0ac2fe69f31ab46de7e024`; bundled Arabic traineddata SHA-256 `e3206d3dc87fd50c24a0fb9f01838615911d25168f4e64415244b67d2bb3e729`; vendor micromamba archive SHA-256 `97a336f4ab794bd96a6a4da5e6ed63e75a1d31830414a182419b23d3b36f3fe0`. Package archive was verified against the registry's solver-selected SHA-256 before extraction.

## Quality retry evidence

Book 2 is substantially harder than the other scans: 382 of its 587 pages fell below mean word confidence65. Actual 300dpi retries on physical pages100,101,106 changed confidence49.33→51.72,44.37→44.66,39.65→38.61 respectively. The first two higher-confidence records were retained and labeled300dpi; the third kept its200dpi result. Increasing resolution does not resolve this source's typography and damaged glyphs. These pages remain low-confidence and excluded from scholarly search. Full page coverage does not imply full reliable text coverage.

## Final corpus verification — 2026-10-24

All seven indexes are complete in the physical-page coverage sense: 3,639 ordered records (3,308 OCR and 331 PDF text-layer pages), with no missing or repeated physical page IDs. This does not mean that every page is reliably searchable. The actual search domain excludes 698 low-confidence OCR records; 2,941 nonempty records remain eligible for search, all unreviewed. There are 32 empty-text records, included among the excluded low-confidence records; these are empty extraction results, not visual certification that the source pages are blank.

| Book | Physical records | Search eligible | Low confidence excluded | Empty text | Method |
| --- | ---: | ---: | ---: | ---: | --- |
| book-1 | 552 | 535 | 17 | 9 | 552 OCR 200dpi |
| book-2 | 587 | 205 | 382 | 3 | 585 OCR 200dpi; 2 OCR 300dpi |
| book-3 | 23 | 23 | 0 | 0 | PDF text |
| book-4 | 694 | 686 | 8 | 2 | OCR 200dpi |
| book-5 | 308 | 308 | 0 | 0 | PDF text |
| book-6 | 8 | 8 | 0 | 0 | OCR 200dpi |
| book-7 | 1,467 | 1,176 | 291 | 18 | OCR 200dpi |
| Total | 3,639 | 2,941 | 698 | 32 | 3,308 OCR; 331 PDF text |

The final build log reports 3,308 OCR completions in 1,008.75 seconds (approximately 3.28 pages/second). This is measured build elapsed time, not an assurance of performance on another host. Published JSON totals 18,141,777 bytes excluding the manifest.

Fresh verification: `tests/round3-book-index-test.py` passed against every public record and every private cached OCR record or text-layer extraction. It checked manifest consistency, stable book IDs, exact 1-based page order/range/count, text/search normalization, method and confidence/quality consistency, absence of TSV header/tab leakage, and original PDF byte lengths/SHA-256. No OCR or dependencies were rerun/installed. `node --test tests/round3-research.test.js` passed (1 test, 0 failures) against the search domain extracted from the current HTML, including low-confidence exclusion and literal grade filtering. Current Round3Library calls that domain; its coverage counter counts indexed physical records, not search eligibility, and the table above supplies that distinction. This is data and search-domain verification, not a new browser UI test or page-by-page scholarly transcription review.

### Published JSON integrity

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| book-1.json | 2,088,501 | 74a5d3fe4674f19dde717f3e67841e6d977ceefc9e0a5deb10e3fc8d11bff386 |
| book-2.json | 2,509,471 | dff8a44a6bef59b3a1113accefa0ebb30a86c9224c6dedac438b593540b2d120 |
| book-3.json | 127,503 | 997d8335e82ded367e7ef0df5fda600f72451244d417e7f7d09ef7e5f772c112 |
| book-4.json | 2,939,623 | bcee5fc7e30f8102f2420f1f494b324ec02851b591dc621db6f8b691ad627f29 |
| book-5.json | 2,810,856 | a8adcb7350ce9ff330f72258ddccdc116a3daf1eb1b068553f492a601dfce6b8 |
| book-6.json | 47,501 | 803989818264ccf0d75b4cb3ca0f6b0001d1c7d9a3b9c4ba5488b8da546024f5 |
| book-7.json | 7,618,322 | 19fd9e0d8ea0c80d97e713ab8cb30c1f98a893d75c8402b97f43a2bf843cd896 |

### Review gate

No structural corpus corruption was found by these checks. Material limitations remain: book-2 excludes 382/587 pages and book-7 excludes 291/1,467 pages; a missing search result does not establish absence from the source. Confidence is a machine heuristic, not verified textual correctness. Both text-layer and OCR excerpts may corrupt Quranic words, names, numbers, footnotes and hadith wording. Citations use physical PDF order, which may differ from printed pagination (the inspected book-1 physical page 20 is printed page 19). The original PDF page is authoritative. A grade filter finds a literal word only; it does not establish a researched or authenticated hadith grade, resolve disagreements, or issue a religious conclusion. Every attributed quotation or grade requires source-page review.
