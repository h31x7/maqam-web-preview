# Group B differential review

Reviewed server commit `7393ab8` plus the current uncommitted Round5Media/translation/player HTML changes. Baseline was Group A commit `dfc9505`. The review covered server schemas/upstream transport/error boundaries and client batching/cache identity, cancellation, provider choice, timeline scheduling and volume handling. No .env or actual credential values were read.

## Decision and findings

Conditional acceptance pending root browser/live-provider QA. No unresolved critical/high security finding identified in the reviewed paths. Two concrete issues were corrected during review after root authorization:

| Severity | Finding | Resolution |
|---|---|---|
| P2 | Public capability model/voice metadata accepted a configured string containing the API credential. A mistaken credential paste into any model/voice setting could disclose it in GET /api/speech and translation model output. Synthetic-only reproduction confirmed the leak. | `_groq_setting` now rejects any public configured name containing the current credential. Tests cover all five public settings, exact credential and prefix/suffix copies, and no upstream request for a rejected translation model. |
| P2 | Provider HTTP 400 `model_terms_required` was collapsed into generic upstream failure, leaving an otherwise configured speech service without an actionable setup state. Root live-provider checks identified this condition for both configured Orpheus models. | Bounded structured provider code recognition maps to HTTP 503 `groq_terms_required` and fixed Arabic instructions for the service administrator. No provider diagnostic is relayed, no retry occurs for this condition, and this agent did not accept legal terms. |

The integrating media agent also fixed future-prefetch retries during review: a failed future segment is memoized for its generation rather than repeatedly requested every 150ms. Its regression originally observed seven calls versus three expected, and now passes. A stale AudioContext unlock rejection is generation-guarded. These HTML changes are owned by the media/root agent.

## Evidence and scope

- Server transport uses fixed HTTPS Groq routes, rejects redirects, bounds upstream JSON/audio, retains numeric retry limits/timeouts and emits generic codes rather than provider bodies. Existing strict Host/Origin, JSON duplicate-key/nonfinite rejection, body framing/size checks and per-IP admission remain active.
- Speech schema is AR/EN only, <=200 characters, allowlisted advertised voice; returned RIFF/PCM metadata and total audio size are validated. Batch translation retains exact output ordering/count, only nonempty bounded strings and one malformed-output retry; legacy scalar translation remains separate.
- Request Authorization remains server-only. The user-agent `Maqam/1.0` added by root to resolve provider 403 is retained. Neither proxy endpoint relays arbitrary provider headers/diagnostics. Static allowlist tests deny /.env, server.py and /.env.example.
- Changed runtime blast radius: one lecture translation component, one narrow native/YouTube media adapter, three same-origin media request functions and one dubbing scheduler. Existing dictionary/platform scalar callers remain intact. Chat/note persistence is outside this group.
- The cache includes source text, video/source identity, target, configured model and engine; no shortened cache hash alone authorizes reuse. Progress and fallback name the actual engine. Unchanged Arabic is rejected as a successful non-Arabic translation.
- Dubbing prefetch is current plus two future sentences, binary chunks <=200 characters, decoded/cache allocation bounded. Stop/language/voice/rate/source/ownership/unmount invalidate stale work. Pause/seek/rate changes re-evaluate current timeline. Original volume restores on stop/error/end; explicit user volume changes are preserved. Browser fallback selects the exact/base language and fails honestly if unavailable.

## Verification

Initial independent checks passed 16 media domain tests and 13 Groq HTTP tests. Added synthetic regressions were observed failing before the server fix, then all 16 Groq HTTP tests passed. Full Python suite ran 80 tests (2 skipped; no failures). The initial aggregate JavaScript run passed 195/196: its sole failure was the old homepage-stream preservation expectation. Root confirmed the user explicitly authorized removing the homepage stream while retaining the student stream and updated that obsolete test. Final rerun passed 196/196 JavaScript tests; JSX parsing and diff whitespace checks also passed. Server fixes are committed as 32dbc7c; this review document remains for the root documentation commit. No test in this review sends real provider requests; the root owns separate live checks. CodeQL and real browser evidence are recorded independently by root and are not inferred from these unit tests.

## Additional user-authorized scope

Root confirmed a new explicit user instruction to remove only the homepage stream and preserve the student stream. The MainScreen entry-stream removal is therefore authorized rather than an unrelated regression; the old preservation assertion was updated by root. This reviewer did not modify that UI.

## Actual limitations

- Browser speechSynthesis has no reliable word-offset API. A pause/seek restarts the current translated sentence; it cannot resume at the precise interrupted word.
- Groq synthetic reading fits a segment with acceleration capped at 1.35. If a long sentence still exceeds its source interval, the next timeline segment stops the remainder. This is timeline-bound reading, not phoneme-aligned dubbing. Playback is polled at 150ms; subtitle display keeps the existing player clock.
- Verified alignment/video identity is required for synchronized mode. Unverified text is explicitly standalone. Real video seek/pause/speed/volume restoration and mobile gesture behavior still need root browser QA.
- Server model existence is checked at setup; existence alone does not prove terms acceptance, voice entitlement or successful synthesis. Root reported /models success but actual AR/EN speech still required model terms; no successful live audio is claimed here.
- Missing tested translation model remains unset. Provider availability, voice coverage beyond AR/EN, long-term preview-model support and real translation accuracy cannot be established by fixtures. Other languages require a browser voice.
- HTTP Retry-After parsing supports bounded numeric seconds. HTTP-date Retry-After is treated as the default exponential delay rather than parsed as a date.


## Edge follow-up review — df141a7 client against 02a78d6 server

The user explicitly authorized the Edge addition, completing the remaining work and publishing, superseding the prior publishing restriction/automatic rejection. No deployment success is claimed by this review; root owns public deployment verification. No application edits or secrets inspection were performed for this follow-up.

Focused conclusion: no blocking client/server contract mismatch identified for the current product registry. The server advertises provider=edge, maxCharacters 200 and languages[code] records containing available/voices/defaultVoice/model=edge-tts. Exact locale, lowercase and base entries allow the client to select a discovered ID and send its unchanged {text,language,voice} request. The server requires strict locale/base membership, so client fields cannot select a foreign language voice or upstream URL. The current registry has only zh-CN/zh-TW regional codes; both are advertised Edge locales. Future regional registry additions must keep the same mapping discipline.

The client accepts Edge audio/mpeg and Groq audio/wav only for their selected provider, caps response length at 2 MiB and checks ID3/MPEG or RIFF envelopes before Web Audio decoding. Server MP3 validation is stricter than the client and rejects absent/invalid MPEG frames; invalid audio still fails decoding safely. Edge uses the same generation-guarded loading, decode, current-plus-two prefetch, failed-prefetch memoization, stop/seek/rate/volume restoration and stale-unlock guard. It does not add a second scheduler or expose a provider override/credential field to the browser. Unsupported Edge languages use only a matching browser voice or the honest unavailable state.

The translation batch size was reduced to <=180 source characters to fit the user-verified Qwen max_tokens 150 budget. Invalid/truncated structured output still receives the existing format retry then explicit legacy fallback; a short live 200 check is not complete lecture translation evidence.

Verification recorded for the combined changes: 199 JavaScript tests pass; Python runs 92 tests with 2 skipped and no failures. Edge live discovery returned 322 voices across 75 base languages and actual AR/EN/Urdu synthesis produced validated MP3; Qwen translation returned 200 with the configured model/output budget. No actual Groq synthesis is claimed while its terms remain unaccepted. Existing synchronized-caption and CodeQL extraction limitations remain unchanged. The earlier report's AR/EN-only server-speech limitation applies to optional Groq; Edge now supplies discovered multilingual server speech. The earlier missing-Qwen state is historical and superseded by this live configuration.
