# Dedicated dubbing stop — deployment evidence

- URL: https://maqam-source-20261020.onrender.com/
- Source: 472685a873f05135fb651a1565ce09ec1a6b4609
- Release: https://github.com/h31x7/maqam-web-preview/commit/510eebe8a72f3a49e1513f3efccc7e7a064de2ad
- Render: dep-dbff9l7avr4c73duegsg, live 2026-10-26T06:37:11Z
- HTML checksum matches local; health ok; actual prepared source completed with 1423 rows.
- Browser start/stop state transition verified on public lecture; English subtitle visible; no console errors observed.
- Tests: JS 214/214; focused media 33/33; source Python 19/19.
- Differential review: stop addition only touches existing translation component handler/control; invokes the existing tested scheduler cancellation. Existing language, source, endpoint and player behavior retained.
- Public fresh source preparation failed source_unavailable; six-recording local preparation awaits explicit resource-use permission. Details and limitations in video-dubbing-changelog.md.
