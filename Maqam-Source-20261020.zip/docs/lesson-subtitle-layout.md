# Portal descriptions and lesson subtitles — 2026-10-27

Request: remove descriptions from Student/Sheikh entry cards; show lesson translation in a dedicated larger-text box immediately below the media. Presentation only, existing single owner Round3LectureTranslation and media adapter unchanged. No server, dependencies, data, state, handlers, endpoint or storage changes.

Map: MainScreen entry descriptions around3451/3477; FeedbackLecture media/component ordering around3261; Round3LectureTranslation subtitle/controls around3232; translation CSS around455–457. Existing D.2 tokens and Arabic UI typography own presentation.

Plan: remove exactly the two description paragraphs; move existing translation component directly after media; render existing subtitle first in its own surface with larger responsive type, settings below. Preserve all translation/voice/source/error/retry behavior. Run current 214 regressions and JSX/event/API/storage checks, visually verify entry and lecture views in both themes and responsive sizes, commit and publish through existing service, verify public HTML.

User added: remove organizer description and empty space within all three buttons, use icons. Entry uses existing SVGs and labels in compact icon buttons. All original click handlers retained; third organizer option remains hidden under768px per existing dashboard rule, so mobile uses two columns with no blank third slot. No badge/footer/description space reserved.

## Verification

214 JS tests pass; full Babel JSX parses; declarations, event-handler structure modulo UI text, API/storage identifiers unchanged. Independent differential review found no actionable issue in subtitle or icon changes. Browser confirmed the translation component is the immediate media sibling, its text is22.4px at390px and30.4px at1440px, existing English translation advances with playback, and original-language details/control states remain. Both themes checked at390/768/1440; no horizontal overflow. Entry buttons have no paragraphs: two116px-high choices on mobile (organizer gate retained), three148px-high choices at768/1440. No console errors on observed paths.

Screenshots in docs/screenshots/lesson-subtitles/: 390-dark/light.png, 768-dark/light.png, 1440-dark/light.png; entry-390-dark/light.png, entry-768-dark/light.png, entry-1440-dark/light.png. Prior baseline layout is visible in docs/screenshots/video-dubbing/approved-wording-lecture.png and arabic-copy-live.png. These existing before images were retained rather than recaptured at every size. No server, .env, data, source-preparation, API, handler, storage or dependency changes.
