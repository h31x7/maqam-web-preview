# Required browser capture and flow matrix

Status: all captures pending due to inaccessible local server. No screenshots are represented as completed.

Each row requires 390×844, 768×1024 and 1440×1000 at baseline and after its owning phase. Filenames should be `screenshots/<baseline|phase-N>/<surface>-<width>.png`. Preserve original RTL, copy and data. For long panels capture both first view and full content where available; verify internal scrolling separately.

| Owning phase | Surface/state | Access / preservation note |
|---|---|---|
| 0/1 | Splash, main entry | Existing splash timer and skip action |
| 1 | Visitor, student, teacher, employee auth | Existing accessibility route controls / original route contract |
| 1 | Language modal, search, selection | Confirm translation and direction behavior, then restore Arabic |
| 1 | Accessibility modal sections | Toggle settings, verify visible state and restore defaults |
| 1 | Voice HUD and sign-language PIP | Permission-dependent recognition reported separately |
| 2 | Visitor home | Live lesson, categories, lecture grid |
| 2 | Visitor Maajem | Welcome, submitted query, pending, reply/fallback, history |
| 2 | Wamadat | Search and clip selection |
| 2 | Schedule | Month controls, lesson details, alerts and Haram map |
| 2 | Sheikhs | Six approved scholars |
| 2 | Library | Search, filters and document actions |
| 2 | Video player | Play/pause, controls, minimize, subtitle/translation entry |
| 2 | Audio mini-player | Play/pause, expand, close |
| 2 | Clip share | Clip range and existing share actions |
| 2 | Lecture quiz/summary | Question, selection and result states |
| 2 | Live translation | Language selection, player and transcript |
| 2 | Floating Maajem, visitor quiz | Original close and answer actions |
| 3 | Student home | Profile, progress, announcements and academic content |
| 3 | Student Maajem hub | Existing tools and tabs |
| 3 | Student lessons | Filters, lesson player and note controls |
| 3 | Student schedule | Calendar and class action |
| 3 | Student activities | Homework, quiz and progress/result states |
| 3 | Student sheikhs | Profile, message and lecture overlays |
| 3 | Student profile | View/edit/save/cancel using original handlers |
| 3 | TeamsVirtualClass | Unmounted in source: static review only unless already reachable by original app |
| 4 | Teacher class schedule | Broadcast and upload actions using original behavior |
| 4 | Teacher performance | Tables and assignment/quiz workflows |
| 4 | Teacher council | Posts and SheikhPostModal |
| 4 | Teacher copilot | Original assistant and pending/result states |
| 4 | Organizer dashboards | Each original dashboard selection and chart/table region |
| 4 | Organizer nawazil feeder | Original inputs and actions |
| 4 | Organizer weekly report | Full report and original report actions |
| 5 | Cross-screen QA | Console errors, overflow, keyboard, reduced motion, contrast, mixed-script text |

After every implementation phase: guest login, tab switching, chat send/receive, language switch, accessibility toggles, video play and quiz. Backend success must be distinguished from source fallback behavior. Do not claim a live Dify pass from a fallback answer.

TSSelectScreen is also unmounted and ts_select currently renders StudentDashboard. Preserve this behavior.
