# Round 4 differential review

Baseline: 2b1ad04. Risk-focused manual review plus executable tests; this is not a completed CodeQL scan. Source app is a single HTML file; review follows named component/domain boundaries.

## Scope and blast radius
A: Round4Study/Store, Reader/QuickNotes/Notes, library reader links, page frame, PDF bootstrap and explicitly named vendor resources. Shared provider/frame affect all secondary pages. Study store transaction/conflict tests cover single-record notes, draft/save, quota failures, stale saves and coordinates.
B: Round3Live, Reminder, PlaylistButton/Playlists, round3Watch, FeedbackLecture and legacy ClipShareModal. Existing watch progress, playback APIs and original media IDs retained. Clipboard helper is used by lecture share and chat copy; three independent modern/denied/failed fallback tests verify honest success.
C/D: haram-schedule, books and secondary recording headers; original seven primary source records, source summary points and quiz data protected by hash tests. Domain filters retain public directory and media association; only seeded platform identity is fictional. No inferred PDF URLs for uncleared editions.
E: Round4 grades/ranking/activity/notices and Round3StudentChat. Existing chat endpoint/conversation validation/safe Markdown retained. New optional image proxy is the highest-risk boundary: /api/capabilities, /api/upload and optional /api/chat.files. Owner-bound upload references, 2 MB image limit, decoded dimension/type checks, bounded multipart/JSON, TTL and request limits, fixed provider host, redirect rejection and sanitized errors reviewed; tests exercise malformed/foreign/expired files and provider failures.
F: MainScreen and width-based guard; guard applies to dashboard/login routes while public directory stays available.

## Regression findings fixed during review
- Explicit PDF.js rendering resources were initially subjected to the old extension-only fallback; corrected to use the explicit manifest union, retaining symlink/root containment checks.
- A cached old book catalog hid new books; reader/library catalog fetch revalidates current data.
- An old process on port 5000 returned 404 for the new API despite fresh HTML. Current server is isolated at 5004 and direct HTTP checks confirm capabilities, new books and OCR data.
- Legacy clip sharing still simulated a publish. It now shares the actual complete media URL and cannot announce success if copying fails.
- Old home GPA/attendance/poster and fake smart-image result were removed from the current student flows. Demo record source remains separate from actual local activity.
- Desktop coarse-pointer blocking removed as explicitly required; mobile public Sheikh entry preserved.
- Existing leaderboard period filters preserved rather than lost during component replacement.

## Evidence and limits
Current JavaScript suite: 163 passing. Current Python boundary/static/Range suite: 64 run, two Windows symlink privilege skips. JSX parse and diff whitespace checks run again before commit. Two new source PDFs return 206 for a 16-byte range; unknown books/OCR files and /.env return 404. Browser console had no error entries during current core-flow traversal; expected provider-unavailable states are shown in UI. Viewport/theme screenshots cover reader, notes, library, watch, playlist picker, quick note, timetable, grades, leaderboard, notices, entry, home, chat and public Sheikh views.

No .env/secrets edits, no Render/GitHub use, no publication. No original Thmanyah font/zip/license assets added. Historical authors/source text retained. CodeQL failed extraction due host temporary/diagnostic filesystem permission errors (zero source extracted); do not interpret this report as a clean CodeQL result. Genuine handwritten-image and full freehand input-device matrix remain unverified, as does live Dify vision without service configuration. These are explicit verification limits.
