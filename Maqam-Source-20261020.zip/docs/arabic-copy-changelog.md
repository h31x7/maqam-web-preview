# Approved Arabic copy correction

User approved all 21 language-review items, overrode the organizer entry title with لوحة التحكم, and requested checking ترا فيه كويز in activities. Copy only; handlers, routes, state, API/storage identifiers, data structure, scholarly transcripts and server/environment remain unchanged. No phrase ترا فيه كويز or ترى فيه كويز was found in current HTML/data JSON before changes. Current activity quiz wording is normalized to اختبار قصير.

Plan: exact copy replacements -> JSX/structural and 214 regression tests -> browser checks -> commit and release -> public checksum/source verification.

| Original | Replacement | Occurrences |
|---|---|---|
| دخول المنظمين للداشبوردات والإدارة الأكاديمية | دخول لوحة التحكم والإدارة الأكاديمية | 2 |
| إعادة التوليد تسأل آخر سؤال في سياق جديد. | إعادة التوليد تعيد طرح آخر سؤال في سياق جديد. | 2 |
| تم تثبيت كافة الحركات والأنيميشنات | أُوقفت جميع الحركات والرسوم المتحركة. | 2 |
| تثبيت حركة وأنيميشنات الصفحة | إيقاف حركة الصفحة والرسوم المتحركة | 2 |
| أسوي لك اختبار فقهي تفاعلي؟ | هل أُعدّ لك اختبارًا فقهيًا تفاعليًا؟ | 2 |
| درجات الاختبار نزلت بالموقع | نُشرت درجات الاختبار على الموقع. | 3 |
| دخول لوحة تحكم المنظمين | دخول لوحة التحكم | 2 |
| المنظمين للداشبوردات | لوحة التحكم | 3 |
| أسوي لك اختبار فقهي؟ | هل أُعدّ لك اختبارًا فقهيًا؟ | 2 |
| أسئلة معاجم المجابة | الأسئلة المُجاب عنها في معاجم | 2 |
| مراجعة للمنهج بكرة | مراجعة المنهج غدًا | 3 |
| 30 طالباً معتمد | 30 طالبًا معتمدًا | 2 |
| ترا فيه كويز | يوجد اختبار قصير | 0 |
| ترى فيه كويز | يوجد اختبار قصير | 0 |
| جاري الطلب… | جارٍ تنفيذ الطلب… | 2 |
| الكويزات | الاختبارات القصيرة | 6 |
| الكويز | الاختبار القصير | 4 |
| كويزاً | اختبارًا قصيرًا | 4 |
| كويز | اختبار قصير | 11 |

جاري -> جارٍ: 20 repeated status-label occurrences (including UI string registry).

## Verification

214 JS tests pass; full JSX parses. Declarations, event-handler structure modulo copy, API/storage identifiers unchanged. One test assertion updated only for the two approved announcement titles. Independent review found no unintended behavior changes. Browser entry shows لوحة التحكم and not the old heading; no horizontal overflow. No server, environment, recording, feature or styling changes. Screenshot: docs/screenshots/video-dubbing/arabic-copy-entry.png.

## Published release

User explicitly revoked the previous usage-stop threshold and requested completion. Source ca11039530940fdacc1488ec4e0ec89b54ab3cc5 published as GitHub 9f91e0af55e9cbd2923647bbef4dfd95184bfd5f. Render dep-dbfk326i0phs73avmht0 is live, finished 2026-10-26T12:04:34.958115Z. Public HTML bytes match local; all seven prepared source objects match local exactly; prepared static file remains404. Browser confirms لوحة التحكم heading, old title absent, no horizontal overflow and no console errors in observed entry viewport. Screenshot docs/screenshots/video-dubbing/arabic-copy-live.png. Fresh prepublication JS suite214/214 passed. No additional code edits on resume. Existing free service and environment unchanged.
