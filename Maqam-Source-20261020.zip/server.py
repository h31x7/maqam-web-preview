#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Allowlisted Maqam static server and bounded same-origin Dify proxy.

Configuration comes only from process environment. Never place credentials in
source, served configuration files or logs. Run with ``python server.py``.
"""

from collections import OrderedDict, deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import ipaddress
import json
import logging
import math
import mimetypes
import os
from pathlib import Path
import re
import shutil
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = "maqamooo.html"
DIFY_API_KEY = os.environ.get("DIFY_API_KEY", "")
DIFY_API_URL = os.environ.get("DIFY_API_URL", "https://api.dify.ai/v1")
PORT = os.environ.get("PORT", "5000")
MAX_BODY_BYTES = 16_384
MAX_QUERY_CHARS = 4_000
MAX_UPSTREAM_BYTES = 1_048_576
UPSTREAM_TIMEOUT_SECONDS = 20
CLIENT_TIMEOUT_SECONDS = 10
RATE_LIMIT_COUNT = 20
RATE_LIMIT_WINDOW_SECONDS = 60
MAX_RATE_IDENTITIES = 4_096
MAX_REQUEST_WORKERS = 64
PUBLIC_ASSET_EXTENSIONS = frozenset({
    ".css", ".js", ".mjs", ".png", ".jpg", ".jpeg", ".webp", ".avif",
    ".gif", ".ico", ".woff", ".woff2", ".ttf", ".mp4", ".webm", ".mp3",
    ".ogg", ".wav",
})
HASHED_ASSET_NAME = re.compile(r"\.[0-9a-fA-F]{8,64}\.")

# Temporary exceptions for the existing CDN/Babel build; tighten after a verified
# precompile rather than breaking translation or the current application.
CONTENT_SECURITY_POLICY = "; ".join([
    "default-src 'self'", "base-uri 'self'", "object-src 'none'",
    "frame-ancestors 'none'", "form-action 'self'",
    "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdnjs.cloudflare.com https://unpkg.com https://cdn.jsdelivr.net https://cdn.tailwindcss.com https://translate.google.com https://translate.googleapis.com https://www.gstatic.com",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://translate.googleapis.com https://www.gstatic.com",
    "font-src 'self' https://fonts.gstatic.com data:",
    "img-src 'self' data: https://i.ytimg.com https://img.youtube.com https://translate.google.com https://translate.googleapis.com https://www.google.com https://www.gstatic.com https://*.googleusercontent.com",
    "connect-src 'self' https://translate.google.com https://translate.googleapis.com https://www.youtube.com",
    "frame-src https://www.youtube.com https://www.youtube-nocookie.com https://translate.google.com",
    "media-src 'self'",
])
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "DENY",
    "Content-Security-Policy": CONTENT_SECURITY_POLICY,
    "Permissions-Policy": 'camera=(), geolocation=(), microphone=(self), fullscreen=(self "https://www.youtube.com")',
}
LOGGER = logging.getLogger("maqam")


def _valid_text(value, maximum, *, allow_empty=False):
    return (isinstance(value, str) and len(value) <= maximum
            and (allow_empty or bool(value.strip()))
            and not any(ord(char) == 0 or 0xD800 <= ord(char) <= 0xDFFF for char in value))


def _uuid_string(value):
    if not isinstance(value, str) or len(value) != 36:
        return False
    try:
        return str(uuid.UUID(value)) == value
    except (ValueError, AttributeError):
        return False


def _identity(value):
    if not isinstance(value, str):
        return False
    prefix, separator, identifier = value.partition("_")
    return bool(separator and prefix in {"visitor", "student"} and _uuid_string(identifier))


def _authority(value, scheme):
    """Validate an authority, without trusting client-forwarded headers."""
    if not isinstance(value, str) or not value or len(value) > 255:
        raise ValueError("Invalid authority")
    if any(char.isspace() or ord(char) < 33 for char in value) or any(char in value for char in "@/\\?#,%"):
        raise ValueError("Invalid authority")
    parsed = urllib.parse.urlsplit(scheme + "://" + value)
    hostname = parsed.hostname
    if not hostname or parsed.username or parsed.password:
        raise ValueError("Invalid authority")
    if ":" in hostname:
        ipaddress.IPv6Address(hostname)
        hostname = "[" + hostname.lower() + "]"
    elif not re.fullmatch(r"[a-zA-Z0-9](?:[a-zA-Z0-9.-]{0,251}[a-zA-Z0-9])?", hostname):
        raise ValueError("Invalid authority")
    port = parsed.port
    if port is not None and not 1 <= port <= 65535:
        raise ValueError("Invalid authority")
    default_port = 443 if scheme == "https" else 80
    return hostname.lower() + (":" + str(port) if port is not None and port != default_port else "")


def _origin(value):
    if not isinstance(value, str) or any(char.isspace() for char in value):
        raise ValueError("Invalid origin")
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme not in {"http", "https"} or parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
        raise ValueError("Invalid origin")
    return parsed.scheme + "://" + _authority(parsed.netloc, parsed.scheme)


def _provider_endpoint():
    parsed = urllib.parse.urlsplit(DIFY_API_URL.strip())
    if parsed.scheme != "https" or not parsed.netloc or parsed.query or parsed.fragment:
        raise ValueError("Invalid provider configuration")
    _authority(parsed.netloc, "https")
    if any(part in {".", ".."} for part in parsed.path.split("/")) or "\\" in parsed.path:
        raise ValueError("Invalid provider configuration")
    return urllib.parse.urlunsplit(("https", parsed.netloc, parsed.path.rstrip("/") + "/chat-messages", "", ""))


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON property")
        result[key] = value
    return result


def _bad_json_constant(_value):
    raise ValueError("Invalid JSON constant")


def _parse_json(data):
    return json.loads(data.decode("utf-8"), object_pairs_hook=_unique_object, parse_constant=_bad_json_constant)


def _inputs(value):
    if not isinstance(value, dict) or len(value) > 20:
        return False
    for key, item in value.items():
        if not _valid_text(key, 64):
            return False
        if isinstance(item, str):
            if not _valid_text(item, 2_000, allow_empty=True):
                return False
        elif item is not None and not isinstance(item, (bool, int, float)):
            return False
        elif isinstance(item, (int, float)) and (abs(item) > 10 ** 15 or not math.isfinite(item)):
            return False
    return len(json.dumps(value, ensure_ascii=False).encode("utf-8")) <= 4_096


def _citation_url(value):
    if not _valid_text(value, 2_048) or any(char.isspace() for char in value):
        return None
    try:
        parsed = urllib.parse.urlsplit(value)
        if parsed.scheme not in {"https", "http"} or not parsed.netloc:
            return None
        _authority(parsed.netloc, parsed.scheme)
    except ValueError:
        return None
    return value


def _citations(response):
    metadata = response.get("metadata")
    resources = metadata.get("retriever_resources") if isinstance(metadata, dict) else None
    if not isinstance(resources, list):
        return []
    sources, seen = [], set()
    for resource in resources[:40]:
        if not isinstance(resource, dict):
            continue
        title = resource.get("document_name")
        if not _valid_text(title, 200):
            continue
        title = title.strip()
        entry = {"title": title}
        link = _citation_url(resource.get("url"))
        if link:
            entry["url"] = link
        identity = (title, link)
        if identity not in seen:
            sources.append(entry)
            seen.add(identity)
        if len(sources) == 20:
            break
    return sources


class RejectProviderRedirects(urllib.request.HTTPRedirectHandler):
    """Never forward an Authorization header through provider redirects."""

    def redirect_request(self, *_args, **_kwargs):
        return None


class RateLimiter:
    def __init__(self):
        self._entries = OrderedDict()
        self._lock = threading.Lock()

    def admit(self, identity):
        now = time.monotonic()
        with self._lock:
            timestamps = self._entries.pop(identity, deque())
            while timestamps and timestamps[0] <= now - RATE_LIMIT_WINDOW_SECONDS:
                timestamps.popleft()
            if len(timestamps) >= RATE_LIMIT_COUNT:
                self._entries[identity] = timestamps
                return False, max(1, math.ceil(RATE_LIMIT_WINDOW_SECONDS - (now - timestamps[0])))
            timestamps.append(now)
            self._entries[identity] = timestamps
            while len(self._entries) > MAX_RATE_IDENTITIES:
                self._entries.popitem(last=False)
        return True, 0


class MaqamHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = False
    allow_reuse_address = True
    request_queue_size = 32

    def process_request(self, request, client_address):
        if not self.worker_slots.acquire(blocking=False):
            body = json.dumps({"success": False, "error": "الخدمة مشغولة الآن. يرجى المحاولة لاحقاً."}, ensure_ascii=False).encode("utf-8")
            fields = {**SECURITY_HEADERS, "Content-Type": "application/json; charset=utf-8", "Content-Length": str(len(body)), "Cache-Control": "no-store", "Connection": "close", "Retry-After": "1"}
            wire = ("HTTP/1.0 503 Service Unavailable\r\n" + "".join(key + ": " + value + "\r\n" for key, value in fields.items()) + "\r\n").encode("ascii") + body
            try:
                request.settimeout(1)
                request.sendall(wire)
            except OSError:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self.worker_slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.worker_slots.release()

    def handle_error(self, _request, _client_address):
        LOGGER.warning("Request handling failed")


class MaqamProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"
    server_version = "Maqam"
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(CLIENT_TIMEOUT_SECONDS)

    def log_message(self, _format, *_args):
        # Do not log targets, bodies, provider errors or credential substrings.
        pass

    def end_headers(self):
        self.send_header("Cache-Control", getattr(self, "cache_policy", "no-store"))
        for key, value in SECURITY_HEADERS.items():
            self.send_header(key, value)
        if getattr(self, "allowed_origin", None):
            self.send_header("Access-Control-Allow-Origin", self.allowed_origin)
            self.send_header("Vary", "Origin")
        super().end_headers()

    def _json(self, status, value, *, head=False, extra_headers=None):
        body = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.cache_policy = "no-store"
        self.close_connection = True
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if not head and self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, socket.timeout):
                pass

    def _error(self, status, *, extra_headers=None):
        messages = {
            400: "تعذر قبول الطلب. يرجى التحقق من البيانات والمحاولة مجدداً.",
            403: "هذا الطلب غير مسموح من الصفحة الحالية.",
            404: "المسار غير موجود.",
            405: "طريقة الطلب غير مدعومة.",
            408: "انتهت مهلة استقبال الطلب. يرجى المحاولة مجدداً.",
            411: "تعذر قبول الطلب. يرجى المحاولة مجدداً.",
            413: "حجم الطلب أكبر من المسموح. يرجى اختصار النص.",
            415: "صيغة الطلب غير مدعومة.",
            429: "تم إرسال طلبات كثيرة. يرجى الانتظار قليلاً والمحاولة مجدداً.",
            500: "تعذر إتمام الطلب الآن. يرجى المحاولة لاحقاً.",
            502: "تعذر الحصول على إجابة الآن. يرجى المحاولة مجدداً.",
            503: "خدمة المحادثة غير متاحة الآن. يرجى المحاولة لاحقاً.",
            504: "استغرقت الإجابة وقتاً أطول من المتاح. يرجى المحاولة مجدداً.",
        }
        self._json(status, {"success": False, "error": messages.get(status, messages[400])}, extra_headers=extra_headers)

    def send_error(self, code, message=None, explain=None):
        self._error(code)

    def _begin(self):
        self.allowed_origin = None
        hosts = self.headers.get_all("Host", [])
        if len(hosts) != 1:
            self._error(400)
            return False
        public_origin = self.server.public_origin
        scheme = urllib.parse.urlsplit(public_origin).scheme if public_origin else "http"
        try:
            authority = _authority(hosts[0], scheme)
        except ValueError:
            self._error(400)
            return False
        if authority not in self.server.allowed_authorities:
            self._error(403)
            return False
        origins = self.headers.get_all("Origin", [])
        if len(origins) > 1:
            self._error(403)
            return False
        if origins:
            try:
                given = _origin(origins[0])
            except ValueError:
                self._error(403)
                return False
            expected = public_origin or scheme + "://" + authority
            if given != expected:
                self._error(403)
                return False
            self.allowed_origin = expected
        return True

    def _path(self):
        if not self.path.startswith("/") or self.path.startswith("//"):
            return None
        try:
            path = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path, encoding="utf-8", errors="strict")
        except (ValueError, UnicodeError):
            return None
        if any(ord(char) < 32 or ord(char) == 127 for char in path) or any(char in path for char in "\\:%?#"):
            return None
        if any(part.startswith(".") for part in path.split("/") if part):
            return None
        return path

    def _serve(self, *, head=False):
        if not self._begin():
            return
        path = self._path()
        if path == "/api/health":
            try:
                app = (self.server.base_dir / APP_FILE).resolve(strict=True)
                ready = app.is_file() and app.is_relative_to(self.server.base_dir)
            except OSError:
                ready = False
            self._json(200 if ready else 503, {"status": "ok" if ready else "unavailable"}, head=head)
            return
        root = self.server.base_dir
        if path in {"/", "/" + APP_FILE}:
            candidate, asset = root / APP_FILE, False
        elif path and path.startswith("/assets/") and Path(path).suffix.lower() in PUBLIC_ASSET_EXTENSIONS:
            candidate, asset = root / path.lstrip("/"), True
        else:
            self._error(404)
            return
        try:
            resolved = candidate.resolve(strict=True)
            if not resolved.is_relative_to(root) or not resolved.is_file():
                self._error(404)
                return
            if asset and (not resolved.is_relative_to(root / "assets") or resolved.suffix.lower() not in PUBLIC_ASSET_EXTENSIONS):
                self._error(404)
                return
            if not asset and resolved.name != APP_FILE:
                self._error(404)
                return
            source = resolved.open("rb")
        except (OSError, ValueError):
            self._error(404)
            return
        try:
            with source:
                self.cache_policy = ("public, max-age=31536000, immutable" if HASHED_ASSET_NAME.search(resolved.name) else "public, max-age=3600, must-revalidate") if asset else "no-cache"
                self.send_response(200)
                content_type = mimetypes.guess_type(resolved.name)[0] or "application/octet-stream"
                if content_type.startswith("text/") or content_type in {"application/javascript", "application/json"}:
                    content_type += "; charset=utf-8"
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(os.fstat(source.fileno()).st_size))
                self.end_headers()
                if not head:
                    shutil.copyfileobj(source, self.wfile, length=65_536)
        except (BrokenPipeError, ConnectionResetError, socket.timeout):
            pass

    def do_GET(self):
        self._serve()

    def do_HEAD(self):
        self._serve(head=True)

    def do_OPTIONS(self):
        if not self._begin():
            return
        if self._path() != "/api/chat":
            self._error(404)
            return
        if self.headers.get("Access-Control-Request-Method", "POST").upper() != "POST":
            self._error(405)
            return
        requested = {item.strip().lower() for item in self.headers.get("Access-Control-Request-Headers", "").split(",") if item.strip()}
        if not requested.issubset({"content-type"}):
            self._error(403)
            return
        self.cache_policy = "no-store"
        self.send_response(204)
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_POST(self):
        if not self._begin():
            return
        if self._path() != "/api/chat":
            self._error(404)
            return
        admitted, retry_after = self.server.rate_limiter.admit(self.client_address[0])
        if not admitted:
            self._error(429, extra_headers={"Retry-After": str(retry_after)})
            return
        lengths = self.headers.get_all("Content-Length", [])
        if self.headers.get("Transfer-Encoding") or len(lengths) != 1 or not re.fullmatch(r"[0-9]+", lengths[0]):
            self._error(400 if lengths else 411)
            return
        normalized_length = lengths[0].lstrip("0") or "0"
        if len(normalized_length) > len(str(MAX_BODY_BYTES)):
            self._error(413)
            return
        length = int(normalized_length)
        if length > MAX_BODY_BYTES:
            self._error(413)
            return
        if length <= 0:
            self._error(400)
            return
        if self.headers.get_content_type() != "application/json" or self.headers.get_content_charset("utf-8").lower() not in {"utf-8", "utf8"}:
            self._error(415)
            return
        try:
            deadline = time.monotonic() + CLIENT_TIMEOUT_SECONDS
            chunks, remaining = [], length
            while remaining:
                budget = deadline - time.monotonic()
                if budget <= 0:
                    raise TimeoutError("Body deadline")
                self.connection.settimeout(budget)
                chunk = self.rfile.read1(remaining)
                if time.monotonic() >= deadline:
                    raise TimeoutError("Body deadline")
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk)
            body = b"".join(chunks)
            if len(body) != length:
                raise ValueError("Incomplete body")
            data = _parse_json(body)
            if not isinstance(data, dict) or not set(data).issubset({"query", "user", "conversation_id", "inputs"}):
                raise ValueError("Invalid payload")
            query, identity, conversation = data.get("query"), data.get("user"), data.get("conversation_id", "")
            inputs = data.get("inputs", {})
            if not _valid_text(query, MAX_QUERY_CHARS) or not _identity(identity) or not isinstance(conversation, str) or (conversation and not _uuid_string(conversation)) or not _inputs(inputs):
                raise ValueError("Invalid payload")
        except (socket.timeout, TimeoutError):
            self._error(408)
            return
        except (ValueError, UnicodeError, TypeError, RecursionError):
            self._error(400)
            return
        self.handle_dify_chat(query.strip(), identity, conversation, inputs)

    def handle_dify_chat(self, query, identity, conversation, inputs):
        key = DIFY_API_KEY
        if not isinstance(key, str) or not key or len(key) > 512 or any(ord(char) < 33 or ord(char) > 126 for char in key):
            self._error(503)
            return
        try:
            endpoint = _provider_endpoint()
        except ValueError:
            self._error(503)
            return
        payload = {"query": query, "user": identity, "conversation_id": conversation, "inputs": inputs, "response_mode": "blocking"}
        request = urllib.request.Request(endpoint, data=json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8"), headers={"Authorization": "Bearer " + key, "Content-Type": "application/json", "Accept": "application/json"}, method="POST")
        opener = urllib.request.build_opener(RejectProviderRedirects())
        try:
            with opener.open(request, timeout=UPSTREAM_TIMEOUT_SECONDS) as response:
                if response.getcode() != 200:
                    raise ValueError("Invalid provider status")
                raw = response.read(MAX_UPSTREAM_BYTES + 1)
                if len(raw) > MAX_UPSTREAM_BYTES:
                    raise ValueError("Provider response too large")
                result = _parse_json(raw)
            if not isinstance(result, dict) or not _valid_text(result.get("answer"), MAX_UPSTREAM_BYTES):
                raise ValueError("Invalid provider response")
            new_conversation = result.get("conversation_id", conversation)
            if not isinstance(new_conversation, str) or (new_conversation and not _uuid_string(new_conversation)):
                raise ValueError("Invalid conversation")
            message_id = result.get("message_id", result.get("id", ""))
            if not isinstance(message_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{0,128}", message_id):
                message_id = ""
            self._json(200, {"success": True, "answer": result["answer"], "conversation_id": new_conversation, "message_id": message_id, "sources": _citations(result)})
        except (socket.timeout, TimeoutError):
            self._error(504)
        except urllib.error.HTTPError as error:
            error.close()
            self._error(503 if error.code == 429 else 502)
        except urllib.error.URLError as error:
            self._error(504 if isinstance(error.reason, (socket.timeout, TimeoutError)) else 502)
        except (ValueError, TypeError, UnicodeError, OSError, RecursionError):
            self._error(502)


def create_server(host, port, base_dir=None):
    """Create one listener with no directory listing or implicit source serving."""
    root = Path(base_dir if base_dir is not None else BASE_DIR).resolve()
    origin_value = os.environ.get("PUBLIC_ORIGIN") or os.environ.get("RENDER_EXTERNAL_URL")
    public_origin = _origin(origin_value) if origin_value else None
    server = MaqamHTTPServer((host, port), MaqamProxyHandler)
    server.base_dir = root
    server.public_origin = public_origin
    actual_port = server.server_address[1]
    local_hosts = {"localhost", "127.0.0.1"}
    if host not in {"", "0.0.0.0"}:
        local_hosts.add(host)
    scheme = urllib.parse.urlsplit(public_origin).scheme if public_origin else "http"
    server.allowed_authorities = {_authority(value + ":" + str(actual_port), scheme) for value in local_hosts}
    if public_origin:
        server.allowed_authorities.add(urllib.parse.urlsplit(public_origin).netloc)
    server.rate_limiter = RateLimiter()
    server.worker_slots = threading.BoundedSemaphore(MAX_REQUEST_WORKERS)
    return server


def serve_on_port(port):
    """Compatibility for the existing Render command during this rollout."""
    with create_server("0.0.0.0", int(port)) as httpd:
        LOGGER.info("Maqam server ready")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass


def main():
    try:
        port = int(os.environ.get("PORT", "5000"))
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        raise SystemExit("PORT must be an integer between 1 and 65535") from None
    serve_on_port(port)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    main()
