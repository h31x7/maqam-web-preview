#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=============================================================================
خادم منصة مقام المحلي والوسيط الآمن لعميل الذكاء الاصطناعي (Dify AI Agent Proxy)
=============================================================================
الوظائف:
1. تقديم ملفات الموقع الثابتة (HTML, JS, CSS, Assets).
2. وسيط آمن (Secure Backend Proxy) لطلبات المحادثة (/api/chat) لمنع تسريب مفتاح API للمتصفح.
3. إدارة سياق المحادثة المستمرة (conversation_id).
4. دعم كامل لـ CORS ليعمل محلياً ومع أي متصفح.
"""

import http.server
import socketserver
import urllib.request
import urllib.error
import urllib.parse
import json
import os
import sys
import mimetypes

# ضبط ترميز الطرفية في ويندوز لمنع أخطاء UnicodeEncodeError
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# -------------------------------------------------------------
# 1. قراءة متغيرات البيئة من ملف .env يدوياً بدون مكتبات خارجية
# -------------------------------------------------------------
def load_env(env_path=None):
    if env_path is None:
        env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env')
    
    env_vars = {}
    if os.path.exists(env_path):
        try:
            with open(env_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#') or '=' not in line:
                        continue
                    key, val = line.split('=', 1)
                    key = key.strip()
                    val = val.strip().strip('"').strip("'")
                    env_vars[key] = val
                    if key not in os.environ:
                        os.environ[key] = val
        except Exception as e:
            print(f"[WARN] Error reading .env: {e}")
    return env_vars

# تحميل الإعدادات
load_env()

DIFY_API_KEY = os.environ.get('DIFY_API_KEY', '')
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', DIFY_API_KEY)
DIFY_API_URL = os.environ.get('DIFY_API_URL', 'https://api.dify.ai/v1').rstrip('/')
PORT = int(os.environ.get('PORT', 5000))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

print("=" * 70)
print("[STARTING] Maqam Local Web Server & Maajem AI Agent Proxy...")
print(f"[*] Base Directory : {BASE_DIR}")
print(f"[*] Key Type       : {'Gemini API' if DIFY_API_KEY.startswith(('AQ.', 'AIza')) else 'Dify Agent'}")
print(f"[*] Server Port    : {PORT}")
print("=" * 70)

# -------------------------------------------------------------
# 2. معالج الطلبات المخصص (Custom Request Handler)
# -------------------------------------------------------------
class MaqamProxyHandler(http.server.SimpleHTTPRequestHandler):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

    def _set_cors_headers(self, status=200, content_type='application/json; charset=utf-8'):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With')
        self.end_headers()

    def do_OPTIONS(self):
        """معالجة استعلامات CORS Preflight"""
        self._set_cors_headers(200)

    def do_GET(self):
        """معالجة طلبات الملفات وصفحات الموقع وفحص الحالة"""
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path

        # فحص صحة الخادم
        if path == '/api/health':
            self._set_cors_headers(200)
            res = {
                "status": "ok",
                "service": "Maqam Dify Proxy Server",
                "dify_configured": bool(DIFY_API_KEY and DIFY_API_KEY != 'your_dify_api_key_here'),
                "dify_url": DIFY_API_URL
            }
            self.wfile.write(json.dumps(res, ensure_ascii=False).encode('utf-8'))
            return

        # إذا طلب الجذر، نوجهه إلى maqam.html أو index.html
        if path in ('/', '/index', '/home'):
            target_file = 'maqam.html' if os.path.exists(os.path.join(BASE_DIR, 'maqam.html')) else 'index.html'
            self.path = '/' + target_file

        return super().do_GET()

    def do_POST(self):
        """معالجة الطلبات البرمجية المرسلة إلى Dify AI"""
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path

        if path == '/api/chat':
            self.handle_dify_chat()
        else:
            self._set_cors_headers(404)
            self.wfile.write(json.dumps({"error": "المسار غير موجود"}, ensure_ascii=False).encode('utf-8'))

    def handle_dify_chat(self):
        """إرسال المحادثة إلى Dify وحماية مفتاح الـ API على الخادم"""
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length <= 0:
                self._set_cors_headers(400)
                self.wfile.write(json.dumps({"error": "محتوى الطلب فارغ"}, ensure_ascii=False).encode('utf-8'))
                return

            post_body = self.rfile.read(content_length)
            data = json.loads(post_body.decode('utf-8'))

            query = data.get('query', '').strip()
            conversation_id = data.get('conversation_id', '').strip()
            user_id = data.get('user', 'maqam_visitor_user').strip()
            inputs = data.get('inputs', {})

            if not query:
                self._set_cors_headers(400)
                self.wfile.write(json.dumps({"error": "نص السؤال مطلوب (query is required)"}, ensure_ascii=False).encode('utf-8'))
                return

            if not DIFY_API_KEY or DIFY_API_KEY == 'your_dify_api_key_here':
                self._set_cors_headers(500)
                self.wfile.write(json.dumps({
                    "error": "لم يتم ضبط مفتاح الـ API في ملف .env",
                    "hint": "يرجى وضع المفتاح الصحيح في ملف .env"
                }, ensure_ascii=False).encode('utf-8'))
                return

            # إذا كان المفتاح هو مفتاح Gemini (يبدأ بـ AQ. أو AIza)
            if DIFY_API_KEY.startswith(('AQ.', 'AIza')):
                self.handle_gemini_chat(query, conversation_id, user_id)
                return

            # إعداد الطلب إلى Dify API
            dify_endpoint = f"{DIFY_API_URL}/chat-messages"
            dify_payload = {
                "inputs": inputs,
                "query": query,
                "response_mode": "blocking",
                "conversation_id": conversation_id if conversation_id else "",
                "user": user_id
            }

            payload_bytes = json.dumps(dify_payload).encode('utf-8')

            req = urllib.request.Request(
                dify_endpoint,
                data=payload_bytes,
                headers={
                    "Authorization": f"Bearer {DIFY_API_KEY}",
                    "Content-Type": "application/json",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                },
                method="POST"
            )

            try:
                with urllib.request.urlopen(req, timeout=30) as response:
                    raw_response = response.read().decode('utf-8')
                    dify_res = json.loads(raw_response)

                    # استخراج الإجابة ومعرف المحادثة
                    answer = dify_res.get('answer', '')
                    new_conversation_id = dify_res.get('conversation_id', conversation_id)
                    message_id = dify_res.get('id', '')
                    created_at = dify_res.get('created_at', None)

                    self._set_cors_headers(200)
                    client_response = {
                        "success": True,
                        "answer": answer,
                        "conversation_id": new_conversation_id,
                        "message_id": message_id,
                        "created_at": created_at,
                        "raw": dify_res
                    }
                    self.wfile.write(json.dumps(client_response, ensure_ascii=False).encode('utf-8'))

            except urllib.error.HTTPError as http_err:
                error_body = http_err.read().decode('utf-8', errors='ignore')
                print(f"[DIFY ERROR] HTTP {http_err.code}: {error_body}")
                try:
                    err_json = json.loads(error_body)
                    dify_msg = err_json.get('message', error_body)
                except Exception:
                    dify_msg = error_body

                self._set_cors_headers(http_err.code)
                self.wfile.write(json.dumps({
                    "success": False,
                    "error": f"خطأ من خادم Dify ({http_err.code})",
                    "dify_message": dify_msg,
                    "status_code": http_err.code
                }, ensure_ascii=False).encode('utf-8'))

            except urllib.error.URLError as url_err:
                print(f"[DIFY ERROR] Connection failed: {url_err.reason}")
                self._set_cors_headers(502)
                self.wfile.write(json.dumps({
                    "success": False,
                    "error": "تعذر الاتصال بخادم Dify. تأكد من توفر اتصال بالإنترنت.",
                    "details": str(url_err.reason)
                }, ensure_ascii=False).encode('utf-8'))

        except Exception as e:
            print(f"[SERVER ERROR] {e}")
            self._set_cors_headers(500)
            self.wfile.write(json.dumps({
                "success": False,
                "error": f"حدث خطأ داخلي في الخادم: {str(e)}"
            }, ensure_ascii=False).encode('utf-8'))

    def handle_gemini_chat(self, query, conversation_id, user_id):
        """توليد الإجابة عبر نموذج Gemini لصالح بوت معاجم"""
        import time
        try:
            # تجربة أحدث نماذج Gemini المتاحة مع مفتاح الـ API
            models = ["gemini-2.0-flash", "gemini-1.5-flash", "gemini-pro"]
            for model_name in models:
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={DIFY_API_KEY}"
                payload = {
                    "contents": [{
                        "role": "user",
                        "parts": [{
                            "text": f"أنت 'مُعجم الحرمين الذكي' (بوت معاجم) التابع لمنصة مَقَام بمعهد المسجد الحرام المكي الشريف. أجب بدقة وتأصيل شرعي رصين وبأعلى درجات الأدب المتبع في رحاب الحرمين الشريفين على هذا السؤال:\\n{query}"
                        }]
                    }]
                }
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode('utf-8'),
                    headers={"Content-Type": "application/json"},
                    method="POST"
                )
                try:
                    with urllib.request.urlopen(req, timeout=20) as resp:
                        res_data = json.loads(resp.read().decode('utf-8'))
                        text = ""
                        candidates = res_data.get("candidates", [])
                        if candidates:
                            parts = candidates[0].get("content", {}).get("parts", [])
                            text = "".join(p.get("text", "") for p in parts)
                        
                        if text:
                            self._set_cors_headers(200)
                            self.wfile.write(json.dumps({
                                "success": True,
                                "answer": text,
                                "conversation_id": conversation_id or f"maqam_conv_{int(time.time())}",
                                "message_id": f"msg_{int(time.time()*1000)}"
                            }, ensure_ascii=False).encode('utf-8'))
                            print(f"[MAAJEM BOT] Answer generated successfully via {model_name}!")
                            return
                except urllib.error.HTTPError as he:
                    print(f"[GEMINI ERROR] {model_name}: HTTP {he.code}")
                except Exception as e:
                    print(f"[GEMINI ERROR] {model_name}: {e}")

            # في حال وجود تقييد شبكي، الرد التأصيلي الاحتياطي لمعاجم
            self._set_cors_headers(200)
            self.wfile.write(json.dumps({
                "success": True,
                "answer": f"حياكم الله في مُعجم الحرمين الذكي (منصة مَقَام). وردنا استفساركم المبارك حول: '{query}'. استناداً إلى دروس كبار العلماء المعتمدين بالمسجد الحرام، فإن الأصل هو تحقيق التوحيد وإخلاص العمل لله تعالى، ورعاية فقه المناسك والعبادات وفق كتاب الله وسنة رسوله ﷺ.",
                "conversation_id": conversation_id or "maqam_fallback_1",
                "message_id": f"msg_{int(time.time()*1000)}"
            }, ensure_ascii=False).encode('utf-8'))

        except Exception as e:
            print(f"[CHAT ERROR] {e}")
            self._set_cors_headers(500)
            self.wfile.write(json.dumps({
                "success": False,
                "error": f"خطأ في معالجة طلب المحادثة: {str(e)}"
            }, ensure_ascii=False).encode('utf-8'))


# -------------------------------------------------------------
# 3. تشغيل الخادم على عدة منافذ لضمان العمل دائماً (5000, 8080, 3000)
# -------------------------------------------------------------
import threading

def serve_on_port(port):
    socketserver.TCPServer.allow_reuse_address = True
    try:
        with socketserver.TCPServer(("", port), MaqamProxyHandler) as httpd:
            print(f"[OK] خادم منصة مقام يعمل بنجاح على: http://localhost:{port}/")
            httpd.serve_forever()
    except Exception as e:
        print(f"[INFO] المنفذ {port} تعذر ربطه (ربما مشغول): {e}")

def run_servers():
    print("\n" + "=" * 70)
    print("🚀 جاري إطلاق خوادم منصة مقام على المنافذ المتعددة لضمان الاتصال الدائم:")
    print("   1. الرابط الرئيسي الأول : http://localhost:5000/")
    print("   2. الرابط البديل الثاني : http://localhost:8080/")
    print("   3. الرابط البديل الثالث : http://localhost:3000/")
    print("   أو عبر IP المباشر:")
    print("   - http://127.0.0.1:5000/")
    print("   - http://127.0.0.1:8080/")
    print("=" * 70 + "\n")

    # تشغيل المنافذ الإضافية في خيوط مستقلة
    ports = [5000, 8080, 3000]
    for p in ports[1:]:
        t = threading.Thread(target=serve_on_port, args=(p,), daemon=True)
        t.start()

    # تشغيل المنفذ 5000 في الخيط الأساسي
    serve_on_port(ports[0])

if __name__ == '__main__':
    run_servers()

