@echo off
cd /d "%~dp0"
set PORT=5004
if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" (
 "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" server.py
) else (
 python server.py
)
if errorlevel 1 pause
