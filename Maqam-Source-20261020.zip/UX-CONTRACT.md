# Maqam feedback behavior contract

Visual authority: DESIGN.md. Single HTML and existing CDN stack remain.

| Capability | Canonical owner | Source of truth | Verification |
|---|---|---|---|
| Theme | PresentationProvider | maqam_theme + initial system preference | feedback-global.test.js + browser refresh |
| Select/Listbox | labelled native select | local field state | keyboard/browser |
| Date | feedbackDomain + native date/time inputs | ISO instants, Asia/Riyadh | domain/publishing tests |
| Form | feedback full-page fields and publisher | FeedbackProvider persisted snapshot | draft/confirm/error browser tests |
| Scrollbar | global D.2 stylesheet | DESIGN.md tokens | overflow browser |
| Toast | App status region + feedback inline status | actual completed operation | browser and persistence tests |
| CRUD | FeedbackProvider | versioned localStorage metadata; IndexedDB original blobs | domain tests and full browser flow |

Success means the local durable write completed. Storage failure keeps the form and shows retryable feedback. Submission means saved on this browser; no teacher/network delivery is claimed. Publication releases on active app timers or reopening; no background push. Quizzes lock answered questions and record one completion, not hypothetical grades. Rankings are local activity only. Unknown deadlines, media, meeting links, summaries and explanations are clearly absent. No invented backend.

Subpages keep underlying dashboards mounted; Back restores the previous view. URL state is a hash route plus view/id query. Mobile or primary coarse pointer denies only teacher/organizer dashboards; scholars directory stays available. Dialogs use MaqamDialogFrame focus/Escape restoration; interactive controls have visible names and focus. Listening starts only after user action; stopping/closing cancels recognition, request and speech.
