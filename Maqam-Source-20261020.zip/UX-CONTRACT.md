# Maqam feedback behavior contract

Visual authority: DESIGN.md. Single HTML and existing CDN stack remain.

| Capability | Canonical owner | Source of truth | Verification |
|---|---|---|---|
| Theme | PresentationProvider | maqam_theme + initial system preference | feedback-global.test.js + browser refresh |
| Select/Listbox | labelled native select | local field state | keyboard/browser |
| Date | feedbackDomain + native date/time inputs | ISO instants, Asia/Riyadh | domain/publishing tests |
| Form | feedback full-page fields and publisher | FeedbackProvider persisted snapshot | draft/confirm/error browser tests |
| Scrollbar | global D.2 stylesheet | DESIGN.md tokens | overflow browser |
| Toast | App status region + feedback inline status | actual completed operation | browser and persistence tests |
| CRUD | FeedbackProvider | versioned localStorage metadata; IndexedDB original blobs | domain tests and full browser flow |

Success means the local durable write completed. Storage failure keeps the form and shows retryable feedback. Submission means saved on this browser; no teacher/network delivery is claimed. Publication releases on active app timers or reopening; no background push. Quizzes lock answered questions and record one completion, not hypothetical grades. Rankings are local activity only. Unknown deadlines, media, meeting links, summaries and explanations are clearly absent. No invented backend.

Subpages keep underlying dashboards mounted; Back restores the previous view. URL state is a hash route plus view/id query. Mobile or primary coarse pointer denies only teacher/organizer dashboards; scholars directory stays available. Dialogs use MaqamDialogFrame focus/Escape restoration; interactive controls have visible names and focus. Listening starts only after user action; stopping/closing cancels recognition, request and speech.

## Round5 note discussions

| Capability | Canonical owner | Source of truth | Allowed variants | Verification |
|---|---|---|---|---|
| Note CRUD and history | Round4StudyStore | Existing normalNotes IndexedDB record | manual / proposed apply / restore / reader save | round5-notes + round4-study tests |
| Maajem messages and input | MaajemMessage / MaajemComposer | Sanitized message and backend-only sources | student / note | chat + client-security tests, browser |
| Discussion overlay | Round5NoteChatHost / MaqamDialogFrame | Active note ID plus note/browser thread | right desktop panel / full mobile | browser keyboard/theme/refresh |
| Smart note adapter | Round5SmartNotes / saveSmart | normalNotes smart-current record | existing OCR and review retained | note identity/concurrency tests, browser |

Discussion sends a bounded excerpt (query <=4000 characters including user question <=1500), context and educational/no-fatwa/source instructions to the real same-origin chat proxy. The first discussion shows the privacy notice; dismissal is stored once in this browser. Each note stores up to eight browser-identity threads, forty messages per thread, its composer draft and provider conversation ID. Active note ID restores after refresh. Closing or stopping cancels client waiting; retries start fresh provider context. Late or conflicting thread writes cannot recreate deleted notes or overwrite another tab. Thread-only updates leave annotation revisions unchanged.

Edits are proposals until explicit application. Strict single complete delimited revisions show before/after; malformed replies remain normal safe Markdown with copy and a separate replace-review action when they fit the 8000-character note bound. Applying or manually changing text preserves the previous text; the last twenty versions can be restored. Stale proposal revisions cannot apply. Reader saves merge live metadata atomically and deleting a pin/note deletes its embedded threads. Unsaved reader pins explicitly require reader save before discussion. Quick save stays open with its actual saved text and a discuss action. The smart adapter keeps OCR/review, checks its captured note revision before saving and reflects externally applied note text; the original review editor remains limited to 1800 characters and clearly labels longer saved text.
